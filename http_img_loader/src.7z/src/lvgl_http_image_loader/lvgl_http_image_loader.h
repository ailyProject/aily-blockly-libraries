#ifndef LVGL_HTTP_IMAGE_LOADER_H
#define LVGL_HTTP_IMAGE_LOADER_H

#include <stdint.h>
#include <stdbool.h>
#include "lvgl.h"

/*=============================================================================
 *                              错误码
 *============================================================================*/
typedef enum {
    HTTP_IMG_OK = 0,              // 成功
    HTTP_IMG_ERR_WIFI,            // WiFi未连接
    HTTP_IMG_ERR_CONNECT,         // HTTP连接失败
    HTTP_IMG_ERR_NOT_FOUND,       // 404 资源不存在
    HTTP_IMG_ERR_TOO_LARGE,       // 图片太大
    HTTP_IMG_ERR_UNKNOWN_SIZE,    // 无法获取图片大小
    HTTP_IMG_ERR_DOWNLOAD,        // 下载失败
    HTTP_IMG_ERR_FILE_SYSTEM,     // 文件系统错误
    HTTP_IMG_ERR_DECODE,          // 解码失败
    HTTP_IMG_ERR_NO_MEMORY,       // 内存不足
    HTTP_IMG_ERR_INVALID_FORMAT,  // 不支持的图片格式
    HTTP_IMG_ERR_TIMEOUT,         // 超时
} http_img_err_t;

/*=============================================================================
 *                              图片信息结构
 *============================================================================*/
typedef struct {
    int32_t  content_length;      // 文件大小（-1表示未知）
    uint16_t width;               // 图片宽度（解码后才有）
    uint16_t height;              // 图片高度（解码后才有）
    char     content_type[48];    // MIME类型
    bool     is_jpeg;             // 是否为JPEG格式
    bool     is_png;              // 是否为PNG格式
} http_img_info_t;

/*=============================================================================
 *                              回调函数类型
 *============================================================================*/

/**
 * @brief 下载进度回调
 * @param downloaded 已下载字节数
 * @param total 总字节数（-1表示未知）
 */
typedef void (*http_img_progress_cb_t)(int32_t downloaded, int32_t total);

/**
 * @brief 加载完成回调
 * @param err 错误码
 * @param info 图片信息（成功时有效）
 */
typedef void (*http_img_complete_cb_t)(http_img_err_t err, const http_img_info_t* info);

/*=============================================================================
 *                              配置结构
 *============================================================================*/

/**
 * @brief PSRAM 配置模式
 */
typedef enum {
    PSRAM_MODE_NONE = 0,      // 无PSRAM（如ESP32-WROOM）
    PSRAM_MODE_AVAILABLE = 1, // 有PSRAM（如ESP32-WROVER）
    PSRAM_MODE_AUTO = 2       // 自动检测（运行时检测）
} http_img_psram_mode_t;

/**
 * @brief 存储策略模式
 */
typedef enum {
    STORAGE_MODE_AUTO = 0,      // 自动选择（有PSRAM用内存，无PSRAM用LittleFS）
    STORAGE_MODE_LITTLEFS = 1,  // 强制使用LittleFS（即使有PSRAM）
    STORAGE_MODE_PSRAM = 2      // 强制使用PSRAM内存（无PSRAM时会失败）
} http_img_storage_mode_t;

/**
 * @brief HTTP图片加载器配置
 */
struct HttpImageConfig {
    // 屏幕分辨率配置
    uint16_t screenWidth;           // 屏幕宽度，默认240
    uint16_t screenHeight;          // 屏幕高度，默认240
    
    // PSRAM和存储配置
    http_img_psram_mode_t psramMode;       // PSRAM模式，默认自动检测
    http_img_storage_mode_t storageMode;   // 存储策略，默认自动选择
    
    // 内存限制配置
    uint32_t maxFileSizePsram;      // 有PSRAM时最大图片大小，默认512KB
    uint32_t maxFileSizeNoPsram;    // 无PSRAM时最大图片大小，默认50KB
    uint32_t maxPixelsNoPsram;      // 无PSRAM时最大像素数，默认屏幕像素数
    
    // HTTP配置
    uint32_t timeoutMs;             // HTTP超时毫秒数，默认15000
    uint32_t chunkSize;             // 分块下载缓冲区大小，默认4096
    
    // 临时文件配置
    const char* tempFile;           // 临时文件路径，默认"/http_temp.jpg"
    
    // 解码配置
    uint32_t decodeStackSize;       // 解码任务栈大小，默认32KB
    bool decodeImmediately;         // 是否立即解码，默认true
    
    // 调试开关
    bool debug;                     // 是否输出调试日志，默认true
    
    // 默认构造函数 - 设置所有默认值
    HttpImageConfig() 
        : screenWidth(240)
        , screenHeight(240)
        , psramMode(PSRAM_MODE_AUTO)
        , storageMode(STORAGE_MODE_AUTO)
        , maxFileSizePsram(512 * 1024)
        , maxFileSizeNoPsram(50 * 1024)
        , maxPixelsNoPsram(240 * 240)
        , timeoutMs(15000)
        , chunkSize(4096)
        , tempFile("/http_temp.jpg")
        , decodeStackSize(32 * 1024)
        , decodeImmediately(true)
        , debug(false)
    {}
};

/*=============================================================================
 *                              HTTP图片加载器类
 *============================================================================*/

class HttpImageLoader {
public:
    /**
     * @brief 获取单例实例
     */
    static HttpImageLoader& getInstance();
    
    /**
     * @brief 初始化HTTP图片加载器
     * @param config 配置参数（可选，使用默认配置）
     * @return HTTP_IMG_OK 成功
     * 
     * @example 使用默认配置
     *   HttpImageLoader::getInstance().init();
     * 
     * @example 自定义配置
     *   HttpImageConfig config;
     *   config.screenWidth = 320;
     *   config.screenHeight = 240;
     *   config.psramMode = PSRAM_MODE_AUTO;
     *   config.debug = false;
     *   HttpImageLoader::getInstance().init(config);
     */
    http_img_err_t init(const HttpImageConfig& config = HttpImageConfig());
    
    /**
     * @brief 检查是否已初始化
     */
    bool isInitialized() const { return _initialized; }
    
    /**
     * @brief 检查系统是否有PSRAM
     * @return true: 有PSRAM, false: 无PSRAM
     */
    bool hasPsram() const { return _hasPsram; }
    
    /**
     * @brief 获取当前允许的最大图片大小
     * @return 最大字节数
     */
    uint32_t getMaxSize() const;
    
    /**
     * @brief 获取当前配置
     */
    const HttpImageConfig& getConfig() const { return _config; }
    
    /**
     * @brief 仅获取远程图片信息（不下载内容）
     * @param url 图片URL
     * @param info [out] 图片信息
     * @return 错误码
     */
    http_img_err_t getInfo(const char* url, http_img_info_t* info);
    
    /**
     * @brief 检查图片是否可加载（大小检查）
     * @param url 图片URL
     * @param info [out] 图片信息（可为NULL）
     * @return HTTP_IMG_OK: 可以加载, HTTP_IMG_ERR_TOO_LARGE: 太大
     */
    http_img_err_t checkLoadable(const char* url, http_img_info_t* info = nullptr);
    
    /**
     * @brief 加载HTTP图片并显示到LVGL Image对象
     * @param url 图片URL
     * @param img_obj LVGL图片对象（需要预先创建）
     * @param progress_cb 进度回调（可为NULL）
     * @return 错误码
     */
    http_img_err_t load(const char* url, lv_obj_t* img_obj, 
                        http_img_progress_cb_t progress_cb = nullptr);
    
    /**
     * @brief 加载HTTP图片到指定的Canvas对象
     * @param url 图片URL
     * @param canvas LVGL Canvas对象
     * @param x 绘制起始X坐标
     * @param y 绘制起始Y坐标
     * @return 错误码
     */
    http_img_err_t loadToCanvas(const char* url, lv_obj_t* canvas,
                                 int16_t x, int16_t y);
    
    /**
     * @brief 获取错误描述字符串
     * @param err 错误码
     * @return 错误描述
     */
    static const char* errToStr(http_img_err_t err);
    
    /**
     * @brief 清理临时文件和缓存
     */
    void cleanup();
    
private:
    HttpImageLoader();
    ~HttpImageLoader();
    
    // 禁止拷贝和赋值
    HttpImageLoader(const HttpImageLoader&) = delete;
    HttpImageLoader& operator=(const HttpImageLoader&) = delete;
    
    // 内部方法
    bool checkPsramAvailable();
    http_img_err_t downloadToPsram(const char* url, int32_t maxSize, 
                                    http_img_progress_cb_t cb);
    http_img_err_t downloadToFile(const char* url, const char* filepath,
                                   int32_t maxSize, http_img_progress_cb_t cb);
    http_img_err_t displayFromPsram(lv_obj_t* img_obj);
    http_img_err_t displayFromFile(const char* filepath, lv_obj_t* img_obj);
    
    void log(const char* fmt, ...);
    
    // 成员变量
    bool _initialized;
    bool _hasPsram;
    bool _usePsramStorage;
    HttpImageConfig _config;
    
    // PSRAM模式下的图片数据
    uint8_t* _imgData;
    size_t _imgDataSize;
    
    // 解码后的像素数据
    uint8_t* _pixelData;
    lv_image_dsc_t _decodedImg;
    
    // 解码任务状态
    volatile bool _decodeDone;
    volatile bool _decodeSuccess;
    
    // 友元函数用于解码任务和JPEG回调
    friend void httpImgDecodeTask(void* param);
    friend int jpgOutputCallback(void* jd, void* bitmap, void* rect);
};

// 全局便捷函数（可选使用）
inline HttpImageLoader& httpImageLoader() {
    return HttpImageLoader::getInstance();
}

#endif // LVGL_HTTP_IMAGE_LOADER_H
