#include "lvgl_http_image_loader.h"

#include <WiFi.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <stdarg.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <esp_heap_caps.h>

// TJpgDec 解码器 (LVGL内置)
extern "C" {
#include "../lvgl/src/libs/tjpgd/tjpgd.h"
}

/*=============================================================================
 *                              JPEG解码辅助结构
 *============================================================================*/
typedef struct {
    const uint8_t* data;
    size_t size;
    size_t pos;
} jpeg_mem_t;

// 当前加载器实例指针（用于解码回调）
static HttpImageLoader* s_currentLoader = nullptr;

/*=============================================================================
 *                              解码任务
 *============================================================================*/
void httpImgDecodeTask(void* param) {
    HttpImageLoader* loader = static_cast<HttpImageLoader*>(param);
    
    if (loader->_config.debug) {
        Serial.printf("[HTTP_IMG] Decode task started (stack high water: %d words)\n", 
                      uxTaskGetStackHighWaterMark(NULL));
    }
    
    // 触发 LVGL 刷新，这会导致图片解码
    lv_refr_now(NULL);
    
    if (loader->_config.debug) {
        Serial.println("[HTTP_IMG] Decode task: lv_refr_now completed");
        Serial.printf("[HTTP_IMG] Decode task stack remaining: %d words\n", 
                      uxTaskGetStackHighWaterMark(NULL));
    }
    
    loader->_decodeSuccess = true;
    loader->_decodeDone = true;
    
    vTaskDelete(NULL);
}

/*=============================================================================
 *                              静态JPEG回调（需要访问实例）
 *============================================================================*/

// JPEG输入回调：从内存读取数据
static size_t jpg_input_cb(JDEC* jd, uint8_t* buf, size_t len) {
    jpeg_mem_t* mem = (jpeg_mem_t*)jd->device;
    size_t remain = mem->size - mem->pos;
    if (len > remain) len = remain;
    if (buf) {
        memcpy(buf, mem->data + mem->pos, len);
    }
    mem->pos += len;
    return len;
}

// JPEG输出回调：写入像素数据（友元函数，可访问私有成员）
int jpgOutputCallback(void* jd_ptr, void* bitmap, void* rect_ptr) {
    JDEC* jd = (JDEC*)jd_ptr;
    JRECT* rect = (JRECT*)rect_ptr;
    
    if (!s_currentLoader || !s_currentLoader->_pixelData) {
        return 0;  // 中断解码
    }
    
    uint16_t* src = (uint16_t*)bitmap;
    uint16_t* dst = (uint16_t*)s_currentLoader->_pixelData;
    uint16_t img_w = jd->width;
    
    // 将解码的MCU块写入目标像素缓冲区
    for (int y = rect->top; y <= rect->bottom; y++) {
        for (int x = rect->left; x <= rect->right; x++) {
            dst[y * img_w + x] = *src++;
        }
    }
    return 1;  // 1=继续解码, 0=中断
}

// 静态包装函数，用于传递给 jd_decomp
static int jpg_output_cb(JDEC* jd, void* bitmap, JRECT* rect) {
    return jpgOutputCallback(jd, bitmap, rect);
}

/*=============================================================================
 *                              HttpImageLoader 实现
 *============================================================================*/

HttpImageLoader& HttpImageLoader::getInstance() {
    static HttpImageLoader instance;
    return instance;
}

HttpImageLoader::HttpImageLoader()
    : _initialized(false)
    , _hasPsram(false)
    , _usePsramStorage(false)
    , _imgData(nullptr)
    , _imgDataSize(0)
    , _pixelData(nullptr)
    , _decodeDone(false)
    , _decodeSuccess(false)
{
    memset(&_decodedImg, 0, sizeof(_decodedImg));
}

HttpImageLoader::~HttpImageLoader() {
    cleanup();
}

void HttpImageLoader::log(const char* fmt, ...) {
    if (!_config.debug) return;
    
    Serial.print("[HTTP_IMG] ");
    
    va_list args;
    va_start(args, fmt);
    char buf[256];
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    
    Serial.println(buf);
}

http_img_err_t HttpImageLoader::init(const HttpImageConfig& config) {
    if (_initialized) {
        return HTTP_IMG_OK;
    }
    
    // 保存配置
    _config = config;
    
    // 检测PSRAM
    switch (_config.psramMode) {
        case PSRAM_MODE_AUTO:
            _hasPsram = checkPsramAvailable();
            break;
        case PSRAM_MODE_AVAILABLE:
            _hasPsram = true;
            break;
        case PSRAM_MODE_NONE:
        default:
            _hasPsram = false;
            break;
    }
    
    // 决定存储策略
    switch (_config.storageMode) {
        case STORAGE_MODE_AUTO:
            _usePsramStorage = _hasPsram;
            break;
        case STORAGE_MODE_PSRAM:
            _usePsramStorage = true;
            break;
        case STORAGE_MODE_LITTLEFS:
        default:
            _usePsramStorage = false;
            break;
    }
    
    log("PSRAM: %s", _hasPsram ? "Available" : "Not available");
    log("Storage mode: %s", _usePsramStorage ? "PSRAM" : "LittleFS");
    log("Max image size: %lu bytes", getMaxSize());
    log("Screen: %dx%d", _config.screenWidth, _config.screenHeight);
    
    // 如果使用LittleFS模式，初始化文件系统
    if (!_usePsramStorage) {
        if (!LittleFS.begin(true)) {
            log("LittleFS mount failed!");
            return HTTP_IMG_ERR_FILE_SYSTEM;
        }
        log("LittleFS initialized");
    }
    
    _initialized = true;
    return HTTP_IMG_OK;
}

bool HttpImageLoader::checkPsramAvailable() {
    size_t psram_size = heap_caps_get_total_size(MALLOC_CAP_SPIRAM);
    log("PSRAM size: %u bytes", psram_size);
    return psram_size > 0;
}

uint32_t HttpImageLoader::getMaxSize() const {
    return _hasPsram ? _config.maxFileSizePsram : _config.maxFileSizeNoPsram;
}

http_img_err_t HttpImageLoader::getInfo(const char* url, http_img_info_t* info) {
    log("getInfo: checking URL: %s", url);
    
    if (!WiFi.isConnected()) {
        log("WiFi not connected!");
        return HTTP_IMG_ERR_WIFI;
    }
    
    log("WiFi connected, starting HTTP request...");
    
    HTTPClient http;
    http.begin(url);
    http.setTimeout(_config.timeoutMs);
    
    // 使用HEAD请求只获取头信息
    const char* headers[] = {"Content-Type", "Content-Length"};
    http.collectHeaders(headers, 2);
    
    int httpCode = http.sendRequest("HEAD");
    log("HEAD request returned: %d", httpCode);
    
    if (httpCode == HTTP_CODE_NOT_FOUND) {
        http.end();
        return HTTP_IMG_ERR_NOT_FOUND;
    }
    
    if (httpCode != HTTP_CODE_OK) {
        log("HEAD request failed: %d", httpCode);
        http.end();
        return HTTP_IMG_ERR_CONNECT;
    }
    
    // 填充信息
    if (info) {
        info->content_length = http.getSize();
        
        String ct = http.header("Content-Type");
        strncpy(info->content_type, ct.c_str(), sizeof(info->content_type) - 1);
        
        info->is_jpeg = (ct.indexOf("jpeg") >= 0 || ct.indexOf("jpg") >= 0);
        info->is_png = (ct.indexOf("png") >= 0);
        info->width = 0;
        info->height = 0;
    }
    
    http.end();
    return HTTP_IMG_OK;
}

http_img_err_t HttpImageLoader::checkLoadable(const char* url, http_img_info_t* info) {
    log("checkLoadable: %s", url);
    
    http_img_info_t local_info;
    http_img_info_t* p_info = info ? info : &local_info;
    
    http_img_err_t err = getInfo(url, p_info);
    if (err != HTTP_IMG_OK) {
        log("checkLoadable failed: %s", errToStr(err));
        return err;
    }
    
    // 检查大小
    int32_t max_size = (int32_t)getMaxSize();
    
    if (p_info->content_length < 0) {
        log("Warning: Content-Length unknown");
        return HTTP_IMG_OK;
    }
    
    if (p_info->content_length > max_size) {
        log("Image too large: %d > %d", p_info->content_length, max_size);
        return HTTP_IMG_ERR_TOO_LARGE;
    }
    
    return HTTP_IMG_OK;
}

http_img_err_t HttpImageLoader::load(const char* url, lv_obj_t* img_obj,
                                      http_img_progress_cb_t progress_cb) {
    log("load() called with URL: %s", url);
    
    if (!_initialized) {
        log("Not initialized, calling init()...");
        http_img_err_t err = init();
        if (err != HTTP_IMG_OK) return err;
    }
    
    // 1. 先检查是否可加载
    log("Checking if image is loadable...");
    http_img_info_t info;
    http_img_err_t err = checkLoadable(url, &info);
    if (err != HTTP_IMG_OK) {
        return err;
    }
    
    log("Downloading: %s (%d bytes)", url, info.content_length);
    
    // 2. 根据存储模式下载
    if (_usePsramStorage) {
        // PSRAM模式：直接下载到内存
        err = downloadToPsram(url, getMaxSize(), progress_cb);
        if (err != HTTP_IMG_OK) {
            return err;
        }
        
        // 3. 从PSRAM显示
        err = displayFromPsram(img_obj);
    } else {
        // LittleFS模式：下载到文件
        err = downloadToFile(url, _config.tempFile, getMaxSize(), progress_cb);
        if (err != HTTP_IMG_OK) {
            return err;
        }
        
        // 3. 从文件显示
        err = displayFromFile(_config.tempFile, img_obj);
    }
    
    if (err != HTTP_IMG_OK) {
        return err;
    }
    
    if (_config.decodeImmediately) {
        // 使用独立任务进行解码，避免栈溢出
        log("Creating decode task with %d bytes stack...", _config.decodeStackSize);
        
        _decodeDone = false;
        _decodeSuccess = false;
        
        BaseType_t ret = xTaskCreatePinnedToCore(
            httpImgDecodeTask,
            "img_decode",
            _config.decodeStackSize / sizeof(StackType_t),
            this,
            5,
            NULL,
            1  // Core 1
        );
        
        if (ret != pdPASS) {
            log("Failed to create decode task!");
            return HTTP_IMG_ERR_NO_MEMORY;
        }
        
        // 等待解码完成
        log("Waiting for decode task...");
        uint32_t timeout = 0;
        while (!_decodeDone && timeout < _config.timeoutMs) {
            vTaskDelay(pdMS_TO_TICKS(10));
            timeout += 10;
        }
        
        if (!_decodeDone) {
            log("Decode timeout!");
            return HTTP_IMG_ERR_TIMEOUT;
        }
        
        log("Decode %s", _decodeSuccess ? "completed" : "failed");
    }
    
    return HTTP_IMG_OK;
}

http_img_err_t HttpImageLoader::loadToCanvas(const char* url, lv_obj_t* canvas,
                                              int16_t x, int16_t y) {
    // TODO: 实现Canvas加载功能
    log("loadToCanvas not implemented yet");
    return HTTP_IMG_ERR_INVALID_FORMAT;
}

const char* HttpImageLoader::errToStr(http_img_err_t err) {
    switch (err) {
        case HTTP_IMG_OK:              return "Success";
        case HTTP_IMG_ERR_WIFI:        return "WiFi not connected";
        case HTTP_IMG_ERR_CONNECT:     return "Connection failed";
        case HTTP_IMG_ERR_NOT_FOUND:   return "Resource not found (404)";
        case HTTP_IMG_ERR_TOO_LARGE:   return "Image too large";
        case HTTP_IMG_ERR_UNKNOWN_SIZE: return "Unknown image size";
        case HTTP_IMG_ERR_DOWNLOAD:    return "Download failed";
        case HTTP_IMG_ERR_FILE_SYSTEM: return "File system error";
        case HTTP_IMG_ERR_DECODE:      return "Decode failed";
        case HTTP_IMG_ERR_NO_MEMORY:   return "Out of memory";
        case HTTP_IMG_ERR_INVALID_FORMAT: return "Invalid format";
        case HTTP_IMG_ERR_TIMEOUT:     return "Timeout";
        default:                       return "Unknown error";
    }
}

void HttpImageLoader::cleanup() {
    // 清理PSRAM中的原始JPEG数据
    if (_imgData) {
        heap_caps_free(_imgData);
        _imgData = nullptr;
        _imgDataSize = 0;
        log("PSRAM JPEG data freed");
    }
    
    // 清理PSRAM中的解码后像素数据
    if (_pixelData) {
        heap_caps_free(_pixelData);
        _pixelData = nullptr;
        log("PSRAM pixel data freed");
    }
    
    // 重置图片描述符
    memset(&_decodedImg, 0, sizeof(_decodedImg));
    
    // 清理LittleFS临时文件
    if (_config.tempFile && LittleFS.exists(_config.tempFile)) {
        LittleFS.remove(_config.tempFile);
        log("Temp file removed");
    }
}

/*=============================================================================
 *                              内部下载/显示方法
 *============================================================================*/

http_img_err_t HttpImageLoader::downloadToPsram(const char* url, int32_t maxSize, 
                                                 http_img_progress_cb_t progress_cb) {
    if (!WiFi.isConnected()) {
        return HTTP_IMG_ERR_WIFI;
    }
    
    // 清理之前的数据
    if (_imgData) {
        heap_caps_free(_imgData);
        _imgData = nullptr;
    }
    
    HTTPClient http;
    http.begin(url);
    http.setTimeout(_config.timeoutMs);
    
    int httpCode = http.GET();
    if (httpCode != HTTP_CODE_OK) {
        log("GET failed: %d", httpCode);
        http.end();
        return HTTP_IMG_ERR_DOWNLOAD;
    }
    
    int32_t totalSize = http.getSize();
    if (totalSize <= 0) {
        totalSize = maxSize;
    }
    
    if (totalSize > maxSize) {
        log("Content too large: %d > %d", totalSize, maxSize);
        http.end();
        return HTTP_IMG_ERR_TOO_LARGE;
    }
    
    // 在PSRAM中分配内存
    log("Allocating %d bytes in PSRAM...", totalSize);
    _imgData = (uint8_t*)heap_caps_malloc(totalSize, MALLOC_CAP_SPIRAM);
    if (!_imgData) {
        log("Failed to allocate PSRAM!");
        http.end();
        return HTTP_IMG_ERR_NO_MEMORY;
    }
    
    WiFiClient* stream = http.getStreamPtr();
    int32_t downloaded = 0;
    
    while (http.connected() && downloaded < totalSize) {
        size_t available = stream->available();
        if (available) {
            size_t toRead = min(available, (size_t)(totalSize - downloaded));
            size_t readBytes = stream->readBytes(_imgData + downloaded, toRead);
            downloaded += readBytes;
            
            if (progress_cb) {
                progress_cb(downloaded, totalSize);
            }
        }
        delay(1);
    }
    
    http.end();
    _imgDataSize = downloaded;
    
    log("Downloaded %d bytes to PSRAM", downloaded);
    
    // 验证JPEG头
    if (downloaded >= 2) {
        log("File header: 0x%02X 0x%02X", _imgData[0], _imgData[1]);
        if (_imgData[0] == 0xFF && _imgData[1] == 0xD8) {
            log("Valid JPEG header");
        }
    }
    
    return HTTP_IMG_OK;
}

http_img_err_t HttpImageLoader::displayFromPsram(lv_obj_t* img_obj) {
    if (!_imgData || _imgDataSize == 0) {
        log("No image data in PSRAM");
        return HTTP_IMG_ERR_FILE_SYSTEM;
    }
    
    log("Decoding JPEG from PSRAM (%d bytes)...", _imgDataSize);
    
    // 设置当前加载器实例指针（用于解码回调）
    s_currentLoader = this;
    
    // 1. 准备解码器
    JDEC jdec;
    
    // 工作缓冲区大小 - TJpgDec需要约3100字节
    #define TJPGD_WORK_SIZE 4096
    void* work = heap_caps_malloc(TJPGD_WORK_SIZE, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!work) {
        work = malloc(TJPGD_WORK_SIZE);  // 回退到普通内存
    }
    if (!work) {
        log("Failed to allocate work buffer");
        return HTTP_IMG_ERR_NO_MEMORY;
    }
    
    // 准备内存读取结构
    jpeg_mem_t mem = { _imgData, _imgDataSize, 0 };
    
    // 2. 分析JPEG
    JRESULT res = jd_prepare(&jdec, jpg_input_cb, work, TJPGD_WORK_SIZE, &mem);
    if (res != JDR_OK) {
        log("JPEG prepare failed: %d", res);
        free(work);
        return HTTP_IMG_ERR_DECODE;
    }
    
    log("JPEG info: %dx%d", jdec.width, jdec.height);
    
    // 3. 分配像素数据缓冲区（RGB565格式，每像素2字节）
    size_t pixel_size = jdec.width * jdec.height * 2;
    log("Allocating pixel buffer: %d bytes", pixel_size);
    
    // 释放之前的像素数据
    if (_pixelData) {
        heap_caps_free(_pixelData);
        _pixelData = nullptr;
    }
    
    _pixelData = (uint8_t*)heap_caps_malloc(pixel_size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!_pixelData) {
        log("Failed to allocate pixel buffer in PSRAM");
        free(work);
        return HTTP_IMG_ERR_NO_MEMORY;
    }
    
    // 4. 解码JPEG
    res = jd_decomp(&jdec, jpg_output_cb, 0);  // scale=0 表示1:1
    
    free(work);  // 释放工作缓冲区
    
    if (res != JDR_OK) {
        log("JPEG decompress failed: %d", res);
        heap_caps_free(_pixelData);
        _pixelData = nullptr;
        return HTTP_IMG_ERR_DECODE;
    }
    
    log("JPEG decoded successfully");
    
    // 5. 创建LVGL图片描述符
    memset(&_decodedImg, 0, sizeof(_decodedImg));
    _decodedImg.header.cf = LV_COLOR_FORMAT_RGB565;
    _decodedImg.header.w = jdec.width;
    _decodedImg.header.h = jdec.height;
    _decodedImg.data_size = pixel_size;
    _decodedImg.data = _pixelData;
    
    // 6. 设置图片源
    lv_image_set_src(img_obj, &_decodedImg);
    
    log("Image displayed from PSRAM: %dx%d", jdec.width, jdec.height);
    return HTTP_IMG_OK;
}

http_img_err_t HttpImageLoader::downloadToFile(const char* url, const char* filepath,
                                                int32_t maxSize, 
                                                http_img_progress_cb_t progress_cb) {
    if (!WiFi.isConnected()) {
        return HTTP_IMG_ERR_WIFI;
    }
    
    HTTPClient http;
    http.begin(url);
    http.setTimeout(_config.timeoutMs);
    
    int httpCode = http.GET();
    if (httpCode != HTTP_CODE_OK) {
        log("GET failed: %d", httpCode);
        http.end();
        return HTTP_IMG_ERR_DOWNLOAD;
    }
    
    int32_t totalSize = http.getSize();
    WiFiClient* stream = http.getStreamPtr();
    
    File file = LittleFS.open(filepath, "w");
    if (!file) {
        log("Failed to open file for writing");
        http.end();
        return HTTP_IMG_ERR_FILE_SYSTEM;
    }
    
    uint8_t* chunk = (uint8_t*)malloc(_config.chunkSize);
    if (!chunk) {
        log("Failed to allocate chunk buffer");
        file.close();
        http.end();
        return HTTP_IMG_ERR_NO_MEMORY;
    }
    
    int32_t downloaded = 0;
    
    while (http.connected() && (totalSize < 0 || downloaded < totalSize)) {
        size_t available = stream->available();
        if (available) {
            size_t toRead = min(available, (size_t)_config.chunkSize);
            size_t readBytes = stream->readBytes(chunk, toRead);
            
            if (readBytes > 0) {
                file.write(chunk, readBytes);
                downloaded += readBytes;
                
                if (downloaded > maxSize) {
                    log("Download exceeds max size!");
                    file.close();
                    free(chunk);
                    LittleFS.remove(filepath);
                    http.end();
                    return HTTP_IMG_ERR_TOO_LARGE;
                }
                
                if (progress_cb) {
                    progress_cb(downloaded, totalSize);
                }
            }
        }
        delay(1);
    }
    
    file.close();
    free(chunk);
    http.end();
    
    log("Downloaded %d bytes to file", downloaded);
    return HTTP_IMG_OK;
}

http_img_err_t HttpImageLoader::displayFromFile(const char* filepath, lv_obj_t* img_obj) {
    static char lv_path[64];
    snprintf(lv_path, sizeof(lv_path), "L:%s", filepath);
    
    log("Setting image from file: %s", lv_path);
    
    if (!LittleFS.exists(filepath)) {
        log("File not found: %s", filepath);
        return HTTP_IMG_ERR_FILE_SYSTEM;
    }
    
    lv_image_set_src(img_obj, lv_path);
    
    log("Image set from file");
    return HTTP_IMG_OK;
}