
#include "Wire.h"
#include "seekfree_expansion_ch422.h"

#define I2C_SDA_PIN (0)
#define I2C_SCL_PIN (1)

#define I2C_DEV_SYS_ADDR 	(0x48 >> 1)
#define I2C_DEV_EOCL_ADDR 	(0x44 >> 1)
#define I2C_DEV_EOCH_ADDR 	(0x46 >> 1)
#define I2C_DEV_EIO_ADDR 	(0x60 >> 1)



// 构造函数
CH422::CH422()
{
    
}
CH422::~CH422()
{

}

void CH422::write_reg(uint8_t reg_addr, uint8_t dat) // 写一个寄存器
{
    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, 400000);
    Wire.beginTransmission(reg_addr);
    Wire.write(dat);
    Wire.endTransmission(true);
}


void CH422::set_beep(uint8_t state)       // 设置蜂鸣器状态
{
    if(1 < state)
    {
        state = 1;
    }
	state = !state;
	
    eio &= ~((uint8_t)(1 << 3));
    eio |= state << 3;
    write_reg(I2C_DEV_EIO_ADDR, eio);
}

void CH422::set_red_led(uint8_t state)
{
    if(1 < state)
    {
        state = 1;
    }
    state = !state;
    eio &= ~((uint8_t)(1 << 1));
    eio |= state << 1;
    write_reg(I2C_DEV_EIO_ADDR, eio);
}

void CH422::set_green_led(uint8_t state)
{
    if(1 < state)
    {
        state = 1;
    }
    state = !state;
    eio &= ~((uint8_t)(1 << 2));
    eio |= state << 2;
    write_reg(I2C_DEV_EIO_ADDR, eio);
}

void CH422::set_blue_led(uint8_t state)
{
    if(1 < state)
    {
        state = 1;
    }
    state = !state;
    eio &= ~((uint8_t)(1 << 0));
    eio |= state << 0;
    write_reg(I2C_DEV_EIO_ADDR, eio);
}


void CH422::set_power(uint8_t pin_index, uint8_t state) // 设置MOS状态，仅用于内部模块进行调用
{
	// 清空对应的位
	eoc &= ~(((uint16_t)1 << pin_index));
	// 设置对应的位
	eoc |= (uint16_t)state << pin_index;
	if(8 > pin_index)
	{
		write_reg(I2C_DEV_EOCL_ADDR, (uint8_t)eoc);
	}
	else
	{
		write_reg(I2C_DEV_EOCH_ADDR, eoc >> 8);
	}
}


void CH422::begin(void)
{
    eoc = 0x0000;
    eio = 0x0F;
    // IO扩展芯片初始化
    write_reg(I2C_DEV_SYS_ADDR, 0x01);
    // 关闭所有的LED与蜂鸣器
    write_reg(I2C_DEV_EOCL_ADDR, (uint8_t)eoc);
    write_reg(I2C_DEV_EOCH_ADDR, eoc >> 8);
    // 关闭所有的供电设备
    write_reg(I2C_DEV_EIO_ADDR, eio);
	
	// 延时确保电源被关闭
	delay(500);
}