#ifndef _seekfree_photoelectricity_h_
#define _seekfree_photoelectricity_h_

#include <Arduino.h> 



class PHOTOELECTRICITY
{
    private:
        uint8_t set_id          (uint16_t now_id, uint8_t set_id);
        uint8_t get_id          (uint16_t id, uint16_t &read_id);

    public:
        uint8_t set_black (uint16_t id);       // 将当前数值作为黑色时的参考值
        uint8_t set_white (uint16_t id);       // 将当前数值作为白色时的参考值

        uint8_t get_position (uint16_t id, int16_t &position);    // 获取偏差
        uint8_t get_value (uint16_t id, uint8_t channel, int16_t &value);       // 读取传感器的数值
        uint8_t get_value_bin (uint16_t id, uint8_t channel, uint8_t &value);   // 获取传感器数值二值化后的值 0：看到黑色 1：看到的是白色
        uint8_t get_black_num (uint16_t id, uint8_t &value);
        uint8_t get_white_num (uint16_t id, uint8_t &value);

        uint8_t begin         	(uint8_t power_index); // 初始化
};



#endif
