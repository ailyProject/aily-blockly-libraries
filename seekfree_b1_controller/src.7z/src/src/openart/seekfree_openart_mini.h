#ifndef _seekfree_openart_mini_h_
#define _seekfree_openart_mini_h_

#include <Arduino.h> 



class OPENART_MINI
{
    private:
        static volatile uint8_t receive_ack_flag;
        static uint8_t data[120];
        static uint8_t data_length;
        
        static int16_t object_shape;
        static int16_t object_x;
        static int16_t object_y;

        static int16_t apriltag_number;
        static int16_t apriltag_x;
        static int16_t apriltag_y;

        uint8_t wait_ack(void);
        void    send_ready(void);
        static void uart_callback(void);
        static void analysis(void);

    public:
        OPENART_MINI();
        ~OPENART_MINI();

        void    detection_object(uint8_t shape, uint32_t rgb_value);    // 1：正方形 2：圆柱 3：圆锥
        void    detection_apriltag(void);
        void    detection_stop(void);
        uint8_t get_result(uint8_t type);   // 判断是否找到对应的内容 1：找到 0：未找到
        int16_t get_coord_x(uint8_t type);  // 获取对应内容的X坐标
        int16_t get_coord_y(uint8_t type);  // 获取对应内容的Y坐标
        void    begin  (void); // 初始化
};


#endif
