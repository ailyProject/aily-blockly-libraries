#ifndef _seekfree_key4_adc1_h_
#define _seekfree_key4_adc1_h_

#include <Arduino.h> 

#define KEY_NUM 4

typedef enum
{
    KEY_IDLE,       // 按键未按下
    KEY_PRESS,      // 按键持续按下
    KEY_LONG_PRESS, // 按键长按中 超过1秒算长按
    KEY_RELEASE,    // 按键从按下到释放的切换
}key_state_enum;

class KEY4_ADC1
{
    private:
        uint8_t key_state[KEY_NUM];
        static void scan    (void *parameter); // 按键扫描函数

    public:
        KEY4_ADC1();
        ~KEY4_ADC1();

        uint8_t read_state  (uint8_t key_id, uint8_t state);        // 获取按键状态 0：未按下 1：已按下未放开 2：长按中 3：按键按下并放开 key_id：范围0-3

        void    begin  (void); // 初始化
};




#endif
