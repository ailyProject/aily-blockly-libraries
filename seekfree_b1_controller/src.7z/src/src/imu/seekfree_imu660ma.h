#ifndef _seekfree_imu660ma_h_
#define _seekfree_imu660ma_h_

#include <Arduino.h> 



class IMU660MA
{
    private:
        int16_t acc_x,  acc_y,  acc_z;
        int16_t gyro_x, gyro_y, gyro_z;
        float   pitch,  roll,   yaw;
        uint8_t set_id          (uint16_t now_id, uint8_t set_id);
        uint8_t get_id          (uint16_t id, uint16_t &read_id);

    public:
        IMU660MA();
        ~IMU660MA();

        uint8_t calibration_acc (void);
        uint8_t calibration_gyro(void);
        uint8_t calibration_yaw (int16_t yaw);
        uint8_t get_acc         (int16_t &acc_x_data, int16_t &acc_y_data, int16_t &acc_z_data);
        uint8_t get_gyro        (int16_t &gyro_x_data, int16_t &gyro_y_data, int16_t &gyro_z_data);
        uint8_t get_pitch       (float &pitch_data);
        uint8_t get_roll        (float &roll_data);
        uint8_t get_yaw         (float &yaw_data);

        uint8_t begin           (uint8_t power_index); // 初始化
};


#endif
