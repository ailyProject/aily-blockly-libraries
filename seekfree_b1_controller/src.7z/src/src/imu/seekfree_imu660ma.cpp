#include "seekfree_can.h"
#include "seekfree_expansion_ch422.h"

#include "seekfree_imu660ma.h"


#define IMU_ID          (0X02)          // 定义IMU产品的ID
#define IMU_CAN_ID      (IMU_ID << 4)   // IMU产品的默认CAN ID

extern ESP32C3_CAN esp32c3_can;
extern CH422        ch422;

IMU660MA::IMU660MA()
{

}

IMU660MA::~IMU660MA()
{

}

uint8_t IMU660MA::set_id(uint16_t now_id, uint8_t set_id)
{
    uint8_t result;
    result = esp32c3_can.send_command_halfword(IMU_CAN_ID + now_id, 6, 0x100, IMU_CAN_ID + set_id, 0);
    return result;
}

uint8_t IMU660MA::get_id(uint16_t id, uint16_t &read_id)
{
    uint8_t result;
    result = esp32c3_can.send_command(IMU_CAN_ID + id, 0x000);
    if(0 == result)
    {
        read_id = esp32c3_can.receive_data_struct->id;
    }
    return result;
}

uint8_t IMU660MA::calibration_acc (void)
{
    uint8_t result;
    result = esp32c3_can.send_command(IMU_CAN_ID + 1, 0x300);
    return result;
}

uint8_t IMU660MA::calibration_gyro(void)
{
    uint8_t result;
    result = esp32c3_can.send_command(IMU_CAN_ID + 1, 0x301);
    return result;
}

uint8_t IMU660MA::calibration_yaw(int16_t yaw)
{
    uint8_t result;
    result = esp32c3_can.send_command_float(IMU_CAN_ID + 1, 0x302, yaw);
    return result;
}

uint8_t IMU660MA::get_acc(int16_t &acc_x_data, int16_t &acc_y_data, int16_t &acc_z_data)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x200, 0, 0, 0, 0);
    if(0 == result)
    {
        acc_x_data = esp32c3_can.receive_data_struct->data_int16[0];
    }

    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x200, 1, 0, 0, 0);
    if(0 == result)
    {
        acc_y_data = esp32c3_can.receive_data_struct->data_int16[0];
    }

    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x200, 2, 0, 0, 0);
    if(0 == result)
    {
        acc_z_data = esp32c3_can.receive_data_struct->data_int16[0];
    }
    return result;
}
uint8_t IMU660MA::get_gyro(int16_t &gyro_x_data, int16_t &gyro_y_data, int16_t &gyro_z_data)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x201, 0, 0, 0, 0);
    if(0 == result)
    {
        gyro_x_data = esp32c3_can.receive_data_struct->data_int16[0];
    }

    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x201, 1, 0, 0, 0);
    if(0 == result)
    {
        gyro_y_data = esp32c3_can.receive_data_struct->data_int16[0];
    }

    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x201, 2, 0, 0, 0);
    if(0 == result)
    {
        gyro_z_data = esp32c3_can.receive_data_struct->data_int16[0];
    }
    return result;
}

uint8_t IMU660MA::get_pitch(float &pitch_data)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x202, 0, 0, 0, 0);
    if(0 == result)
    {
        pitch_data = esp32c3_can.receive_data_struct->data_float;
    }

    return result;
}

uint8_t IMU660MA::get_roll(float &roll_data)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x202, 1, 0, 0, 0);
    if(0 == result)
    {
        roll_data = esp32c3_can.receive_data_struct->data_float;
    }

    return result;
}

uint8_t IMU660MA::get_yaw(float &yaw_data)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(IMU_CAN_ID + 1, 5, 0x202, 2, 0, 0, 0);
    if(0 == result)
    {
        yaw_data = esp32c3_can.receive_data_struct->data_float;
    }

    return result;
}

uint8_t IMU660MA::begin(uint8_t power_index)
{
    uint8_t  state = 1;
    uint16_t read_id;
    ch422.set_power(power_index, 1);  // 打开电源
    delay(200);             // 打开电源之后务必延时，等待设备启动
    get_id(0, read_id);
    if(IMU_CAN_ID == read_id)
    {
        set_id(0, 1);
        state = 0;
    }
    else
    {
        ch422.set_power(power_index, 0);  // 打开电源
    }
    return state;
}
