#ifndef _seekfree_can_h_
#define _seekfree_can_h_

#include <Arduino.h> 
#include "driver/twai.h"

#define BOARD_ID        (0X01)          // 定义当前主板的ID


typedef struct
{
	uint16_t cmd;
	uint16_t id;		// 发送时填写自己的ID，接收时表示收到的消息来至于谁
	union
	{
		uint8_t     data_byte[4];
		uint16_t 	data_halfword[2];
        int16_t     data_int16[2];
        uint32_t    data_word;
        int32_t     data_int32;
        float       data_float;
	};
	
}seekfree_can_struct;

class ESP32C3_CAN
{
    private:
    bool driver_installed;

    public:
        
        ESP32C3_CAN();
        ~ESP32C3_CAN();

        twai_message_t      send_data;
        twai_message_t      receive_data;
        seekfree_can_struct *send_data_struct;      // 快速解析数据的联合体
        seekfree_can_struct *receive_data_struct;
        uint8_t state (void);   // 读取CAN接口初始化状态 1：初始化完成 0：未完成初始化
        uint8_t write (void);   // 将send_data中的数据发送出去，返回1：发送失败
        uint8_t read  (void);   // 接收数据保存到receive_data，返回1：接收失败
        uint8_t send_command            (uint16_t can_id, uint16_t cmd);
        uint8_t send_command_byte       (uint16_t can_id, uint8_t length, uint16_t cmd, uint8_t data1, uint8_t data2, uint8_t data3, uint8_t data4);
        uint8_t send_command_halfword   (uint16_t can_id, uint8_t length, uint16_t cmd, uint16_t data1, uint16_t data2);
        uint8_t send_command_float      (uint16_t can_id, uint16_t cmd, float data1);
        uint8_t error (void); 

        void    begin  (void); // 初始化
};




#endif
