
#include "seekfree_openart_mini.h"

#define WAIT_TIME 100

#define BAUD      115200  // Any baudrate from 300 to 115200
#define TEST_UART 1     // Serial1 will be used for the loopback testing with different RX FIFO FULL values
#define RXPIN     2     // GPIO 4 => RX for Serial1
#define TXPIN     3     // GPIO 5 => TX for Serial1

uint8_t OPENART_MINI::data[120] = {0};
uint8_t OPENART_MINI::data_length = 0;

int16_t OPENART_MINI::object_shape;
int16_t OPENART_MINI::object_x;
int16_t OPENART_MINI::object_y;

int16_t OPENART_MINI::apriltag_number;
int16_t OPENART_MINI::apriltag_x;
int16_t OPENART_MINI::apriltag_y;

volatile uint8_t OPENART_MINI::receive_ack_flag = 0;



OPENART_MINI::OPENART_MINI()
{


}

OPENART_MINI::~OPENART_MINI()
{

}

void OPENART_MINI::uart_callback(void)
{
    data_length = Serial1.available();
    
    if (data_length) 
    {
        Serial1.readBytes(data, data_length);
        data[data_length] = 0;
        analysis();
    }
}

void OPENART_MINI::analysis(void)
{
    String receive_str = String((char *)data);

    if(0 <= receive_str.indexOf("AT+RESULT1"))
    {
        int index1, index2;

        index1 = receive_str.indexOf('=') + 1;
        index2 = receive_str.indexOf(',');
        object_shape = (int16_t)(receive_str.substring(index1, index2).toInt());
        
        index1 = index2 + 1;
        index2 = receive_str.indexOf(',', index2 + 1);
        object_x = (int16_t)(receive_str.substring(index1, index2).toInt());
        
        index1 = index2 + 1;
        index2 = receive_str.indexOf('\r', index2 + 1);
        object_y = (int16_t)(receive_str.substring(index1, index2).toInt());

        Serial.printf("OpenART mini receive=object %d,x=%d,y=%d\r\n", object_shape, object_x, object_y);
    }

    else if(0 <= receive_str.indexOf("AT+RESULT2"))
    {
        int index1, index2;

        index1 = receive_str.indexOf('=') + 1;
        index2 = receive_str.indexOf(',');
        apriltag_number = (int16_t)(receive_str.substring(index1, index2).toInt());
        
        index1 = index2 + 1;
        index2 = receive_str.indexOf(',', index2 + 1);
        apriltag_x = (int16_t)(receive_str.substring(index1, index2).toInt());
        
        index1 = index2 + 1;
        index2 = receive_str.indexOf('\r', index2 + 1);
        apriltag_y = (int16_t)(receive_str.substring(index1, index2).toInt());

        Serial.printf("OpenART mini receive=apriltag %d,x=%d,y=%d\r\n", apriltag_number, apriltag_x, apriltag_y);
    }

    else if(0 <= receive_str.indexOf("AT+OK"))
    {
        receive_ack_flag = 1;
        Serial.printf("OpenART mini receive=AT+OK\r\n");
    }
    else
    {
        Serial.printf("OpenART mini receive=ERROR\r\n");
    }
}

void OPENART_MINI::send_ready(void)
{
    // 清空接收区
    memset(data, 0, sizeof(data));
    // 清空接受标志位
    receive_ack_flag = 0;
}


uint8_t OPENART_MINI::wait_ack(void)
{
    int16_t time = WAIT_TIME;

    do
    {// 等待接收到数据
        if(receive_ack_flag)
        {
            receive_ack_flag = 0;
            break;
        }
        delay(10);

    }while(time--);

    return receive_ack_flag;
}

void OPENART_MINI::detection_object(uint8_t shape, uint32_t rgb_value)
{
    send_ready();
    Serial.printf("OpenART mini object start\r\n");
    Serial1.printf("AT+OBJECT=%d,0x%lX\r\n", shape, rgb_value);
    wait_ack();
}

void OPENART_MINI::detection_apriltag(void)
{
    send_ready();
    Serial.printf("OpenART mini apriltag start\r\n");
    Serial1.printf("AT+APRILTAG\r\n");
    wait_ack();
}

void OPENART_MINI::detection_stop(void)
{
    send_ready();
    Serial.printf("OpenART mini stop\r\n");
    Serial1.printf("AT+STOP\r\n");
    wait_ack();
    
}

uint8_t OPENART_MINI::get_result(uint8_t type)
{
    uint8_t temp;
    temp = (1 == type) ? object_shape : apriltag_number;
    object_shape = 0;
    apriltag_number = 0;
    return temp;
}

int16_t OPENART_MINI::get_coord_x(uint8_t type)
{
    return (1 == type) ? object_x : apriltag_x;
}

int16_t OPENART_MINI::get_coord_y(uint8_t type)
{
    return (1 == type) ? object_y : apriltag_y;
}


void OPENART_MINI::begin(void)
{
    Serial1.begin(BAUD, SERIAL_8N1, RXPIN, TXPIN);
    Serial1.flush();
    Serial1.setRxFIFOFull(120); // 设置缓冲区满的大小
    Serial1.setRxTimeout(10);   // 设置超时时间为10个字符
    Serial1.onReceive(OPENART_MINI::uart_callback, false);
}

