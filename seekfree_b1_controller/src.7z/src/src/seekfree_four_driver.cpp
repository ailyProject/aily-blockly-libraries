
#include "seekfree_can.h"
#include "seekfree_expansion_ch422.h"
#include "seekfree_imu660ma.h"
#include "seekfree_four_driver.h"

#define MOTOR_ID        (0x01)          // 定义电机产品的ID
#define MOTOR_CAN_ID    (MOTOR_ID << 4) // 电机产品的默认CAN ID



extern CH422        ch422;
extern ESP32C3_CAN  esp32c3_can;
extern IMU660MA     imu660ma;

FOUR_DRIVER::FOUR_DRIVER()
{
    car_dir = 0;
}

FOUR_DRIVER::~FOUR_DRIVER()
{

}

void FOUR_DRIVER::angle_limit(float &angle)
{
    while(angle >= 180)
    {
        angle -= 360;
    }
    while(angle < -180)
    {
        angle += 360;
    }
}


uint8_t FOUR_DRIVER::set_id(uint16_t now_id, uint8_t set_id)
{
    uint8_t result;
    result = esp32c3_can.send_command_halfword(MOTOR_CAN_ID + now_id, 6, 0x100, MOTOR_CAN_ID + set_id, 0);
    return result;
}


uint8_t FOUR_DRIVER::set_speed_ready(uint16_t id)
{
    uint8_t result;
    result = esp32c3_can.send_command(MOTOR_CAN_ID + id, 0x502);
    return result;

}

uint8_t FOUR_DRIVER::set_speed(uint16_t id, uint16_t channel, int16_t speed)
{
    uint8_t result;
    result = esp32c3_can.send_command_halfword(MOTOR_CAN_ID + id, 8, 0x500, channel | (0 << 8), speed);
    return result;
}

uint8_t FOUR_DRIVER::set_distance(uint16_t id, uint16_t channel, int16_t speed, int16_t distance)
{
    uint8_t result;
    result = set_speed(id, channel, speed);
    result = esp32c3_can.send_command_halfword(MOTOR_CAN_ID + id, 8, 0x501, channel | (0 << 8), distance);
    return result;
}

uint8_t FOUR_DRIVER::set_can_res(uint16_t id, uint8_t state)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(MOTOR_CAN_ID + id, 5, 0x101, state, 0, 0, 0);
    return result;
}

uint8_t FOUR_DRIVER::set_duty(uint16_t id, int16_t duty)
{
    uint8_t result;
    memset(&esp32c3_can.send_data, 0, sizeof(esp32c3_can.send_data));
    esp32c3_can.send_data.identifier = MOTOR_CAN_ID + id;
    esp32c3_can.send_data.data_length_code = 4;
    esp32c3_can.send_data.data[0] = BOARD_ID;
    esp32c3_can.send_data.data[1] = 0x04;
    esp32c3_can.send_data.data[2] = duty;
    esp32c3_can.send_data.data[3] = duty >> 8;
    result = esp32c3_can.write();
    // result = set_mode(id, MOTOR_DUTY);
    return result;
}

uint8_t FOUR_DRIVER::clear_encoder(uint16_t id, uint8_t channel)
{
    uint8_t result = 0;
    uint8_t state[4];
    state[0] = channel & 0x01;
    state[1] = channel & 0x02;
    state[2] = channel & 0x04;
    state[3] = channel & 0x08;
    result = esp32c3_can.send_command_byte(MOTOR_CAN_ID + id, 8, 0x509, state[0], state[0], state[0], state[0]);
    return result;
}

uint8_t FOUR_DRIVER::set_reversal(uint16_t id, uint8_t state1, uint8_t state2, uint8_t state3, uint8_t state4)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(MOTOR_CAN_ID + id, 8, 0x508, state1, state2, state3, state4);
    return result;
}

uint8_t FOUR_DRIVER::get_id(uint16_t can_id, uint16_t &read_id)
{
    uint8_t result;
    result = esp32c3_can.send_command(MOTOR_CAN_ID + can_id, 0x000);

    if(0 == result)
    {
        read_id = esp32c3_can.receive_data_struct->id;
    }

    return result;
}


uint8_t FOUR_DRIVER::get_encoder(uint16_t id, uint8_t channel, int32_t &encoder)
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(MOTOR_CAN_ID + id, 5, 0x405, channel, 0, 0, 0);
    if(0 == result)
    {
        encoder = esp32c3_can.receive_data_struct->data_int32;
    }

    return result;
}

uint8_t FOUR_DRIVER::get_version(uint16_t id)
{
    uint8_t result;
    memset(&esp32c3_can.send_data, 0, sizeof(esp32c3_can.send_data));
    memset(&esp32c3_can.receive_data, 0, sizeof(esp32c3_can.receive_data));
    esp32c3_can.send_data.identifier = MOTOR_CAN_ID + id;;
    esp32c3_can.send_data.data_length_code = 2;
    esp32c3_can.send_data.data[0] = BOARD_ID;
    esp32c3_can.send_data.data[1] = 0xA1;
    result = esp32c3_can.write();
    if(0 == result)
    {
        result = esp32c3_can.read();
        main_ver = esp32c3_can.receive_data.data[2];
        midd_ver = esp32c3_can.receive_data.data[3];
        micr_ver = esp32c3_can.receive_data.data[4];
    }

    return result;
}


uint8_t FOUR_DRIVER::set_speed_all(int16_t speed, int16_t turn_speed)
{
    uint8_t result = 0;
    result += set_speed(1, 3, speed - turn_speed);
    result += set_speed(1, 1, speed - turn_speed);
    result += set_speed(1, 2, speed + turn_speed);
    result += set_speed(1, 0, speed + turn_speed);
    result += set_speed_ready(1);
    return result;
}

uint8_t FOUR_DRIVER::clear_encoder_all(void)
{
    uint8_t result = 0;
    result = esp32c3_can.send_command_byte(MOTOR_CAN_ID + 1, 8, 0x509, 1, 1, 1, 1);
    return result;
}

uint8_t FOUR_DRIVER::get_encoder_all(int32_t &distance, uint8_t flag_abs)
{
    uint8_t i;
    uint8_t result = 0;
    int32_t temp_distance;
    distance = 0;

    for(i = 0; 4 > i; i++)
    {
        get_encoder(1, i, temp_distance);
        if(flag_abs)
        {
            distance += abs(temp_distance);
        }
        else
        {
            distance += temp_distance;
        }
    }
    distance /= 4;  // 求平均
    return result;
}

uint8_t FOUR_DRIVER::walk(int32_t distance, int16_t speed)
{
    uint8_t result = 0;
    int32_t distance_walk; // 已经行走的距离
    int16_t speed_diff;
    uint8_t slow_speed = 0;
    float   dir_err;
    float   yaw;

    // 距离极性应该与速度一致
    distance = abs(distance) * speed / abs(speed);
    // 将所有的编码器计数清空
    clear_encoder_all();
    // 当前航向角为方向
    // imu660ma.get_yaw(car_dir);
    do
    {
        // 读取角度
        imu660ma.get_yaw(yaw);

        // 根据角度数据计算调节速度
        dir_err = yaw - car_dir;
        angle_limit(dir_err);

        // 根据误差计算差速数值
        speed_diff = dir_err * 3;
        // 限制差速的大小
        if(100 < abs(speed_diff))
        {
            speed_diff = abs(speed_diff) / speed_diff * 100;
        }
        // 根据调节速度重新设置每个电机的速度
        set_speed_all(speed, speed_diff);
        delay(10);

        // 读取当前已经前进的距离
        get_encoder_all(distance_walk, 0);
        // 转换为厘米
        distance_walk = distance_walk / 54;
        if((abs(distance) - abs(distance_walk) < 30) && (0 == slow_speed))
        {// 距离目的地剩余30厘米，降低速度
            if(50 < abs(speed))
			{
				speed = abs(speed) / speed * 50; // 50厘米/秒
			}
            slow_speed = 1;
        }
    }while(abs(distance_walk) < abs(distance));

    // 速度设置为0
    result += set_speed_all(0, 0);

    return result;
}

uint8_t FOUR_DRIVER::walk2(int32_t distance, int16_t speed)
{
    uint8_t result = 0;
    int32_t distance_walk; // 已经行走的距离
    int16_t speed_diff;
    uint8_t slow_speed = 0;
    float   dir_err;
    float   yaw;

    // 距离极性应该与速度一致
    distance = abs(distance) * speed / abs(speed);
    // 将所有的编码器计数清空
    clear_encoder_all();

    // 当前航向角为方向
    // imu660ma.get_yaw(car_dir);
    do
    {
        // 读取角度
        imu660ma.get_yaw(yaw);
        // 根据角度数据计算调节速度
        dir_err = yaw - car_dir;
        angle_limit(dir_err);

        // 根据误差计算差速数值
        speed_diff = dir_err * 4;
        // 限制差速的大小
        if(100 < abs(speed_diff))
        {
            speed_diff = abs(speed_diff) / speed_diff * 100;
        }
        // 根据调节速度重新设置每个电机的速度
        set_speed(1, 0, speed + speed_diff);
        set_speed(1, 3, speed - speed_diff);
        set_speed(1, 1, -speed - speed_diff);
        set_speed(1, 2, -speed + speed_diff);
        set_speed_ready(1);
        delay(10);

        // 读取当前已经前进的距离
        get_encoder_all(distance_walk, 1);
        // 转换为厘米
        distance_walk = distance_walk / 54;
        if((abs(distance) - abs(distance_walk) < 10) && (0 == slow_speed))
        {// 距离目的地剩余10厘米，降低速度
            if(50 < abs(speed))
            {
                speed = abs(speed) / speed * 50; // 50厘米/秒
            }
            slow_speed = 1;
        }
    }while(abs(distance_walk) < abs(distance));

    // 速度设置为0
    result += set_speed_all(0, 0);

    return result;
}

uint8_t FOUR_DRIVER::move(uint8_t direction, int16_t speed, int32_t distance)
{
    uint8_t result = 1;
    distance = abs(distance);
    speed = abs(speed);
    if((1 == direction) || (2 == direction))
    {
        speed = (2 == direction) ? -speed : speed;
        result = walk(distance, speed);
    }
    else if((3 == direction) || (4 == direction))
    {
        speed = (4 == direction) ? -speed : speed;
        result = walk2(distance, speed);
    }
    return result;
}
uint8_t FOUR_DRIVER::turn(int16_t angle, uint16_t speed)
{
    uint8_t result = 0;
    int16_t except_speed;
    float   angle_err;
    uint16_t delay_num;
    float   yaw;

    car_dir += angle;
    angle_limit(car_dir);

    delay_num = 0;

    do
    {
        // 读取角度
        imu660ma.get_yaw(yaw);
        // 正数左转 反之右转
        angle_err = car_dir - yaw;
        angle_limit(angle_err);

        // 判断是否接近目标角度
        delay_num = (2.0f > abs(yaw - car_dir)) ? (delay_num + 1) : 0;
        if(50 < delay_num)
        {// 确保稳定一段时间之后再结束转向的动作
            break;
        }
        // 基于误差计算转向速度，使用一次项与二次项实现非线性速度变化
        except_speed = angle_err * 2 + angle_err * abs(angle_err) / 100;
        if(speed < abs(except_speed))
        {// 最大速度限制
            except_speed = speed * except_speed / abs(except_speed);
        }
        else if(5 > abs(except_speed))
        {// 最小速度限制，避免速度设置过小导致无法转动
            except_speed = 5 * except_speed / abs(except_speed);
        }
        set_speed_all(0, -except_speed);

        delay(1);
    }while(1);

    set_speed_all(0, 0);

    return result;
}

uint8_t FOUR_DRIVER::track(int16_t x, int16_t y)
{
    static int16_t track_num;

    static int16_t temp_x_last;
    static int16_t temp_y_last;
    int16_t out_x, out_y;
    uint8_t return_state = 0;
    int16_t speed_motor[4];

    out_x = x / 5 + (x - temp_x_last) / 10;
    out_y = y / 5 + (y - temp_y_last) / 10;

    speed_motor[0] = out_y;
    speed_motor[1] = out_y;
    speed_motor[2] = out_y;
    speed_motor[3] = out_y;
    speed_motor[0] += -out_x;
    speed_motor[1] += +out_x;
    speed_motor[2] += +out_x;
    speed_motor[3] += -out_x;

    set_speed(1, 0, speed_motor[0]);
    set_speed(1, 1, speed_motor[1]);
    set_speed(1, 2, speed_motor[2]);
    set_speed(1, 3, speed_motor[3]);
    set_speed_ready(1);
    
    temp_x_last = x;
    temp_y_last = y;

    if((4 > x) && (4 > y))
    {
        track_num++;
    }
    else
    {
        track_num = 0;
    }

    if(5 < track_num)
    {
        return_state = 1;
        track_num = 0;
        temp_x_last = 0;
        temp_y_last = 0;
        set_speed_all(0, 0);
    }

    return return_state;
}

uint8_t FOUR_DRIVER::begin(uint8_t power_index)
{
    uint16_t read_id;
    uint8_t return_state;
	static uint8_t id_num = 0;
    car_dir = 0;                // 车头角度设置为0
    return_state = 0;
    ch422.set_power(power_index, 1);  // 打开电源
    delay(200);             // 打开电源之后务必延时，等待设备启动
    read_id = 0;
    get_id(0, read_id);     // 获取产品ID
    if(MOTOR_CAN_ID == read_id)
    {
		id_num++;
		
        set_id(0, id_num);
        set_can_res(id_num, 0);

        // 设置1号、2号电机反转
        set_reversal(id_num, 1, 0, 1, 0);
    }
    else
    {
        return_state = 1;
        ch422.set_power(power_index, 0);// 关闭电源
    }
    
    return return_state;        // 返回状态
}