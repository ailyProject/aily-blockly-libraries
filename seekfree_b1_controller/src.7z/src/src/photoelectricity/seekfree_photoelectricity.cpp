#include "seekfree_can.h"
#include "seekfree_expansion_ch422.h"
#include "seekfree_photoelectricity.h"

#define PHOTO_ID          (0X03)            // 定义灰度传感器产品的ID
#define PHOTO_CAN_ID      (PHOTO_ID << 4)   // 灰度传感器产品的默认CAN ID

extern CH422        ch422;
extern ESP32C3_CAN esp32c3_can;



uint8_t PHOTOELECTRICITY::set_id(uint16_t now_id, uint8_t set_id)
{
    uint8_t result;
    result = esp32c3_can.send_command_halfword(PHOTO_CAN_ID + now_id, 6, 0x100, PHOTO_CAN_ID + set_id, 0);
    return result;
}

uint8_t PHOTOELECTRICITY::set_black(uint16_t id)
{
    uint8_t result;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x300);
    return result;
}

uint8_t PHOTOELECTRICITY::set_white(uint16_t id)
{
    uint8_t result;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x301);
    return result;
}

uint8_t PHOTOELECTRICITY::get_id(uint16_t id, uint16_t &read_id)
{
    uint8_t result;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x000);
    if(0 == result)
    {
        read_id = esp32c3_can.receive_data_struct->id;
    }
    return result;
}




uint8_t PHOTOELECTRICITY::get_position (uint16_t id, int16_t &position)    // 获取偏差
{
    uint8_t result;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x200);
    if(0 == result)
    {
        position = esp32c3_can.receive_data_struct->data_int16[0];
    }

    return result;
}

uint8_t PHOTOELECTRICITY::get_value (uint16_t id, uint8_t channel, int16_t &value)    // 获取偏差
{
    uint8_t result;
    result = esp32c3_can.send_command_byte(PHOTO_CAN_ID + id, 5, 0x201, channel, 0, 0, 0);
    if(0 == result)
    {
        value = esp32c3_can.receive_data_struct->data_int16[0];
    }

    return result;
}

uint8_t PHOTOELECTRICITY::get_value_bin (uint16_t id, uint8_t channel, uint8_t &value)    // 获取偏差
{
    uint8_t result;
    uint16_t temp;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x202);
    if(0 == result)
    {
        temp = esp32c3_can.receive_data_struct->data_halfword[0];
        value = (temp >> channel) & 0x01;
    }

    return result;
}

uint8_t PHOTOELECTRICITY::get_black_num (uint16_t id, uint8_t &value)    // 获取黑点数量
{
    uint8_t result;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x202);
    if(0 == result)
    {
        value = esp32c3_can.receive_data_struct->data_byte[2];
    }

    return result;
}

uint8_t PHOTOELECTRICITY::get_white_num (uint16_t id, uint8_t &value)    // 获取白点数量
{
    uint8_t result;
    result = esp32c3_can.send_command(PHOTO_CAN_ID + id, 0x202);
    if(0 == result)
    {
        value = esp32c3_can.receive_data_struct->data_byte[3];
    }

    return result;
}

uint8_t PHOTOELECTRICITY::begin(uint8_t power_index)
{
    uint8_t  state = 1;
    uint16_t read_id;
	static uint8_t id_num = 0;

    ch422.set_power(power_index, 1);       
    delay(200); // 打开电源之后务必延时，等待设备启动
    get_id(0, read_id);
    if(PHOTO_CAN_ID == read_id)
    {
		id_num++;
        set_id(0, id_num);
        state = 0;
    }
    else
    {
        ch422.set_power(power_index, 0);
    }

    return state;

}






