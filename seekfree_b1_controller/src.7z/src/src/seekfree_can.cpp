

#include "seekfree_can.h"
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
// Pins used to connect to CAN bus transceiver:
#define RX_PIN 20
#define TX_PIN 21

#define POLLING_RATE_MS 3000

ESP32C3_CAN::ESP32C3_CAN()
{
    driver_installed = 0;
}

ESP32C3_CAN::~ESP32C3_CAN()
{
    driver_installed = 0;
}

uint8_t ESP32C3_CAN::state(void)
{
    return driver_installed;
}

uint8_t ESP32C3_CAN::write (void)
{    
    uint8_t state = 1;
    if(driver_installed)
    {
        if (twai_transmit(&send_data, pdMS_TO_TICKS(POLLING_RATE_MS)) == ESP_OK) 
        {
            state = 0;
        }
    }
    
    return state;
}

uint8_t ESP32C3_CAN::read (void)
{
    uint8_t state = 1;
    uint32_t alerts_triggered;
    twai_status_info_t twaistatus;

    if(driver_installed)
    {
        twai_read_alerts(&alerts_triggered, pdMS_TO_TICKS(POLLING_RATE_MS));
        twai_get_status_info(&twaistatus);
        
        if (alerts_triggered & TWAI_ALERT_RX_DATA) 
        {
            state = 0;
            twai_receive(&receive_data, 0);
        }
    }
    
    return state;
}

uint8_t ESP32C3_CAN::send_command (uint16_t can_id, uint16_t cmd)
{
    uint8_t state;

    send_data.identifier = can_id;
    send_data.data_length_code = 4;

    send_data_struct->cmd = cmd;
    send_data_struct->id  = BOARD_ID;

    state = write();
    if(0 == state)
    {
        state = read();
    }

    return state;
}

uint8_t ESP32C3_CAN::send_command_byte (uint16_t can_id, uint8_t length, uint16_t cmd, uint8_t data1, uint8_t data2, uint8_t data3, uint8_t data4)
{
    uint8_t state;
    send_data.identifier = can_id;
    send_data.data_length_code = length;

    send_data_struct->cmd = cmd;
    send_data_struct->id  = BOARD_ID;
    send_data_struct->data_byte[0] = data1;
    send_data_struct->data_byte[1] = data2;
    send_data_struct->data_byte[2] = data3;
    send_data_struct->data_byte[3] = data4;

    state = write();
    if(0 == state)
    {
        state = read();
    }

    return state;
}

uint8_t ESP32C3_CAN::send_command_halfword (uint16_t can_id, uint8_t length, uint16_t cmd, uint16_t data1, uint16_t data2)
{
    uint8_t state;
    send_data.identifier = can_id;
    send_data.data_length_code = length;

    send_data_struct->cmd = cmd;
    send_data_struct->id  = BOARD_ID;
    send_data_struct->data_halfword[0] = data1;
    send_data_struct->data_halfword[1] = data2;

    state = write();
    if(0 == state)
    {
        state = read();
    }

    return state;
}


uint8_t ESP32C3_CAN::send_command_float (uint16_t can_id, uint16_t cmd, float data1)
{
    uint8_t state;
    send_data.identifier = can_id;
    send_data.data_length_code = 8;

    send_data_struct->cmd = cmd;
    send_data_struct->id  = BOARD_ID;
    send_data_struct->data_float = data1;

    state = write();
    if(0 == state)
    {
        state = read();
    }

    return state;
}

uint8_t ESP32C3_CAN::error (void)
{
    // Check if alert happened
    uint32_t alerts_triggered;
    twai_status_info_t twaistatus;

    if(driver_installed)
    {
        twai_read_alerts(&alerts_triggered, pdMS_TO_TICKS(POLLING_RATE_MS));
        twai_get_status_info(&twaistatus);

        // Handle alerts
        if (alerts_triggered & TWAI_ALERT_ERR_PASS) {
            Serial.println("Alert: TWAI controller has become error passive.");
        }
        if (alerts_triggered & TWAI_ALERT_BUS_ERROR) {
            Serial.println("Alert: A (Bit, Stuff, CRC, Form, ACK) error has occurred on the bus.");
            Serial.printf("Bus error count: %lu\n", twaistatus.bus_error_count);
        }
        if (alerts_triggered & TWAI_ALERT_TX_FAILED) {
            Serial.println("Alert: The Transmission failed.");
            Serial.printf("TX buffered: %lu\t", twaistatus.msgs_to_tx);
            Serial.printf("TX error: %lu\t", twaistatus.tx_error_counter);
            Serial.printf("TX failed: %lu\n", twaistatus.tx_failed_count);
        }
        if (alerts_triggered & TWAI_ALERT_TX_SUCCESS) {
            Serial.println("Alert: The Transmission was successful.");
            Serial.printf("TX buffered: %lu\t", twaistatus.msgs_to_tx);
        }
    }
    return 0;
}


void ESP32C3_CAN::begin(void)
{
    send_data_struct    = (seekfree_can_struct *)send_data.data;
    receive_data_struct = (seekfree_can_struct *)receive_data.data;

    // Initialize configuration structures using macro initializers
    twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT((gpio_num_t)TX_PIN, (gpio_num_t)RX_PIN, TWAI_MODE_NORMAL);
    twai_timing_config_t t_config = TWAI_TIMING_CONFIG_1MBITS();  //Look in the api-reference for other speed sets.
    twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

    if(0 == driver_installed)
    {
        do
        {
            // Install TWAI driver
            if (twai_driver_install(&g_config, &t_config, &f_config) == ESP_OK) 
            {
                Serial.println("Driver installed");
            } 
            else 
            {
                Serial.println("Failed to install driver");
                break;
            }

            // Start TWAI driver
            if (twai_start() == ESP_OK) 
            {
                Serial.println("Driver started");
            } 
            else 
            {
                Serial.println("Failed to start driver");
                break;
            }

            // Reconfigure alerts to detect TX alerts and Bus-Off errors TWAI_ALERT_TX_SUCCESS
            uint32_t alerts_to_enable = TWAI_ALERT_RX_DATA | TWAI_ALERT_RX_QUEUE_FULL | TWAI_ALERT_ERR_PASS | TWAI_ALERT_BUS_ERROR;
            if (twai_reconfigure_alerts(alerts_to_enable, NULL) == ESP_OK) 
            {
                Serial.println("CAN Alerts reconfigured");
            } 
            else 
            {
                Serial.println("Failed to reconfigure alerts");
                break;
            }
            // TWAI driver is now successfully installed and started
            driver_installed = true;
        }while(0);
    }
}
