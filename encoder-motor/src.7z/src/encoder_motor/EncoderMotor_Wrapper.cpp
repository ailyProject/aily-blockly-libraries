/**
 * @file EncoderMotor_Wrapper.cpp
 * @brief 编码电机封装库实现
 */

#include "EncoderMotor_Wrapper.h"

// ========== 静态成员初始化 ==========
bool EncoderMotor_Manager::initialized_ = false;
uint32_t EncoderMotor_Manager::ppr_ = DEFAULT_ENCODER_PPR;
uint32_t EncoderMotor_Manager::reduction_ = DEFAULT_ENCODER_REDUCTION;


// ========== 全局编码电机对象（指针，初始为nullptr） ==========
em::EncoderMotor* g_encoder_motor_0 = nullptr;
em::EncoderMotor* g_encoder_motor_1 = nullptr;

// ========== 全局管理器实例 ==========
EncoderMotor_Manager EncoderMotor;

// ========== 封装类实现 ==========
void EncoderMotor_Manager::initMotor(uint8_t motor_id,
                                    int pin_positive, int pin_negative,
                                    int pin_encoder_a, int pin_encoder_b,
                                    uint32_t ppr, uint32_t reduction,
                                    int ledc_ch_pos, int ledc_ch_neg) {
    ppr_ = ppr;
    reduction_ = reduction;
    
    em::EncoderMotor** motor_ptr = (motor_id == 0) ? &g_encoder_motor_0 : &g_encoder_motor_1;
    
    // 如果电机对象已存在，先删除
    if (*motor_ptr != nullptr) {
        delete *motor_ptr;
        *motor_ptr = nullptr;
    }
    
    // 动态创建电机对象
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
    *motor_ptr = new em::EncoderMotor(
        pin_positive,
        pin_negative,
        pin_encoder_a,
        pin_encoder_b,
        ppr,
        reduction,
        ENCODER_PHASE_RELATION
    );
#else
    // ESP32 Arduino Core < 3.0 需要指定LEDC通道
    if (ledc_ch_pos < 0) ledc_ch_pos = (motor_id == 0) ? E0_MOTOR_LEDC_CH_POS : E1_MOTOR_LEDC_CH_POS;
    if (ledc_ch_neg < 0) ledc_ch_neg = (motor_id == 0) ? E0_MOTOR_LEDC_CH_NEG : E1_MOTOR_LEDC_CH_NEG;
    
    *motor_ptr = new em::EncoderMotor(
        pin_positive,
        ledc_ch_pos,
        pin_negative,
        ledc_ch_neg,
        pin_encoder_a,
        pin_encoder_b,
        ppr,
        reduction,
        ENCODER_PHASE_RELATION
    );
#endif
    
    // 初始化电机
    if (*motor_ptr != nullptr) {
        (*motor_ptr)->Init();
        (*motor_ptr)->SetSpeedPid(DEFAULT_PID_P, DEFAULT_PID_I, DEFAULT_PID_D);
    }
}

void EncoderMotor_Manager::begin(uint32_t ppr, uint32_t reduction) {
    if (!initialized_) {
        ppr_ = ppr;
        reduction_ = reduction;
        
        // 使用硬编码默认引脚初始化两个电机
        // 电机0: GPIO12(+), GPIO14(-), GPIO35(A), GPIO36(B)
        initMotor(0, 12, 14, 35, 36, ppr, reduction);
        // 电机1: GPIO15(+), GPIO17(-), GPIO34(A), GPIO39(B)
        initMotor(1, 15, 17, 34, 39, ppr, reduction);
        
        initialized_ = true;
    }
}

void EncoderMotor_Manager::setAllPID(float p, float i, float d) {
    if (g_encoder_motor_0 != nullptr) g_encoder_motor_0->SetSpeedPid(p, i, d);
    if (g_encoder_motor_1 != nullptr) g_encoder_motor_1->SetSpeedPid(p, i, d);
}

void EncoderMotor_Manager::stopAll() {
    if (g_encoder_motor_0 != nullptr) g_encoder_motor_0->Stop();
    if (g_encoder_motor_1 != nullptr) g_encoder_motor_1->Stop();
}

void EncoderMotor_Manager::resetAllPulseCount() {
    if (g_encoder_motor_0 != nullptr) g_encoder_motor_0->ResetPulseCount();
    if (g_encoder_motor_1 != nullptr) g_encoder_motor_1->ResetPulseCount();
}

em::EncoderMotor* EncoderMotor_Manager::getMotor(uint8_t motor_id) {
    if (motor_id == 0) {
        return g_encoder_motor_0;
    } else if (motor_id == 1) {
        return g_encoder_motor_1;
    }
    return nullptr;
}

float EncoderMotor_Manager::pulseToDegree(int64_t pulse_count) {
    return pulse_count * 360.0 / (ppr_ * reduction_);
}
