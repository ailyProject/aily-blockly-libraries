
/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file lv_switch_properties.c
 */

#include "../switch/lv_switch.h"

#if LV_USE_OBJ_PROPERTY && LV_USE_OBJ_PROPERTY_NAME

#if LV_USE_SWITCH
/**
 * Switch widget property names, name must be in order.
 * Generated code from properties.py
 */
/* *INDENT-OFF* */
const lv_property_name_t lv_switch_property_names[1] = {
    {"orientation",            LV_PROPERTY_SWITCH_ORIENTATION,},
};
#endif /*LV_USE_SWITCH*/

/* *INDENT-ON* */
#endif
