
/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file lv_tabview_properties.c
 */

#include "../tabview/lv_tabview.h"

#if LV_USE_OBJ_PROPERTY && LV_USE_OBJ_PROPERTY_NAME

#if LV_USE_TABVIEW
/**
 * Tabview widget property names, name must be in order.
 * Generated code from properties.py
 */
/* *INDENT-OFF* */
const lv_property_name_t lv_tabview_property_names[2] = {
    {"tab_active",             LV_PROPERTY_TABVIEW_TAB_ACTIVE,},
    {"tab_bar_position",       LV_PROPERTY_TABVIEW_TAB_BAR_POSITION,},
};
#endif /*LV_USE_TABVIEW*/

/* *INDENT-ON* */
#endif
