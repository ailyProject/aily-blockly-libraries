
/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file lv_spinner_properties.c
 */

#include "../spinner/lv_spinner.h"

#if LV_USE_OBJ_PROPERTY && LV_USE_OBJ_PROPERTY_NAME

#if LV_USE_SPINNER
/**
 * Spinner widget property names, name must be in order.
 * Generated code from properties.py
 */
/* *INDENT-OFF* */
const lv_property_name_t lv_spinner_property_names[2] = {
    {"anim_duration",          LV_PROPERTY_SPINNER_ANIM_DURATION,},
    {"arc_sweep",              LV_PROPERTY_SPINNER_ARC_SWEEP,},
};
#endif /*LV_USE_SPINNER*/

/* *INDENT-ON* */
#endif
