
/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file lv_menu_properties.c
 */

#include "../menu/lv_menu.h"

#if LV_USE_OBJ_PROPERTY && LV_USE_OBJ_PROPERTY_NAME

#if LV_USE_MENU
/**
 * Menu widget property names, name must be in order.
 * Generated code from properties.py
 */
/* *INDENT-OFF* */
const lv_property_name_t lv_menu_property_names[2] = {
    {"mode_header",            LV_PROPERTY_MENU_MODE_HEADER,},
    {"mode_root_back_button",  LV_PROPERTY_MENU_MODE_ROOT_BACK_BUTTON,},
};
#endif /*LV_USE_MENU*/

/* *INDENT-ON* */
#endif
