
/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file lv_checkbox_properties.c
 */

#include "../checkbox/lv_checkbox.h"

#if LV_USE_OBJ_PROPERTY && LV_USE_OBJ_PROPERTY_NAME

#if LV_USE_CHECKBOX
/**
 * Checkbox widget property names, name must be in order.
 * Generated code from properties.py
 */
/* *INDENT-OFF* */
const lv_property_name_t lv_checkbox_property_names[1] = {
    {"text",                   LV_PROPERTY_CHECKBOX_TEXT,},
};
#endif /*LV_USE_CHECKBOX*/

/* *INDENT-ON* */
#endif
