
/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file lv_line_properties.c
 */

#include "../line/lv_line.h"

#if LV_USE_OBJ_PROPERTY && LV_USE_OBJ_PROPERTY_NAME

#if LV_USE_LINE
/**
 * Line widget property names, name must be in order.
 * Generated code from properties.py
 */
/* *INDENT-OFF* */
const lv_property_name_t lv_line_property_names[1] = {
    {"y_invert",               LV_PROPERTY_LINE_Y_INVERT,},
};
#endif /*LV_USE_LINE*/

/* *INDENT-ON* */
#endif
