#pragma once

#include "../../../../lv_conf_internal.h"
#include LV_STDINT_INCLUDE

typedef intptr_t ssize_t;
