
// This is the command sequence that rotates the ED2208 driver coordinate frame


