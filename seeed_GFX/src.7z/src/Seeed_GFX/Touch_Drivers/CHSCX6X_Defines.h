#define CHSC6X_I2C_ID 0x2e
#define CHSC6X_MAX_POINTS_NUM 1
#define CHSC6X_READ_POINT_LEN 5

#ifndef TOUCH_WIRE
#define TOUCH_WIRE Wire
#endif