#include "Esp_I2S.h"
#include <math.h>

EspI2S::EspI2S(void) {
    bclk_pin = 41;
    ws_pin = 42;
    din_pin = 2;
    sampleBuffer = nullptr;
    initialized = false;
    avgLevel = 0;
    peakLevel = 0;
    rmsLevel = 0;
    noiseFloor = 100;
    totalSamples = 0;

    // PDM初始化 - 修正缩进
    pdmInitialized = false;
    micType = MIC_TYPE_PCM;
    pdm_clk_pin = 41;
    pdm_data_pin = 2;

    // 🔧 添加新API初始化
    rx_chan = NULL;
    tx_chan = NULL;

    // 录制相关初始化
    recording = false;
    recordedBytes = 0;
    recordStartTime = 0;
    maxRecordDuration = 0;
    currentFileName = "";
    
    // 添加功放相关初始化
    speaker_bclk = 39;
    speaker_lrc = 40;
    speaker_dout = 38;
    speakerInitialized = false;
    playingAudio = false;
    volume = 0.3;  // 默认音量30%
    
    // 音乐播放初始化
    currentMelody = nullptr;
    melodyLength = 0;
    currentNoteIndex = 0;
    noteStartTime = 0;
    melodyPlaying = false;
    melodyLoop = false;
    phase = 0.0;
    
    // WAV播放初始化
    playingWav = false;
    paused = false;
    playbackStartTime = 0;
    wavDataSize = 0;
    wavSampleRate = 0;
    wavChannels = 0;
    wavBitsPerSample = 0;
    playbackPosition = 0;
}

EspI2S::~EspI2S() {
    if (melodyPlaying) {
        stopMelody();
    }
    if (playingWav) {
        stopPlayback();
    }
    endSpeaker();
    endPDM();  // 添加这行
    end();
}

bool EspI2S::begin(int sampleRate, int bufferSize, int bclk, int ws, int din) {
    sample_rate = sampleRate;
    buffer_size = bufferSize;
    bclk_pin = bclk;
    ws_pin = ws;
    din_pin = din;
    micType = MIC_TYPE_PCM;

    // 分配缓冲区
    sampleBuffer = (int16_t*)malloc(buffer_size * sizeof(int16_t));
    if (!sampleBuffer) {
        Serial.println("❌ 内存分配失败!");
        return false;
    }

    // 🔧 新API: 通道配置
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    
    // 🔧 新API: 创建接收通道
    esp_err_t err = i2s_new_channel(&chan_cfg, NULL, &rx_chan);
    if (err != ESP_OK) {
        Serial.printf("❌ I2S通道创建失败: %s\n", esp_err_to_name(err));
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }

    // 🔧 新API: 标准I2S配置
    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(sample_rate),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = (gpio_num_t)bclk_pin,
            .ws = (gpio_num_t)ws_pin,
            .dout = I2S_GPIO_UNUSED,
            .din = (gpio_num_t)din_pin,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    // 🔧 新API: 初始化标准模式
    err = i2s_channel_init_std_mode(rx_chan, &std_cfg);
    if (err != ESP_OK) {
        Serial.printf("❌ I2S标准模式初始化失败: %s\n", esp_err_to_name(err));
        i2s_del_channel(rx_chan);
        rx_chan = NULL;
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }

    // 🔧 新API: 启用通道
    err = i2s_channel_enable(rx_chan);
    if (err != ESP_OK) {
        Serial.printf("❌ I2S通道启用失败: %s\n", esp_err_to_name(err));
        i2s_del_channel(rx_chan);
        rx_chan = NULL;
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }

    initialized = true;
    Serial.println("✅ EspI2S 初始化成功（新API）");
    Serial.printf("📍 引脚配置: BCLK=%d, WS=%d, DIN=%d\n", bclk_pin, ws_pin, din_pin);
    Serial.printf("🎵 采样率: %d Hz, 缓冲区: %d 样本\n", sample_rate, buffer_size);

    return true;
}

void EspI2S::end() {
    if (initialized && rx_chan) {
        // 🔧 新API: 禁用和删除通道
        i2s_channel_disable(rx_chan);
        i2s_del_channel(rx_chan);
        rx_chan = NULL;
        initialized = false;
        pdmInitialized = false;
        Serial.println("🔌 I2S驱动已卸载（新API）");
    }
    if (sampleBuffer) {
        free(sampleBuffer);
        sampleBuffer = nullptr;
    }
}

bool EspI2S::isReady() {
    return initialized && (sampleBuffer != nullptr);
}

bool EspI2S::readSamples() {
    if (micType == MIC_TYPE_PDM) {
        return readPDMSamples();
    }

    if (!initialized || !rx_chan || !sampleBuffer) {
        return false;
    }
    
    size_t bytesRead;
    // 🔧 新API: 使用 i2s_channel_read
    esp_err_t result = i2s_channel_read(rx_chan, sampleBuffer, 
                                       buffer_size * sizeof(int16_t), 
                                       &bytesRead, pdMS_TO_TICKS(100));
    
    if (result != ESP_OK) {
        Serial.printf("⚠️ I2S读取错误: %s\n", esp_err_to_name(result));
        return false;
    }
    
    // 计算统计数据
    int32_t sum = 0;
    int64_t sumSquares = 0;
    int16_t maxVal = 0;
    int16_t minVal = 32767;
    
    for (int i = 0; i < buffer_size; i++) {
        int16_t sample = abs(sampleBuffer[i]);
        sum += sample;
        sumSquares += (int64_t)sample * sample;
        
        if (sample > maxVal) maxVal = sample;
        if (sampleBuffer[i] < minVal) minVal = sampleBuffer[i];
    }
    
    avgLevel = (float)sum / buffer_size;
    peakLevel = maxVal;
    rmsLevel = sqrt((float)sumSquares / buffer_size);
    totalSamples += buffer_size;
    
    return true;
}

float EspI2S::getAverageLevel() {
    return avgLevel;
}

float EspI2S::getPeakLevel() {
    return peakLevel;
}

float EspI2S::getRMSLevel() {
    return rmsLevel;
}

float EspI2S::getDecibels() {
    if (rmsLevel <= 0) return -96.0;
    return 20.0 * log10(rmsLevel / 32767.0);
}

float EspI2S::getPercentage() {
    return (rmsLevel / 32767.0) * 100.0;
}

bool EspI2S::isSoundDetected(int threshold) {
    return avgLevel > threshold;
}

String EspI2S::getQualityLevel() {
    if (avgLevel < 100) return "🔇静音";
    else if (avgLevel < 500) return "🔉微弱";
    else if (avgLevel < 2000) return "🔊正常";
    else if (avgLevel < 8000) return "📢较强";
    else if (avgLevel < 20000) return "🔥很强";
    else return "🚨过载";
}

float EspI2S::getSNR() {
    if (noiseFloor <= 0) return 0;
    return 20.0 * log10(rmsLevel / noiseFloor);
}

float EspI2S::getLowFreqEnergy() {
    if (!sampleBuffer) return 0;
    
    long energy = 0;
    int samples = buffer_size / 3;
    for (int i = 0; i < samples; i++) {
        energy += abs(sampleBuffer[i]);
    }
    return (float)energy / samples;
}

float EspI2S::getMidFreqEnergy() {
    if (!sampleBuffer) return 0;
    
    long energy = 0;
    int start = buffer_size / 3;
    int end = 2 * buffer_size / 3;
    for (int i = start; i < end; i++) {
        energy += abs(sampleBuffer[i]);
    }
    return (float)energy / (end - start);
}

float EspI2S::getHighFreqEnergy() {
    if (!sampleBuffer) return 0;
    
    long energy = 0;
    int start = 2 * buffer_size / 3;
    for (int i = start; i < buffer_size; i++) {
        energy += abs(sampleBuffer[i]);
    }
    return (float)energy / (buffer_size - start);
}

void EspI2S::setThreshold(int threshold) {
    noiseFloor = threshold;
    Serial.printf("🔧 噪声阈值设置为: %d LSB\n", threshold);
}

void EspI2S::calibrateNoiseFloor() {
    if (!initialized) return;
    
    Serial.println("🔧 开始噪声基准校准...");
    Serial.printf("   麦克风类型: %s\n", getMicTypeString().c_str());  // 添加这行
    Serial.println("   请保持环境安静 3 秒...");
    
    float totalNoise = 0;
    int measurements = 0;
    
    for (int i = 0; i < 30; i++) { // 30次测量，每次100ms
        if (readSamples()) {
            totalNoise += avgLevel;
            measurements++;
        }
        delay(100);
    }
    
    if (measurements > 0) {
        noiseFloor = totalNoise / measurements;
        Serial.printf("✅ 噪声基准校准完成: %.1f LSB\n", noiseFloor);
    } else {
        Serial.println("❌ 校准失败");
    }
}

String EspI2S::getStatusString() {
    if (!initialized) return "未初始化";
    
    String status = "📊 EspI2S 状态:\n";
    status += "   🔌 状态: " + String(initialized ? "正常" : "未初始化") + "\n";
    status += "   🎤 麦克风类型: " + getMicTypeString() + "\n";  // 添加这行
    
    if (micType == MIC_TYPE_PDM) {
        status += "   📍 PDM引脚: CLK=" + String(pdm_clk_pin) + ", DATA=" + String(pdm_data_pin) + "\n";
    } else {
        status += "   📍 PCM引脚: BCLK=" + String(bclk_pin) + ", WS=" + String(ws_pin) + ", DIN=" + String(din_pin) + "\n";
    }
    
    status += "   🎵 采样率: " + String(sample_rate) + " Hz\n";
    status += "   📦 缓冲区: " + String(buffer_size) + " 样本\n";
    status += "   📈 平均电平: " + String(avgLevel, 1) + " LSB\n";
    status += "   🏔️ 峰值电平: " + String(peakLevel, 1) + " LSB\n";
    status += "   📊 RMS电平: " + String(rmsLevel, 1) + " LSB\n";
    status += "   🔊 分贝值: " + String(getDecibels(), 1) + " dBFS\n";
    status += "   📏 百分比: " + String(getPercentage(), 1) + "%\n";
    status += "   🎯 音质: " + getQualityLevel() + "\n";
    status += "   📊 信噪比: " + String(getSNR(), 1) + " dB\n";
    status += "   🔢 总样本: " + String(totalSamples);
    
    return status;
}

unsigned long EspI2S::getSampleCount() {
    return totalSamples;
}

// 原始数据访问方法
int16_t* EspI2S::getRawBuffer() {
    return sampleBuffer;
}

int EspI2S::getBufferSize() {
    return buffer_size;
}

// 录制功能
bool EspI2S::startRecording(String fileName, unsigned long duration) {
    if (recording) {
        Serial.println("⚠️ 已在录制中");
        return false;
    }
    
    if (!initialized) {
        Serial.println("❌ I2S未初始化");
        return false;
    }
    
    // 生成文件名
    if (fileName == "") {
        currentFileName = generateFileName();
    } else {
        currentFileName = fileName;
        if (!currentFileName.endsWith(".wav")) {
            currentFileName += ".wav";
        }
    }
    
    // 创建文件
    audioFile = SD.open("/" + currentFileName, FILE_WRITE);
    if (!audioFile) {
        Serial.println("❌ 无法创建音频文件");
        return false;
    }
    
    // 设置录制参数
    maxRecordDuration = duration;
    recordedBytes = 0;
    recordStartTime = millis();
    
    // 写入WAV头
    writeWavHeader(audioFile, sample_rate, 16, 1);
    
    recording = true;
    
    Serial.println("🎙️ 开始录制音频");
    Serial.printf("🎤 麦克风类型: %s\n", getMicTypeString().c_str());  // 添加这行
    Serial.printf("📁 文件: %s\n", currentFileName.c_str());
    if (maxRecordDuration > 0) {
        Serial.printf("⏱️ 最大时长: %.1f 秒\n", maxRecordDuration / 1000.0);
    }
    
    return true;
}

bool EspI2S::stopRecording() {
    if (!recording) {
        return false;
    }
    
    recording = false;
    
    // 更新WAV头
    updateWavHeader(audioFile);
    
    // 关闭文件
    audioFile.close();
    
    unsigned long recordTime = millis() - recordStartTime;
    Serial.println("🛑 录制完成");
    Serial.printf("📁 文件: %s\n", currentFileName.c_str());
    Serial.printf("⏱️ 时长: %.2f 秒\n", recordTime / 1000.0);
    Serial.printf("💾 大小: %.1f KB\n", (recordedBytes + 44) / 1024.0);
    
    return true;
}

bool EspI2S::isRecording() {
    return recording;
}

void EspI2S::updateRecording() {
    if (!recording) return;
    
    // 检查最大录制时长
    if (maxRecordDuration > 0 && (millis() - recordStartTime) >= maxRecordDuration) {
        Serial.println("⏰ 达到最大录制时长，自动停止");
        stopRecording();
        return;
    }
    
    // 读取音频数据并写入文件
    if (readSamples()) {
        writeAudioData();
    }
}

bool EspI2S::writeAudioData() {
    if (!recording || !audioFile) return false;
    
    size_t bytesToWrite = buffer_size * sizeof(int16_t);
    size_t written = audioFile.write((uint8_t*)sampleBuffer, bytesToWrite);
    
    if (written == bytesToWrite) {
        recordedBytes += written;
        return true;
    } else {
        Serial.println("⚠️ 写入音频数据失败");
        return false;
    }
}

void EspI2S::writeWavHeader(File &file, uint32_t sampleRate, uint16_t bitDepth, uint16_t channels) {
    uint32_t fileSize = 44;  // 先写入 WAV 头部，后续再更新文件大小
    uint32_t dataSize = 0;   // 数据区大小
 
    file.seek(0);
    file.write((const uint8_t *)"RIFF", 4);
    file.write((uint8_t *)&fileSize, 4);
    file.write((const uint8_t *)"WAVE", 4);
    file.write((const uint8_t *)"fmt ", 4);
    uint32_t subchunk1Size = 16;
    file.write((uint8_t *)&subchunk1Size, 4);
    uint16_t audioFormat = 1;
    file.write((uint8_t *)&audioFormat, 2);
    file.write((uint8_t *)&channels, 2);
    file.write((uint8_t *)&sampleRate, 4);
    uint32_t byteRate = sampleRate * channels * (bitDepth / 8);
    file.write((uint8_t *)&byteRate, 4);
    uint16_t blockAlign = channels * (bitDepth / 8);
    file.write((uint8_t *)&blockAlign, 2);
    file.write((uint8_t *)&bitDepth, 2);
    file.write((const uint8_t *)"data", 4);
    file.write((uint8_t *)&dataSize, 4);
}

void EspI2S::updateWavHeader(File &file) {
    uint32_t fileSize = file.size() - 8;
    uint32_t dataSize = file.size() - 44;
 
    file.seek(4);
    file.write((uint8_t *)&fileSize, 4);
    file.seek(40);
    file.write((uint8_t *)&dataSize, 4);
}

String EspI2S::generateFileName() {
    unsigned long timestamp = millis();
    return "audio_" + String(timestamp) + ".wav";
}

// 文件管理
bool EspI2S::listAudioFiles() {
    Serial.println("📂 SD卡音频文件列表:");
    File root = SD.open("/");
    if (!root) {
        Serial.println("❌ 无法打开根目录");
        return false;
    }
    
    int fileCount = 0;
    uint32_t totalSize = 0;
    
    File file = root.openNextFile();
    while (file) {
        if (!file.isDirectory()) {
            String fileName = file.name();
            if (fileName.endsWith(".wav")) {
                fileCount++;
                uint32_t fileSize = file.size();
                totalSize += fileSize;
                Serial.printf("   🎵 %s (%.1fKB)\n", fileName.c_str(), fileSize/1024.0);
            }
        }
        file = root.openNextFile();
    }
    
    if (fileCount == 0) {
        Serial.println("   📭 没有找到WAV文件");
    } else {
        Serial.printf("📊 总计: %d个文件, %.1fKB\n", fileCount, totalSize/1024.0);
    }
    
    return true;
}

bool EspI2S::deleteAudioFile(String fileName) {
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    
    String fullPath = "/" + fileName;
    
    if (SD.exists(fullPath)) {
        if (SD.remove(fullPath)) {
            Serial.printf("🗑️ 已删除: %s\n", fileName.c_str());
            return true;
        } else {
            Serial.printf("❌ 删除失败: %s\n", fileName.c_str());
            return false;
        }
    } else {
        Serial.printf("❌ 文件不存在: %s\n", fileName.c_str());
        return false;
    }
}

bool EspI2S::fileExists(String fileName) {
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    return SD.exists("/" + fileName);
}

uint32_t EspI2S::getFileSize(String fileName) {
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }
    
    File file = SD.open("/" + fileName);
    if (file) {
        uint32_t size = file.size();
        file.close();
        return size;
    }
    return 0;
}

// 录制状态
String EspI2S::getCurrentFileName() {
    return currentFileName;
}

unsigned long EspI2S::getRecordedTime() {
    if (recording) {
        return millis() - recordStartTime;
    }
    return 0;
}

uint32_t EspI2S::getRecordedBytes() {
    return recordedBytes;
}

String EspI2S::getRecordingStatus() {
    if (!recording) return "停止";
    
    String status = "录制中: " + currentFileName;
    status += " (";
    status += String(getRecordedTime() / 1000.0, 1);
    status += "s, ";
    status += String(recordedBytes / 1024.0, 1);
    status += "KB)";
    
    return status;
}

// 功放初始化
bool EspI2S::initSpeaker(int bclk, int lrc, int dout) {
    speaker_bclk = bclk;
    speaker_lrc = lrc;
    speaker_dout = dout;

    // 新API: 创建发送通道
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_MASTER);
    esp_err_t err = i2s_new_channel(&chan_cfg, &tx_chan, NULL);
    if (err != ESP_OK) {
        Serial.printf("❌ 功放I2S通道创建失败: %s\n", esp_err_to_name(err));
        return false;
    }

    // 新API: 标准I2S配置
    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(44100),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = (gpio_num_t)speaker_bclk,
            .ws = (gpio_num_t)speaker_lrc,
            .dout = (gpio_num_t)speaker_dout,
            .din = I2S_GPIO_UNUSED,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    err = i2s_channel_init_std_mode(tx_chan, &std_cfg);
    if (err != ESP_OK) {
        Serial.printf("❌ 功放I2S标准模式初始化失败: %s\n", esp_err_to_name(err));
        i2s_del_channel(tx_chan);
        tx_chan = NULL;
        return false;
    }

    err = i2s_channel_enable(tx_chan);
    if (err != ESP_OK) {
        Serial.printf("❌ 功放I2S通道启用失败: %s\n", esp_err_to_name(err));
        i2s_del_channel(tx_chan);
        tx_chan = NULL;
        return false;
    }

    speakerInitialized = true;
    Serial.println("🔊 功放初始化成功");
    Serial.printf("📍 功放引脚: BCLK=%d, LRC=%d, DOUT=%d\n", speaker_bclk, speaker_lrc, speaker_dout);

    return true;
}

void EspI2S::endSpeaker() {
    if (speakerInitialized) {
        i2s_channel_disable(tx_chan);
        i2s_del_channel(tx_chan);
        tx_chan = NULL;
        speakerInitialized = false;
        Serial.println("🔌 功放I2S驱动已卸载");
    }
}

bool EspI2S::isSpeakerReady() {
    return speakerInitialized;
}

// 生成正弦波 - 与参考代码相同的逻辑
void EspI2S::generateSineWave(int16_t* buffer, size_t samples, float freq) {
    float phaseIncrement = 2 * PI * freq / 44100.0;  // 44.1kHz采样率
    
    for (int i = 0; i < samples; i++) {
        int16_t sample = volume * 32767.0 * sin(phase);
        buffer[i * 2] = sample;      // 左声道
        buffer[i * 2 + 1] = sample;  // 右声道
        
        phase += phaseIncrement;
        if (phase >= 2 * PI) phase -= 2 * PI;
    }
}

// 播放单音 - 与参考代码相同的逻辑
bool EspI2S::playTone(float frequency, uint32_t duration) {
    if (!speakerInitialized) {
        Serial.println("❌ 功放未初始化");
        return false;
    }
    
    const size_t bufferSamples = 256;
    int16_t audioBuffer[bufferSamples * 2];  // 立体声
    size_t bytesWritten;
    
    unsigned long startTime = millis();
    Serial.printf("🎵 播放音调: %.1fHz, 时长: %dms\n", frequency, duration);
    
    while (millis() - startTime < duration) {
        generateSineWave(audioBuffer, bufferSamples, frequency);
        
        esp_err_t result = i2s_channel_write(tx_chan, audioBuffer, bufferSamples * 2 * sizeof(int16_t), &bytesWritten, pdMS_TO_TICKS(100));
        
        if (result != ESP_OK) {
            Serial.printf("⚠️ 音频输出错误: %s\n", esp_err_to_name(result));
            return false;
        }
    }
    
    return true;
}

bool EspI2S::playNote(float frequency, uint32_t duration) {
    return playTone(frequency, duration);
}

// 播放旋律 - 与参考代码相同的逻辑
bool EspI2S::playMelody(Note* melody, int length, bool loop) {
    if (!speakerInitialized) {
        Serial.println("❌ 功放未初始化");
        return false;
    }
    
    currentMelody = melody;
    melodyLength = length;
    currentNoteIndex = 0;
    noteStartTime = millis();
    melodyPlaying = true;
    melodyLoop = loop;
    phase = 0.0;
    
    Serial.printf("🎼 开始播放旋律: %d个音符\n", length);
    return true;
}

bool EspI2S::stopMelody() {
    melodyPlaying = false;
    currentMelody = nullptr;
    Serial.println("⏹️ 停止播放旋律");
    return true;
}

bool EspI2S::isMelodyPlaying() {
    return melodyPlaying;
}

// 更新旋律播放 - 与参考代码相同的逻辑
void EspI2S::updateMelody() {
    if (!melodyPlaying || !currentMelody || !speakerInitialized) return;
    
    // 检查当前音符是否播放完毕
    if (millis() - noteStartTime >= currentMelody[currentNoteIndex].duration) {
        currentNoteIndex++;
        
        // 检查是否播放完所有音符
        if (currentNoteIndex >= melodyLength) {
            if (melodyLoop) {
                currentNoteIndex = 0;  // 循环播放
                Serial.println("🔄 旋律循环播放");
            } else {
                melodyPlaying = false;
                Serial.println("✅ 旋律播放完成");
                return;
            }
        }
        
        noteStartTime = millis();
        phase = 0.0;  // 🔧 重置相位，避免音符间的突变
        
        // 🔧 输出当前播放的音符信息
        Serial.printf("🎵 播放音符 %d/%d: %.1fHz, %dms\n", 
                     currentNoteIndex + 1, melodyLength,
                     currentMelody[currentNoteIndex].freq,
                     currentMelody[currentNoteIndex].duration);
    }
    
    // 🔧 增大缓冲区，确保连续播放
    const size_t bufferSamples = 512;  // 从128增加到512
    int16_t audioBuffer[bufferSamples * 2];
    size_t bytesWritten;
    
    float currentFreq = currentMelody[currentNoteIndex].freq;
    
    // 🔧 添加音符间的静音间隔
    unsigned long currentTime = millis() - noteStartTime;
    unsigned long noteDuration = currentMelody[currentNoteIndex].duration;
    
    // 音符播放80%的时间，20%是静音间隔
    if (currentTime < noteDuration * 0.8) {
        generateSineWave(audioBuffer, bufferSamples, currentFreq);
    } else {
        // 静音间隔
        memset(audioBuffer, 0, bufferSamples * 2 * sizeof(int16_t));
    }
    
    esp_err_t result = i2s_channel_write(tx_chan, audioBuffer, bufferSamples * 2 * sizeof(int16_t), &bytesWritten, pdMS_TO_TICKS(100));
    if (result != ESP_OK) {
    Serial.printf("⚠️ 音频输出错误: %s\n", esp_err_to_name(result));
    }
}

// 音量控制
void EspI2S::setVolume(float vol) {
    volume = constrain(vol, 0.0, 8.0);
    Serial.printf("🔊 音量设置为: %.1f%%\n", volume * 100);
}

float EspI2S::getVolume() {
    return volume;
}

// 预定义音乐 - 小星星与参考代码相同
bool EspI2S::playTwinkleStar(bool loop) {
    static Note twinkleStar[] = {
        // 小星星一闪一闪亮晶晶
        {NOTE_C4, 600}, {NOTE_C4, 600}, {NOTE_G4, 600}, {NOTE_G4, 600},
        {NOTE_A4, 600}, {NOTE_A4, 600}, {NOTE_G4, 1200},  // 满天都是
        
        {NOTE_F4, 600}, {NOTE_F4, 600}, {NOTE_E4, 600}, {NOTE_E4, 600},
        {NOTE_D4, 600}, {NOTE_D4, 600}, {NOTE_C4, 1200},  // 小星星
        
        {NOTE_G4, 600}, {NOTE_G4, 600}, {NOTE_F4, 600}, {NOTE_F4, 600},
        {NOTE_E4, 600}, {NOTE_E4, 600}, {NOTE_D4, 1200},  // 挂在天空
        
        {NOTE_G4, 600}, {NOTE_G4, 600}, {NOTE_F4, 600}, {NOTE_F4, 600},
        {NOTE_E4, 600}, {NOTE_E4, 600}, {NOTE_D4, 1200},  // 放光明
        
        {NOTE_C4, 600}, {NOTE_C4, 600}, {NOTE_G4, 600}, {NOTE_G4, 600},
        {NOTE_A4, 600}, {NOTE_A4, 600}, {NOTE_G4, 1200},  // 重复第一句
        
        {NOTE_F4, 600}, {NOTE_F4, 600}, {NOTE_E4, 600}, {NOTE_E4, 600},
        {NOTE_D4, 600}, {NOTE_D4, 600}, {NOTE_C4, 1200}   // 结尾
    };
    
    int length = sizeof(twinkleStar) / sizeof(twinkleStar[0]);
    return playMelody(twinkleStar, length, loop);
}

bool EspI2S::playHappyBirthday(bool loop) {
    static Note happyBirthday[] = {
        {NOTE_C4, 200}, {NOTE_C4, 200}, {NOTE_D4, 400},
        {NOTE_C4, 400}, {NOTE_F4, 400}, {NOTE_E4, 800},
        {NOTE_C4, 400}, {NOTE_C4, 400}, {NOTE_D4, 800},
        {NOTE_C4, 400}, {NOTE_G4, 400}, {NOTE_F4, 800}
    };
    
    int length = sizeof(happyBirthday) / sizeof(happyBirthday[0]);
    return playMelody(happyBirthday, length, loop);
}

bool EspI2S::playBeep(uint32_t duration) {
    return playTone(1000, duration);  // 1kHz蜂鸣音
}

bool EspI2S::playSuccess() {
    static Note success[] = {
        {NOTE_C4, 150}, {NOTE_E4, 150}, {NOTE_G4, 150}, {NOTE_C5, 300}
    };
    
    int length = sizeof(success) / sizeof(success[0]);
    return playMelody(success, length, false);
}

bool EspI2S::playError() {
    static Note error[] = {
        {NOTE_G4, 200}, {NOTE_C4, 200}, {NOTE_G4, 200}, {NOTE_C4, 200}
    };
    
    int length = sizeof(error) / sizeof(error[0]);
    return playMelody(error, length, false);
}

// WAV文件播放功能
bool EspI2S::playWavFile(String fileName) {
    if (!speakerInitialized) {
        Serial.println("❌ 功放未初始化");
        return false;
    }

    if (playingWav) {
        Serial.println("⚠️ 已在播放中");
        return false;
    }

    // 确保文件名有.wav扩展名
    if (!fileName.endsWith(".wav")) {
        fileName += ".wav";
    }

    // 打开文件
    playbackFile = SD.open("/" + fileName, FILE_READ);
    if (!playbackFile) {
        Serial.printf("❌ 无法打开文件: %s\n", fileName.c_str());
        return false;
    }

    // 读取WAV头
    if (!parseWavHeader()) {
        Serial.println("❌ 无效的WAV文件格式");
        playbackFile.close();
        return false;
    }

    i2s_channel_disable(tx_chan);
    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(wavSampleRate),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = (gpio_num_t)speaker_bclk,
            .ws = (gpio_num_t)speaker_lrc,
            .dout = (gpio_num_t)speaker_dout,
            .din = I2S_GPIO_UNUSED,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };
    i2s_channel_init_std_mode(tx_chan, &std_cfg);
    i2s_channel_enable(tx_chan);

    playingWav = true;
    paused = false;
    playbackStartTime = millis();
    playbackPosition = 0;

    Serial.printf("🎵 开始播放: %s\n", fileName.c_str());
    Serial.printf("📊 格式: %dHz, %d位, %d声道\n", wavSampleRate, wavBitsPerSample, wavChannels);

    return true;
}

bool EspI2S::parseWavHeader() {
    char chunkID[5];
    uint32_t chunkSize;
    char format[5];
    
    // 读取RIFF头
    playbackFile.readBytes(chunkID, 4);
    chunkID[4] = '\0';
    if (strcmp(chunkID, "RIFF") != 0) return false;
    
    playbackFile.read((uint8_t*)&chunkSize, 4);
    
    playbackFile.readBytes(format, 4);
    format[4] = '\0';
    if (strcmp(format, "WAVE") != 0) return false;
    
    // 查找fmt块
    while (playbackFile.available()) {
        playbackFile.readBytes(chunkID, 4);
        chunkID[4] = '\0';
        playbackFile.read((uint8_t*)&chunkSize, 4);
        
        if (strcmp(chunkID, "fmt ") == 0) {
            uint16_t audioFormat;
            playbackFile.read((uint8_t*)&audioFormat, 2);
            playbackFile.read((uint8_t*)&wavChannels, 2);
            playbackFile.read((uint8_t*)&wavSampleRate, 4);
            
            // 跳过其他fmt数据
            playbackFile.seek(playbackFile.position() + chunkSize - 8);
            
        } else if (strcmp(chunkID, "data") == 0) {
            wavDataSize = chunkSize;
            break;
        } else {
            // 跳过未知块
            playbackFile.seek(playbackFile.position() + chunkSize);
        }
    }
    
    return wavDataSize > 0;
}

void EspI2S::updatePlayback() {
    if (!playingWav || paused || !playbackFile) return;
    
    const size_t bufferSamples = 256;
    int16_t audioBuffer[bufferSamples * 2];  // 立体声缓冲区
    size_t bytesRead;
    size_t bytesWritten;
    
    // 读取音频数据
    if (wavChannels == 1) {  // 单声道
        int16_t monoBuffer[bufferSamples];
        bytesRead = playbackFile.read((uint8_t*)monoBuffer, bufferSamples * sizeof(int16_t));
        
        // 转换为立体声
        for (int i = 0; i < bytesRead / 2; i++) {
            audioBuffer[i * 2] = monoBuffer[i] * volume;      // 左声道
            audioBuffer[i * 2 + 1] = monoBuffer[i] * volume;  // 右声道
        }
        
        bytesWritten = (bytesRead / 2) * 2 * sizeof(int16_t);
        
    } else {  // 立体声
        bytesRead = playbackFile.read((uint8_t*)audioBuffer, bufferSamples * 2 * sizeof(int16_t));
        
        // 应用音量
        for (int i = 0; i < bytesRead / 2; i++) {
            audioBuffer[i] = audioBuffer[i] * volume;
        }
        
        bytesWritten = bytesRead;
    }
    
    if (bytesRead > 0) {
        // 🔧 使用阻塞写入确保时序正确
        size_t written;
        esp_err_t result = i2s_channel_write(tx_chan, audioBuffer, bufferSamples * 2 * sizeof(int16_t), &written, pdMS_TO_TICKS(100));

        if (result != ESP_OK) {
            Serial.printf("⚠️ I2S写入错误: %s\n", esp_err_to_name(result));
        }
        
        playbackPosition += bytesRead;
        
        // 🔧 添加时序控制 - 根据采样率计算延时
        uint32_t samplesPlayed = bytesRead / (sizeof(int16_t) * wavChannels);
        uint32_t timePerBuffer = (samplesPlayed * 1000) / wavSampleRate;  // 毫秒
        
        // 短暂延时以维持正确的播放速度
        if (timePerBuffer > 0) {
            delay(timePerBuffer / 4);  // 适当的延时
        }
        
    } else {
        // 播放完成
        Serial.println("✅ WAV播放完成");
        stopPlayback();
    }
}

bool EspI2S::stopPlayback() {
    if (!playingWav) return false;
    
    playingWav = false;
    paused = false;
    
    if (playbackFile) {
        playbackFile.close();
    }
    
    Serial.println("⏹️ 停止播放WAV");
    return true;
}

bool EspI2S::pausePlayback() {
    if (!playingWav) return false;
    
    paused = true;
    Serial.println("⏸️ 暂停播放");
    return true;
}

bool EspI2S::resumePlayback() {
    if (!playingWav) return false;
    
    paused = false;
    Serial.println("▶️ 恢复播放");
    return true;
}

bool EspI2S::isPlayingWav() {
    return playingWav;
}

unsigned long EspI2S::getPlaybackTime() {
    if (!playingWav) return 0;
    return millis() - playbackStartTime;
}

uint32_t EspI2S::getFileDuration(String fileName) {
    // 根据文件大小和采样率估算时长
    if (!fileExists(fileName)) return 0;
    
    uint32_t fileSize = getFileSize(fileName);
    if (fileSize < 44) return 0;  // 至少要有WAV头
    
    uint32_t dataSize = fileSize - 44;  // 减去WAV头
    uint32_t duration = (dataSize * 1000) / (44100 * 2);  // 假设44.1kHz 16位
    
    return duration;
}

// 播放状态
String EspI2S::getPlayingStatus() {
    if (playingWav) {
        String status = "播放WAV: ";
        status += String(getPlaybackTime() / 1000.0, 1);
        status += "s";
        return status;
    }
    
    if (!melodyPlaying) return "停止";
    
    String status = "播放中: 音符 ";
    status += String(currentNoteIndex + 1);
    status += "/";
    status += String(melodyLength);
    status += " (";
    status += String(currentMelody[currentNoteIndex].freq, 1);
    status += "Hz)";
    
    return status;
}

int EspI2S::getCurrentNoteIndex() {
    return currentNoteIndex;
}

String EspI2S::getCurrentNoteName() {
    if (!melodyPlaying || !currentMelody) return "";
    
    float freq = currentMelody[currentNoteIndex].freq;
    
    if (abs(freq - NOTE_C4) < 1) return "C4";
    else if (abs(freq - NOTE_D4) < 1) return "D4";
    else if (abs(freq - NOTE_E4) < 1) return "E4";
    else if (abs(freq - NOTE_F4) < 1) return "F4";
    else if (abs(freq - NOTE_G4) < 1) return "G4";
    else if (abs(freq - NOTE_A4) < 1) return "A4";
    else if (abs(freq - NOTE_B4) < 1) return "B4";
    else if (abs(freq - NOTE_C5) < 1) return "C5";
    else return String(freq, 1) + "Hz";
}

// ===========================================
// PDM麦克风功能实现
// ===========================================

bool EspI2S::beginPDM(int sampleRate, int bufferSize, int clk_pin, int data_pin) {
    // 如果PCM已初始化，先关闭
    if (initialized) {
        Serial.println("⚠️ 检测到PCM已初始化，将切换到PDM模式");
        end();
    }
    
    // 如果PDM已初始化，先关闭
    if (pdmInitialized) {
        endPDM();
    }
    
    sample_rate = sampleRate;
    buffer_size = bufferSize;
    pdm_clk_pin = clk_pin;
    pdm_data_pin = data_pin;
    micType = MIC_TYPE_PDM;

    // 分配缓冲区
    sampleBuffer = (int16_t*)malloc(buffer_size * sizeof(int16_t));
    if (!sampleBuffer) {
        Serial.println("❌ PDM内存分配失败!");
        return false;
    }

    // 🔧 新API: 1. 通道配置
    i2s_chan_config_t chan_cfg = {
        .id = I2S_NUM_AUTO,
        .role = I2S_ROLE_MASTER,
        .dma_desc_num = 6,
        .dma_frame_num = 240,
        .auto_clear = true,
        .auto_clear_before_cb = false,
        .intr_priority = 0
    };
    
    // 🔧 新API: 2. 创建接收通道
    esp_err_t err = i2s_new_channel(&chan_cfg, NULL, &rx_chan);
    if (err != ESP_OK) {
        Serial.printf("❌ 创建PDM通道失败: %s\n", esp_err_to_name(err));
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }
    
    // 🔧 新API: 3. PDM接收配置
    i2s_pdm_rx_config_t pdm_rx_cfg = {
        .clk_cfg = {
            .sample_rate_hz = (uint32_t)sampleRate,
            .clk_src = I2S_CLK_SRC_DEFAULT,
            .mclk_multiple = I2S_MCLK_MULTIPLE_256,
        },
        .slot_cfg = {
            .data_bit_width = I2S_DATA_BIT_WIDTH_16BIT,
            .slot_bit_width = I2S_SLOT_BIT_WIDTH_AUTO,
            .slot_mode = I2S_SLOT_MODE_MONO,
            .slot_mask = I2S_PDM_SLOT_LEFT,
        },
        .gpio_cfg = {
            .clk = (gpio_num_t)clk_pin,
            .din = (gpio_num_t)data_pin,
            .invert_flags = {
                .clk_inv = false,
            },
        },
    };
    
    // 🔧 新API: 4. 初始化PDM接收模式
    err = i2s_channel_init_pdm_rx_mode(rx_chan, &pdm_rx_cfg);
    if (err != ESP_OK) {
        Serial.printf("❌ PDM模式初始化失败: %s\n", esp_err_to_name(err));
        i2s_del_channel(rx_chan);
        rx_chan = NULL;
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }
    
    // 🔧 新API: 5. 启用通道
    err = i2s_channel_enable(rx_chan);
    if (err != ESP_OK) {
        Serial.printf("❌ PDM通道启用失败: %s\n", esp_err_to_name(err));
        i2s_del_channel(rx_chan);
        rx_chan = NULL;
        free(sampleBuffer);
        sampleBuffer = nullptr;
        return false;
    }
    
    pdmInitialized = true;
    initialized = true;
    Serial.println("✅ PDM麦克风初始化成功（新API）");
    Serial.printf("📍 PDM引脚: CLK=%d, DATA=%d\n", pdm_clk_pin, pdm_data_pin);
    Serial.printf("🎵 采样率: %d Hz, 缓冲区: %d 样本\n", sample_rate, buffer_size);
    
    return true;
}

void EspI2S::endPDM() {
    if (pdmInitialized && rx_chan) {
        // 🔧 新API: 禁用和删除通道
        i2s_channel_disable(rx_chan);
        i2s_del_channel(rx_chan);
        rx_chan = NULL;
        pdmInitialized = false;
        initialized = false;
        Serial.println("🔌 PDM I2S驱动已卸载（新API）");
    }
    if (sampleBuffer) {
        free(sampleBuffer);
        sampleBuffer = nullptr;
    }
}

bool EspI2S::isPDMReady() {
    return pdmInitialized && (rx_chan != NULL) && (sampleBuffer != nullptr);
}

bool EspI2S::readPDMSamples() {
    if (!pdmInitialized || !rx_chan || !sampleBuffer) {
        Serial.println("❌ PDM未初始化或缓冲区为空");
        return false;
    }
    
    size_t bytes_read = 0;
    
    // 🔧 新API: 使用 i2s_channel_read
    esp_err_t result = i2s_channel_read(rx_chan, sampleBuffer, 
                                       buffer_size * sizeof(int16_t), 
                                       &bytes_read, pdMS_TO_TICKS(100));
    
    if (result != ESP_OK) {
        Serial.printf("⚠️ PDM I2S读取错误: %s\n", esp_err_to_name(result));
        return false;
    }
    
    if (bytes_read == 0) {
        Serial.println("⚠️ 没有读取到PDM数据");
        return false;
    }
    
    Serial.printf("✅ PDM读取了 %d 字节数据\n", bytes_read);
    
    // 🔧 打印前几个样本值用于调试
    Serial.printf("🔍 样本值: %d, %d, %d, %d\n", 
                  sampleBuffer[0], sampleBuffer[1], sampleBuffer[2], sampleBuffer[3]);
    
    processPDMData();
    calculateAudioStats();
    
    return true;
}

void EspI2S::processPDMData() {
    if (!sampleBuffer) return;
    
    for (int i = 0; i < buffer_size; i++) {
        sampleBuffer[i] = sampleBuffer[i] >> 2;
    }
}

void EspI2S::calculateAudioStats() {
    if (!sampleBuffer) return;
    
    int32_t sum = 0;
    int64_t sumSquares = 0;
    int16_t maxVal = 0;
    
    for (int i = 0; i < buffer_size; i++) {
        int16_t sample = abs(sampleBuffer[i]);
        sum += sample;
        sumSquares += (int64_t)sample * sample;
        if (sample > maxVal) maxVal = sample;
    }
    
    avgLevel = (float)sum / buffer_size;
    peakLevel = maxVal;
    rmsLevel = sqrt((float)sumSquares / buffer_size);
    totalSamples += buffer_size;
}

MicType EspI2S::getMicType() {
    return micType;
}

String EspI2S::getMicTypeString() {
    switch (micType) {
        case MIC_TYPE_PCM: return "PCM";
        case MIC_TYPE_PDM: return "PDM";
        default: return "未知";
    }
}

bool EspI2S::setPDMFilter(int filterLength, float cutoffFreq) {
    if (!pdmInitialized) {
        return false;
    }
    Serial.printf("🔧 PDM滤波器配置: 长度=%d, 截止频率=%.1fHz\n", filterLength, cutoffFreq);
    return true;
}

bool EspI2S::setPDMGain(float gain) {
    if (!pdmInitialized) {
        return false;
    }
    if (gain < 0.1 || gain > 10.0) {
        return false;
    }
    Serial.printf("🔧 PDM增益设置为: %.1fx\n", gain);
    return true;
}