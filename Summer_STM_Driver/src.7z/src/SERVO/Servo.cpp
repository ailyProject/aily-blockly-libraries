#include "Servo.h"
#include <Arduino.h>
#include "driver/ledc.h"

#define SERVO_FREQ 50         // 舵机PWM频率50Hz
#define SERVO_MIN_US 500      // 舵机最小脉宽（微秒）
#define SERVO_MAX_US 2500     // 舵机最大脉宽（微秒）
#define SERVO_PERIOD_US 20000 // 舵机周期（微秒）
#define LEDC_RESOLUTION 16    // LEDC分辨率
#define LEDC_BASE_CHANNEL 4   // LEDC通道起始（使用4及以上）

Servo::Servo() {
    pin = -1;
    currentAngle = 90;
    attached = false;
    ledcChannel = -1;
}

Servo::~Servo() {
    detach();
}

void Servo::attach(int servoPin) {
    pin = servoPin;
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
    // 分配LEDC通道（简单实现：pin号-2作为通道，保证4及以上）
    ledcChannel = LEDC_BASE_CHANNEL + ((pin % 4) & 0x03); // 4~7
    ledcSetup(ledcChannel, SERVO_FREQ, LEDC_RESOLUTION);
    ledcAttachPin(pin, ledcChannel);
    attached = true;
}

void Servo::detach() {
    if (attached) {
        ledcDetachPin(pin);
        digitalWrite(pin, LOW);
        attached = false;
        pin = -1;
        ledcChannel = -1;
    }
}

bool Servo::isAttached() {
    return attached;
}

void Servo::write(int angle) {
    if (!attached) return;

    // 限制角度范围
    if (angle < 0) angle = 0;
    if (angle > 180) angle = 180;

    currentAngle = angle;

    // 角度转脉宽
    int pulseWidth = map(angle, 0, 180, SERVO_MIN_US, SERVO_MAX_US);

    // 脉宽转占空比
    uint32_t duty = (uint32_t)pulseWidth * ((1 << LEDC_RESOLUTION) - 1) / SERVO_PERIOD_US;
    ledcWrite(ledcChannel, duty);
}

void Servo::writeMicroseconds(int microseconds) {
    if (!attached) return;

    // 限制脉宽范围
    if (microseconds < SERVO_MIN_US) microseconds = SERVO_MIN_US;
    if (microseconds > SERVO_MAX_US) microseconds = SERVO_MAX_US;

    currentAngle = map(microseconds, SERVO_MIN_US, SERVO_MAX_US, 0, 180);

    uint32_t duty = (uint32_t)microseconds * ((1 << LEDC_RESOLUTION) - 1) / SERVO_PERIOD_US;
    ledcWrite(ledcChannel, duty);
}

int Servo::read() {
    return currentAngle;
}

void Servo::smoothMove(int targetAngle, int speed) {
    if (!attached) return;

    if (targetAngle < 0) targetAngle = 0;
    if (targetAngle > 180) targetAngle = 180;
    if (speed < 1) speed = 1;
    if (speed > 10) speed = 10;

    if (currentAngle < targetAngle) {
        for (int angle = currentAngle; angle <= targetAngle; angle += speed) {
            write(angle);
            delay(5);
        }
    } else {
        for (int angle = currentAngle; angle >= targetAngle; angle -= speed) {
            write(angle);
            delay(5);
        }
    }
    write(targetAngle);
}

void Servo::sweep(int startAngle, int endAngle, int delayTime) {
    if (!attached) return;

    if (startAngle < 0) startAngle = 0;
    if (startAngle > 180) startAngle = 180;
    if (endAngle < 0) endAngle = 0;
    if (endAngle > 180) endAngle = 180;

    for (int angle = startAngle; angle <= endAngle; angle++) {
        write(angle);
        delay(delayTime);
    }
    for (int angle = endAngle; angle >= startAngle; angle--) {
        write(angle);
        delay(delayTime);
    }
}