#ifndef STM32_I2C_H
#define STM32_I2C_H

#include <Arduino.h>
#include <Wire.h>

// I2C配置
#define STM32_I2C_ADDR    0x10
#define I2C_SDA_PIN       21
#define I2C_SCL_PIN       22
#define I2C_FREQ          100000

// 设备类型
#define DEVICE_SERVO      0x00
#define DEVICE_TT_MOTOR   0x01
#define DEVICE_STEPPER    0x02
#define DEVICE_SYSTEM     0x03

// 电机方向
#define MOTOR_STOP        0
#define MOTOR_FORWARD     1
#define MOTOR_BACKWARD    2

// 步进电机方向
#define STEPPER_CW        0
#define STEPPER_CCW       1

// 系统命令
#define SYS_CMD_STOP_ALL  0
#define SYS_CMD_SERVO_MID 1
#define SYS_CMD_READ_JY61P 0x10
#define SYS_CMD_ZERO_JY61P 0x11
#define SYS_CMD_READ_ACC   0x12
#define SYS_CMD_READ_GYRO  0x13

// 应答码
#define ACK_SUCCESS       0x06
#define ACK_FAILURE       0x15
#define ACK_TIMEOUT       0xFF

class STM32_I2C_Controller {
public:
    // 初始化I2C通信
    void begin();
    void begin(uint8_t sda, uint8_t scl);
    
    // 基础通信函数
    bool sendCommand(uint8_t device_type, uint8_t device_num, uint8_t param1, uint8_t param2);
    
    // ========== 舵机控制 ==========
    void servoInit();
    void servoAngle(uint8_t servo_num, uint8_t angle);
    void servoDualAngle(uint8_t angle);
    void servoToMid();
    
    // ========== TT马达控制 ==========
    void motorControl(uint8_t motor_num, uint8_t direction, uint8_t speed);
    void motorStop(uint8_t motor_num);
    
    // ========== 步进电机控制 ==========
    void stepperControl(uint8_t stepper_num, uint8_t direction, uint16_t degrees);
    void stepperControlTurns(uint8_t stepper_num, uint8_t direction, float turns);
    
    // ========== 系统控制 ==========
    void stopAllMotors();
    
    // ========== JY61P六轴传感器 ==========
    void jy61pSetZero();
    float jy61pGetAngle(char axis);  // 'X', 'Y', 'Z'
    float jy61pGetAcceleration(char axis);  // 'X', 'Y', 'Z'
    float jy61pGetGyro(char axis);  // 'X', 'Y', 'Z'
    
private:
    bool initialized = false;
    uint8_t sda_pin = I2C_SDA_PIN;
    uint8_t scl_pin = I2C_SCL_PIN;
    
    // 内部辅助函数
    float readJY61PData(uint8_t cmd, uint8_t axis_index);
};

// 全局实例
extern STM32_I2C_Controller STM32_I2C;

#endif // STM32_I2C_H
