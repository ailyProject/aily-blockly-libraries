#include "STM32_I2C.h"

// 全局实例
STM32_I2C_Controller STM32_I2C;

// ========== 初始化 ==========
void STM32_I2C_Controller::begin() {
    begin(I2C_SDA_PIN, I2C_SCL_PIN);
}

void STM32_I2C_Controller::begin(uint8_t sda, uint8_t scl) {
    if (!initialized) {
        sda_pin = sda;
        scl_pin = scl;
        Wire.begin(sda_pin, scl_pin);
        Wire.setClock(I2C_FREQ);
        initialized = true;
    }
}

// ========== 基础通信 ==========
bool STM32_I2C_Controller::sendCommand(uint8_t device_type, uint8_t device_num, uint8_t param1, uint8_t param2) {
    Wire.beginTransmission(STM32_I2C_ADDR);
    Wire.write(device_type);
    Wire.write(device_num);
    Wire.write(param1);
    Wire.write(param2);
    uint8_t error = Wire.endTransmission();
    if (error != 0) return false;
    
    delay(50);
    
    uint8_t bytesRead = Wire.requestFrom(STM32_I2C_ADDR, 5);
    if (bytesRead != 5) return false;
    
    uint8_t ack = Wire.read();
    for (int i = 0; i < 4; i++) Wire.read();
    
    return (ack == ACK_SUCCESS);
}

// ========== 舵机控制 ==========
void STM32_I2C_Controller::servoInit() {
    // 初始化时确保I2C已启动
    if (!initialized) begin();
}

void STM32_I2C_Controller::servoAngle(uint8_t servo_num, uint8_t angle) {
    if (!initialized) begin();
    sendCommand(DEVICE_SERVO, servo_num, 0, angle);
}

void STM32_I2C_Controller::servoDualAngle(uint8_t angle) {
    if (!initialized) begin();
    sendCommand(DEVICE_SERVO, 0xFF, 0, angle);
}

void STM32_I2C_Controller::servoToMid() {
    if (!initialized) begin();
    sendCommand(DEVICE_SYSTEM, SYS_CMD_SERVO_MID, 0, 0);
}

// ========== TT马达控制 ==========
void STM32_I2C_Controller::motorControl(uint8_t motor_num, uint8_t direction, uint8_t speed) {
    if (!initialized) begin();
    // 协议: device_num=电机号, param1=方向, param2=速度
    sendCommand(DEVICE_TT_MOTOR, motor_num, direction, speed);
}

void STM32_I2C_Controller::motorStop(uint8_t motor_num) {
    if (!initialized) begin();
    // 停止: direction=0, speed=0
    sendCommand(DEVICE_TT_MOTOR, motor_num, MOTOR_STOP, 0);
}

// ========== 步进电机控制 ==========
void STM32_I2C_Controller::stepperControl(uint8_t stepper_num, uint8_t direction, uint16_t degrees) {
    if (!initialized) begin();
    uint8_t device_num = stepper_num | (direction << 1);
    uint8_t angle_high = (degrees >> 8) & 0xFF;
    uint8_t angle_low = degrees & 0xFF;
    sendCommand(DEVICE_STEPPER, device_num, angle_high, angle_low);
}

void STM32_I2C_Controller::stepperControlTurns(uint8_t stepper_num, uint8_t direction, float turns) {
    uint16_t degrees = (uint16_t)(turns * 360);
    stepperControl(stepper_num, direction, degrees);
}

// ========== 系统控制 ==========
void STM32_I2C_Controller::stopAllMotors() {
    if (!initialized) begin();
    sendCommand(DEVICE_SYSTEM, SYS_CMD_STOP_ALL, 0, 0);
}

// ========== JY61P六轴传感器 ==========
void STM32_I2C_Controller::jy61pSetZero() {
    if (!initialized) begin();
    Wire.beginTransmission(STM32_I2C_ADDR);
    Wire.write(DEVICE_SYSTEM);
    Wire.write(SYS_CMD_ZERO_JY61P);
    Wire.write(0x00);
    Wire.write(0x00);
    Wire.endTransmission();
    delay(50);
    Wire.requestFrom(STM32_I2C_ADDR, 5);
    for (int i = 0; i < 5; i++) Wire.read();
}

float STM32_I2C_Controller::jy61pGetAngle(char axis) {
    return readJY61PData(SYS_CMD_READ_JY61P, axis == 'X' ? 0 : (axis == 'Y' ? 1 : 2));
}

float STM32_I2C_Controller::jy61pGetAcceleration(char axis) {
    return readJY61PData(SYS_CMD_READ_ACC, axis == 'X' ? 0 : (axis == 'Y' ? 1 : 2));
}

float STM32_I2C_Controller::jy61pGetGyro(char axis) {
    return readJY61PData(SYS_CMD_READ_GYRO, axis == 'X' ? 0 : (axis == 'Y' ? 1 : 2));
}

// ========== 内部辅助函数 ==========
float STM32_I2C_Controller::readJY61PData(uint8_t cmd, uint8_t axis_index) {
    if (!initialized) begin();
    
    // 发送读取命令
    Wire.beginTransmission(STM32_I2C_ADDR);
    Wire.write(DEVICE_SYSTEM);
    Wire.write(cmd);
    Wire.write(0x00);
    Wire.write(0x00);
    if (Wire.endTransmission() != 0) return 0.0;
    
    delay(100);  // 增加延时确保STM32处理完成
    
    // 读取ACK
    if (Wire.requestFrom(STM32_I2C_ADDR, 5) < 5) return 0.0;
    uint8_t ack = Wire.read();
    for (int i = 0; i < 4; i++) Wire.read();
    if (ack != ACK_SUCCESS) return 0.0;
    
    delay(10);
    
    // 读取数据
    if (Wire.requestFrom(STM32_I2C_ADDR, 8) < 8) return 0.0;
    uint8_t data[8];
    for (int i = 0; i < 8; i++) data[i] = Wire.read();
    
    // 根据不同命令解析数据
    if (cmd == SYS_CMD_READ_JY61P) {
        // 角度数据: 标志0xAA
        if (data[0] == 0xAA) {
            float values[3];
            values[0] = data[1] + data[2] / 100.0;      // Roll (X)
            values[1] = data[3] + data[4] / 100.0;      // Pitch (Y)
            values[2] = data[5] * 2 + data[6] / 100.0;  // Yaw (Z)
            return values[axis_index];
        }
    } 
    else if (cmd == SYS_CMD_READ_ACC) {
        // ⭐ 加速度数据: 标志0xBB...0xBB (首尾都是0xBB)
        if (data[0] == 0xBB && data[7] == 0xBB) {
            // 解析有符号16位整数，单位0.01g
            int16_t acc_x = (int16_t)((data[1] << 8) | data[2]);
            int16_t acc_y = (int16_t)((data[3] << 8) | data[4]);
            int16_t acc_z = (int16_t)((data[5] << 8) | data[6]);
            
            float values[3];
            values[0] = acc_x / 100.0f;  // X轴加速度 (g)
            values[1] = acc_y / 100.0f;  // Y轴加速度 (g)
            values[2] = acc_z / 100.0f;  // Z轴加速度 (g)
            return values[axis_index];
        }
    } 
    else if (cmd == SYS_CMD_READ_GYRO) {
        // ⭐ 角速度数据: 标志0xCC...0xCC (首尾都是0xCC)
        if (data[0] == 0xCC && data[7] == 0xCC) {
            // 解析有符号16位整数，单位0.01°/s
            int16_t gyro_x = (int16_t)((data[1] << 8) | data[2]);
            int16_t gyro_y = (int16_t)((data[3] << 8) | data[4]);
            int16_t gyro_z = (int16_t)((data[5] << 8) | data[6]);
            
            float values[3];
            values[0] = gyro_x / 100.0f;  // X轴角速度 (°/s)
            values[1] = gyro_y / 100.0f;  // Y轴角速度 (°/s)
            values[2] = gyro_z / 100.0f;  // Z轴角速度 (°/s)
            return values[axis_index];
        }
    }
    
    return 0.0;
}