
#ifndef  OpenJumperTTS_H
#define  OpenJumperTTS_H

#include <Arduino.h>

#if defined __AVR__ || defined(ESP8266) 
#include <SoftwareSerial.h>
#elif defined (ESP32)
#include <ESP32SoftwareSerial.h>
#endif

#define BUFFER_HEAD 0xFD

#define SPEECH_SPEED        0x73//语速
#define SPEECH_INTONATION   0x74//语调
#define SPEECH_VOLUME       0x76//音量

#define PLAY_STOP      0x02//停止
#define PLAY_PAUSE     0x03//暂停  
#define PLAY_CONTINUE  0x04//继续

#define VOICE_Ringtones     1//铃声
#define VOICE_PromptSound   2//提示音
#define VOICE_WarningSound  3//警示音

#define MP3_DEBUG 0

//   void concatByteArrays(uint8_t* result, uint8_t** arrays, size_t* lengths, size_t numArrays);
//   void genTTSBuffer(const char* content, uint8_t* buffer, size_t* bufferLength);
//   void PlayControl(uint8_t State);

//   void sendTTSBuffer(uint8_t* buffer);
//   uint8_t* genTTSBuffer(const char* content);
// #endif

// uint8_t rings[]   = {0X72,0X69,0X6E,0X67,0X5F};
// uint8_t message[] = {0X6D,0X65,0X73,0X73,0X61,0x67,0x65,0x5F};
// uint8_t alert[]   = {0xFD,0X00,0X09,0X01,0X01,0X61,0X6C,0X65,0X72,0X74,0x5F};

#if defined __AVR__ || defined(ESP8266) 

class OpenJumperTTS : public SoftwareSerial
{
  public: 

    OpenJumperTTS(short rxPin, short txPin) : SoftwareSerial(rxPin,txPin) { };

    void PlayText(const char *data);
    void PlayNumber(int numberString);
    void playcontrol(byte command);
    void setspeechSpeed(byte speechSpeed);
    void setIntonation(byte intonation);
    void setVolume(byte volumeVlaue);
    void RestoreDefaultValues(void);
    void PlayPromptSound(byte soundType,byte soundnumber);
    
  protected:
    int waitUntilAvailable(unsigned long maxWaitTime = 1000);
    void sendTTSBuffer(uint8_t* buffer);
    uint8_t* genTTSBuffer(const char* content);
};

#elif defined ESP32

class OpenJumperTTS : public Esp32SoftwareSerial
{
  
  public:

  protected:

};

#endif

#endif
