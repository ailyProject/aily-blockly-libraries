#ifndef MMC5603NJ_H
#define MMC5603NJ_H

#include <Arduino.h>
#include <Wire.h>

// MMC5603NJ I2C地址
#define MMC5603NJ_ADDRESS 0x30

// 寄存器地址
#define MMC5603NJ_OUT_X_L        0x00
#define MMC5603NJ_OUT_X_H        0x01
#define MMC5603NJ_OUT_Y_L        0x02
#define MMC5603NJ_OUT_Y_H        0x03
#define MMC5603NJ_OUT_Z_L        0x04
#define MMC5603NJ_OUT_Z_H        0x05
#define MMC5603NJ_OUT_TEMP       0x09
#define MMC5603NJ_STATUS         0x18
#define MMC5603NJ_CTRL0          0x1B
#define MMC5603NJ_CTRL1          0x1C
#define MMC5603NJ_CTRL2          0x1D
#define MMC5603NJ_WHO_AM_I       0x39

// 状态寄存器位
#define MMC5603NJ_STATUS_MEAS_M_DONE  0x01
#define MMC5603NJ_STATUS_MEAS_T_DONE  0x02

// 控制寄存器位
#define MMC5603NJ_CTRL0_TM_M     0x01
#define MMC5603NJ_CTRL0_TM_T     0x02
#define MMC5603NJ_CTRL0_SET      0x08
#define MMC5603NJ_CTRL0_RESET    0x10
#define MMC5603NJ_CTRL0_AUTO_SR  0x20
#define MMC5603NJ_CTRL0_AUTO_ST  0x40
#define MMC5603NJ_CTRL0_CMM_FREQ_EN 0x80

class MMC5603NJ {
public:
    MMC5603NJ();
    
    // 初始化函数
    bool begin(TwoWire *wire = &Wire);
    
    // 数据读取函数
    void readMag(float *x, float *y, float *z);
    float readTemperature();
    
    // 原始数据读取
    void readRawMag(int32_t *x, int32_t *y, int32_t *z);
    uint8_t readRawTemperature();
    
    // 校准函数
    void calibrate();
    void setOffset(float x_offset, float y_offset, float z_offset);
    
    // 辅助函数
    uint8_t getDeviceID();
    bool selfTest();
    void reset();
    bool isDataReady();
    
private:
    TwoWire *_wire;
    float _magScale;
    float _xOffset, _yOffset, _zOffset;
    
    // I2C通信函数
    void writeRegister(uint8_t reg, uint8_t value);
    uint8_t readRegister(uint8_t reg);
    void readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length);
    
    // 内部函数
    void startMeasurement();
    void waitForMeasurement();
    void performSetReset();
};

#endif