#include "QMI8658A.h"

QMI8658A::QMI8658A() {
    _accRange = QMI8658A_ACC_RANGE_8G;
    _gyroRange = QMI8658A_GYRO_RANGE_2048DPS;
    calculateScaleFactors();
}

bool QMI8658A::begin(TwoWire *wire) {
    _wire = wire;
    
    // 检查设备ID (官方库显示可能有多种ID值)
    uint8_t deviceId = getDeviceID();
    // 更宽松的设备ID检查，允许多种可能的ID值
    if (deviceId == 0x00 || deviceId == 0xFF) {
        return false; // 明显的通信错误
    }
    
    // 复位设备
    reset();
    delay(10);
    
    // 配置设备
    // CTRL1: 设置加速度计和陀螺仪ODR为125Hz
    writeRegister(QMI8658A_CTRL1, QMI8658A_ODR_125HZ);
    
    // CTRL2: 设置加速度计量程为8G
    writeRegister(QMI8658A_CTRL2, _accRange);
    
    // CTRL3: 设置陀螺仪量程为2048dps
    writeRegister(QMI8658A_CTRL3, _gyroRange);
    
    // CTRL7: 启用加速度计和陀螺仪
    writeRegister(QMI8658A_CTRL7, 0x03); // 0x03 = 启用加速度计和陀螺仪
    
    calculateScaleFactors();
    
    return true;
}

void QMI8658A::setAccRange(uint8_t range) {
    if (range > QMI8658A_ACC_RANGE_16G) {
        range = QMI8658A_ACC_RANGE_8G;
    }
    
    _accRange = range;
    writeRegister(QMI8658A_CTRL2, _accRange);
    calculateScaleFactors();
}

void QMI8658A::setGyroRange(uint8_t range) {
    if (range > QMI8658A_GYRO_RANGE_2048DPS) {
        range = QMI8658A_GYRO_RANGE_2048DPS;
    }
    
    _gyroRange = range;
    writeRegister(QMI8658A_CTRL3, _gyroRange);
    calculateScaleFactors();
}

void QMI8658A::setODR(uint8_t odr) {
    if (odr > QMI8658A_ODR_3_90625HZ) {
        odr = QMI8658A_ODR_125HZ;
    }
    
    writeRegister(QMI8658A_CTRL1, odr);
}

void QMI8658A::enableAcc(bool enable) {
    uint8_t ctrl7 = readRegister(QMI8658A_CTRL7);
    
    if (enable) {
        ctrl7 |= 0x01; // 设置bit 0为1，启用加速度计
    } else {
        ctrl7 &= ~0x01; // 设置bit 0为0，禁用加速度计
    }
    
    writeRegister(QMI8658A_CTRL7, ctrl7);
}

void QMI8658A::enableGyro(bool enable) {
    uint8_t ctrl7 = readRegister(QMI8658A_CTRL7);
    
    if (enable) {
        ctrl7 |= 0x02; // 设置bit 1为1，启用陀螺仪
    } else {
        ctrl7 &= ~0x02; // 设置bit 1为0，禁用陀螺仪
    }
    
    writeRegister(QMI8658A_CTRL7, ctrl7);
}

void QMI8658A::readAccel(float *x, float *y, float *z) {
    int16_t raw_x, raw_y, raw_z;
    readRawAccel(&raw_x, &raw_y, &raw_z);
    
    *x = raw_x * _accScale;
    *y = raw_y * _accScale;
    *z = raw_z * _accScale;
}

void QMI8658A::readGyro(float *x, float *y, float *z) {
    int16_t raw_x, raw_y, raw_z;
    readRawGyro(&raw_x, &raw_y, &raw_z);
    
    *x = raw_x * _gyroScale;
    *y = raw_y * _gyroScale;
    *z = raw_z * _gyroScale;
}

float QMI8658A::readTemperature() {
    int16_t raw_temp = readRawTemperature();
    
    // QMI8658A温度计算公式: T = raw_temp / 256.0 + 25.0
    return (raw_temp / 256.0f) + 25.0f;
}

void QMI8658A::readRawAccel(int16_t *x, int16_t *y, int16_t *z) {
    uint8_t buffer[6];
    readRegisters(QMI8658A_ACC_X_L, buffer, 6);
    
    *x = (int16_t)((buffer[1] << 8) | buffer[0]);
    *y = (int16_t)((buffer[3] << 8) | buffer[2]);
    *z = (int16_t)((buffer[5] << 8) | buffer[4]);
}

void QMI8658A::readRawGyro(int16_t *x, int16_t *y, int16_t *z) {
    uint8_t buffer[6];
    readRegisters(QMI8658A_GYRO_X_L, buffer, 6);
    
    *x = (int16_t)((buffer[1] << 8) | buffer[0]);
    *y = (int16_t)((buffer[3] << 8) | buffer[2]);
    *z = (int16_t)((buffer[5] << 8) | buffer[4]);
}

int16_t QMI8658A::readRawTemperature() {
    uint8_t buffer[2];
    readRegisters(QMI8658A_TEMP_L, buffer, 2);
    
    return (int16_t)((buffer[1] << 8) | buffer[0]);
}

uint8_t QMI8658A::getDeviceID() {
    return readRegister(QMI8658A_WHO_AM_I);
}

bool QMI8658A::selfTest() {
    // 简单的自检：检查设备ID
    uint8_t id = getDeviceID();
    return (id == 0x05);
}

void QMI8658A::reset() {
    // 软复位 - QMI8658A使用CTRL7寄存器进行复位
    writeRegister(QMI8658A_CTRL7, 0x80); // 设置CTRL7的bit 7为1，触发软复位
    delay(50); // 增加延时确保复位完成
    writeRegister(QMI8658A_CTRL7, 0x00); // 清除复位位
    delay(10);
}

void QMI8658A::writeRegister(uint8_t reg, uint8_t value) {
    _wire->beginTransmission(QMI8658A_ADDRESS);
    _wire->write(reg);
    _wire->write(value);
    _wire->endTransmission();
}

uint8_t QMI8658A::readRegister(uint8_t reg) {
    _wire->beginTransmission(QMI8658A_ADDRESS);
    _wire->write(reg);
    _wire->endTransmission(false);
    
    _wire->requestFrom(QMI8658A_ADDRESS, (uint8_t)1);
    if (_wire->available()) {
        return _wire->read();
    }
    return 0;
}

void QMI8658A::readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length) {
    _wire->beginTransmission(QMI8658A_ADDRESS);
    _wire->write(reg);
    _wire->endTransmission(false);
    
    _wire->requestFrom(QMI8658A_ADDRESS, length);
    for (uint8_t i = 0; i < length && _wire->available(); i++) {
        buffer[i] = _wire->read();
    }
}

void QMI8658A::calculateScaleFactors() {
    // 计算加速度计比例因子
    switch (_accRange) {
        case QMI8658A_ACC_RANGE_2G:
            _accScale = 2.0f / 32768.0f;
            break;
        case QMI8658A_ACC_RANGE_4G:
            _accScale = 4.0f / 32768.0f;
            break;
        case QMI8658A_ACC_RANGE_8G:
            _accScale = 8.0f / 32768.0f;
            break;
        case QMI8658A_ACC_RANGE_16G:
            _accScale = 16.0f / 32768.0f;
            break;
        default:
            _accScale = 8.0f / 32768.0f;
            break;
    }
    
    // 计算陀螺仪比例因子
    switch (_gyroRange) {
        case QMI8658A_GYRO_RANGE_16DPS:
            _gyroScale = 16.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_32DPS:
            _gyroScale = 32.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_64DPS:
            _gyroScale = 64.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_128DPS:
            _gyroScale = 128.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_256DPS:
            _gyroScale = 256.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_512DPS:
            _gyroScale = 512.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_1024DPS:
            _gyroScale = 1024.0f / 32768.0f;
            break;
        case QMI8658A_GYRO_RANGE_2048DPS:
            _gyroScale = 2048.0f / 32768.0f;
            break;
        default:
            _gyroScale = 2048.0f / 32768.0f;
            break;
    }
}