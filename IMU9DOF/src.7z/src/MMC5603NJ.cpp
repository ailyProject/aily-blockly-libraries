#include "MMC5603NJ.h"

MMC5603NJ::MMC5603NJ() {
    _magScale = 0.00625f; // MMC5603NJ: 1 LSB = 0.00625 uT (20位分辨率)
    _xOffset = 0.0f;
    _yOffset = 0.0f;
    _zOffset = 0.0f;
}

bool MMC5603NJ::begin(TwoWire *wire) {
    _wire = wire;
    
    // 检查设备ID (根据官方库，可能不需要严格检查)
    uint8_t id = getDeviceID();
    // 更宽松的设备ID检查，避免因ID变化导致初始化失败
    if (id == 0x00 || id == 0xFF) {
        return false; // 明显的通信错误
    }
    
    // 复位设备
    reset();
    delay(10);
    
    // 执行SET/RESET操作以消除残余磁场
    performSetReset();
    
    return true;
}

void MMC5603NJ::readMag(float *x, float *y, float *z) {
    int32_t raw_x, raw_y, raw_z;
    readRawMag(&raw_x, &raw_y, &raw_z);
    
    // 应用比例因子和偏移校正
    *x = (raw_x * _magScale) - _xOffset;
    *y = (raw_y * _magScale) - _yOffset;
    *z = (raw_z * _magScale) - _zOffset;
}

float MMC5603NJ::readTemperature() {
    uint8_t raw_temp = readRawTemperature();
    
    // MMC5603NJ温度计算公式: T = (raw_temp - 75) * 0.8 + 25
    return ((float)raw_temp - 75.0f) * 0.8f + 25.0f;
}

void MMC5603NJ::readRawMag(int32_t *x, int32_t *y, int32_t *z) {
    // 启动测量
    startMeasurement();
    
    // 等待测量完成
    waitForMeasurement();
    
    // 读取数据 - MMC5603NJ使用20位数据
    uint8_t buffer[9];
    readRegisters(MMC5603NJ_OUT_X_L, buffer, 9);
    
    // MMC5603NJ数据格式：每个轴20位，存储在3个字节中
    *x = ((uint32_t)buffer[0] << 12) | ((uint32_t)buffer[1] << 4) | (buffer[6] >> 4);
    *y = ((uint32_t)buffer[2] << 12) | ((uint32_t)buffer[3] << 4) | (buffer[7] >> 4);
    *z = ((uint32_t)buffer[4] << 12) | ((uint32_t)buffer[5] << 4) | (buffer[8] >> 4);
    
    // 将20位无符号值转换为有符号值 (中心值为524288)
    *x -= 524288;
    *y -= 524288;
    *z -= 524288;
}

uint8_t MMC5603NJ::readRawTemperature() {
    // 启动温度测量
    writeRegister(MMC5603NJ_CTRL0, MMC5603NJ_CTRL0_TM_T);
    
    // 等待温度测量完成
    while (!(readRegister(MMC5603NJ_STATUS) & MMC5603NJ_STATUS_MEAS_T_DONE)) {
        delay(1);
    }
    
    // 读取温度数据
    return readRegister(MMC5603NJ_OUT_TEMP);
}

void MMC5603NJ::calibrate() {
    // 简单的校准过程：收集多个样本并计算平均偏移
    const int samples = 10;
    float x_sum = 0, y_sum = 0, z_sum = 0;
    
    for (int i = 0; i < samples; i++) {
        float x, y, z;
        
        // 临时禁用偏移校正
        float temp_x_offset = _xOffset;
        float temp_y_offset = _yOffset;
        float temp_z_offset = _zOffset;
        _xOffset = 0.0f;
        _yOffset = 0.0f;
        _zOffset = 0.0f;
        
        // 读取磁力计数据
        readMag(&x, &y, &z);
        
        // 恢复偏移值
        _xOffset = temp_x_offset;
        _yOffset = temp_y_offset;
        _zOffset = temp_z_offset;
        
        // 累加样本
        x_sum += x;
        y_sum += y;
        z_sum += z;
        
        delay(50);
    }
    
    // 计算平均偏移
    _xOffset = x_sum / samples;
    _yOffset = y_sum / samples;
    _zOffset = z_sum / samples;
}

void MMC5603NJ::setOffset(float x_offset, float y_offset, float z_offset) {
    _xOffset = x_offset;
    _yOffset = y_offset;
    _zOffset = z_offset;
}

uint8_t MMC5603NJ::getDeviceID() {
    return readRegister(MMC5603NJ_WHO_AM_I);
}

bool MMC5603NJ::selfTest() {
    // 简单的自检：检查设备ID
    uint8_t id = getDeviceID();
    return (id == 0x10);
}

void MMC5603NJ::reset() {
    // 软复位
    writeRegister(MMC5603NJ_CTRL1, 0x80); // 设置CTRL1的bit 7为1，触发软复位
    delay(10);
}

bool MMC5603NJ::isDataReady() {
    uint8_t status = readRegister(MMC5603NJ_STATUS);
    return (status & MMC5603NJ_STATUS_MEAS_M_DONE) != 0;
}

void MMC5603NJ::writeRegister(uint8_t reg, uint8_t value) {
    _wire->beginTransmission(MMC5603NJ_ADDRESS);
    _wire->write(reg);
    _wire->write(value);
    _wire->endTransmission();
}

uint8_t MMC5603NJ::readRegister(uint8_t reg) {
    _wire->beginTransmission(MMC5603NJ_ADDRESS);
    _wire->write(reg);
    _wire->endTransmission(false);
    
    _wire->requestFrom(MMC5603NJ_ADDRESS, (uint8_t)1);
    if (_wire->available()) {
        return _wire->read();
    }
    return 0;
}

void MMC5603NJ::readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length) {
    _wire->beginTransmission(MMC5603NJ_ADDRESS);
    _wire->write(reg);
    _wire->endTransmission(false);
    
    _wire->requestFrom(MMC5603NJ_ADDRESS, length);
    for (uint8_t i = 0; i < length && _wire->available(); i++) {
        buffer[i] = _wire->read();
    }
}

void MMC5603NJ::startMeasurement() {
    // 启动磁力计测量
    writeRegister(MMC5603NJ_CTRL0, MMC5603NJ_CTRL0_TM_M);
}

void MMC5603NJ::waitForMeasurement() {
    // 等待测量完成
    while (!isDataReady()) {
        delay(1);
    }
}

void MMC5603NJ::performSetReset() {
    // 执行SET操作
    writeRegister(MMC5603NJ_CTRL0, MMC5603NJ_CTRL0_SET);
    delay(1);
    
    // 执行RESET操作
    writeRegister(MMC5603NJ_CTRL0, MMC5603NJ_CTRL0_RESET);
    delay(1);
}