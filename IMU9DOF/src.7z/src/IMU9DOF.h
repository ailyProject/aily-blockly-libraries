#ifndef IMU9DOF_H
#define IMU9DOF_H

#include <Arduino.h>
#include <Wire.h>
#include "QMI8658A.h"
#include "MMC5603NJ.h"

class IMU9DOF {
public:
    IMU9DOF();
    
    // 初始化函数
    bool begin(TwoWire *wire = &Wire);
    
    // 数据读取函数
    void readAccel(float *x, float *y, float *z);
    void readGyro(float *x, float *y, float *z);
    void readMag(float *x, float *y, float *z);
    float readTemperature();
    
    // 姿态角计算
    void computeAngles();
    float getRoll();    // 横滚角（绕X轴）
    float getPitch();   // 俯仰角（绕Y轴）
    float getYaw();     // 航向角（绕Z轴）
    
    // 校准函数
    void calibrateMag();
    void setMagOffset(float x_offset, float y_offset, float z_offset);
    
    // 配置函数
    void setAccRange(uint8_t range);
    void setGyroRange(uint8_t range);
    void setODR(uint8_t odr);
    
    // 获取传感器实例
    QMI8658A* getAccGyro() { return &_accGyro; }
    MMC5603NJ* getMag() { return &_mag; }
    
private:
    QMI8658A _accGyro;  // 六轴传感器（加速度计+陀螺仪）
    MMC5603NJ _mag;     // 三轴磁力计
    
    float _roll;        // 横滚角
    float _pitch;       // 俯仰角
    float _yaw;         // 航向角
    
    // 姿态角计算辅助函数
    float atan2_approximation(float y, float x);
};

#endif