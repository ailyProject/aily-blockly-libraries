#include "IMU9DOF.h"
#include <math.h>

IMU9DOF::IMU9DOF() {
    _roll = 0.0f;
    _pitch = 0.0f;
    _yaw = 0.0f;
}

bool IMU9DOF::begin(TwoWire *wire) {
    bool accGyroOk = _accGyro.begin(wire);
    bool magOk = _mag.begin(wire);
    
    return accGyroOk && magOk;
}

void IMU9DOF::readAccel(float *x, float *y, float *z) {
    _accGyro.readAccel(x, y, z);
}

void IMU9DOF::readGyro(float *x, float *y, float *z) {
    _accGyro.readGyro(x, y, z);
}

void IMU9DOF::readMag(float *x, float *y, float *z) {
    _mag.readMag(x, y, z);
}

float IMU9DOF::readTemperature() {
    // 使用加速度计/陀螺仪的温度传感器
    return _accGyro.readTemperature();
}

void IMU9DOF::computeAngles() {
    float ax, ay, az;
    float mx, my, mz;
    
    // 读取加速度计数据
    readAccel(&ax, &ay, &az);
    
    // 读取磁力计数据
    readMag(&mx, &my, &mz);
    
    // 计算俯仰角和横滚角（使用加速度计）
    _roll = atan2_approximation(ay, az) * 180.0f / PI;
    _pitch = atan2_approximation(-ax, sqrt(ay * ay + az * az)) * 180.0f / PI;
    
    // 计算航向角（使用磁力计，需要倾角补偿）
    float sinRoll = sin(_roll * PI / 180.0f);
    float cosRoll = cos(_roll * PI / 180.0f);
    float sinPitch = sin(_pitch * PI / 180.0f);
    float cosPitch = cos(_pitch * PI / 180.0f);
    
    // 倾角补偿
    float bx = mx * cosPitch + mz * sinPitch;
    float by = mx * sinRoll * sinPitch + my * cosRoll - mz * sinRoll * cosPitch;
    
    // 计算航向角
    _yaw = atan2_approximation(-by, bx) * 180.0f / PI;
    
    // 将航向角转换为0-360度范围
    if (_yaw < 0) {
        _yaw += 360.0f;
    }
}

float IMU9DOF::getRoll() {
    return _roll;
}

float IMU9DOF::getPitch() {
    return _pitch;
}

float IMU9DOF::getYaw() {
    return _yaw;
}

void IMU9DOF::calibrateMag() {
    _mag.calibrate();
}

void IMU9DOF::setMagOffset(float x_offset, float y_offset, float z_offset) {
    _mag.setOffset(x_offset, y_offset, z_offset);
}

void IMU9DOF::setAccRange(uint8_t range) {
    _accGyro.setAccRange(range);
}

void IMU9DOF::setGyroRange(uint8_t range) {
    _accGyro.setGyroRange(range);
}

void IMU9DOF::setODR(uint8_t odr) {
    _accGyro.setODR(odr);
}

// 快速反正切近似函数，比标准atan2快但精度略低
float IMU9DOF::atan2_approximation(float y, float x) {
    // 检查特殊情况
    if (x == 0.0f) {
        if (y > 0.0f) return PI / 2.0f;
        if (y < 0.0f) return -PI / 2.0f;
        return 0.0f; // 未定义，但返回0
    }
    
    float abs_y = fabs(y);
    float r, angle;
    
    if (x >= 0.0f) {
        r = (x - abs_y) / (x + abs_y);
        angle = (1.0f - r) * (PI / 4.0f);
    } else {
        r = (x + abs_y) / (abs_y - x);
        angle = (3.0f - r) * (PI / 4.0f);
    }
    
    return (y < 0.0f) ? -angle : angle;
}