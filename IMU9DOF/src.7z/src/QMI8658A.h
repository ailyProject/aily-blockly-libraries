#ifndef QMI8658A_H
#define QMI8658A_H

#include <Arduino.h>
#include <Wire.h>

// QMI8658A I2C地址 (根据官方库使用0x6B)
#define QMI8658A_ADDRESS 0x6B

// 寄存器地址
#define QMI8658A_WHO_AM_I        0x00
#define QMI8658A_REVISION_ID     0x01
#define QMI8658A_CTRL1           0x02
#define QMI8658A_CTRL2           0x03
#define QMI8658A_CTRL3           0x04
#define QMI8658A_CTRL4           0x05
#define QMI8658A_CTRL5           0x06
#define QMI8658A_CTRL6           0x07
#define QMI8658A_CTRL7           0x08
#define QMI8658A_FIFO_WTM_TH     0x09
#define QMI8658A_FIFO_CTRL       0x0A
#define QMI8658A_FIFO_SMPL_CNT   0x0B
#define QMI8658A_FIFO_STATUS     0x0C
#define QMI8658A_FIFO_DATA       0x0D

#define QMI8658A_ACC_X_L         0x35
#define QMI8658A_ACC_X_H         0x36
#define QMI8658A_ACC_Y_L         0x37
#define QMI8658A_ACC_Y_H         0x38
#define QMI8658A_ACC_Z_L         0x39
#define QMI8658A_ACC_Z_H         0x3A

#define QMI8658A_GYRO_X_L        0x3B
#define QMI8658A_GYRO_X_H        0x3C
#define QMI8658A_GYRO_Y_L        0x3D
#define QMI8658A_GYRO_Y_H        0x3E
#define QMI8658A_GYRO_Z_L        0x3F
#define QMI8658A_GYRO_Z_H        0x40

#define QMI8658A_TEMP_L          0x33
#define QMI8658A_TEMP_H          0x34

// 加速度计量程
#define QMI8658A_ACC_RANGE_2G    0x00
#define QMI8658A_ACC_RANGE_4G    0x01
#define QMI8658A_ACC_RANGE_8G    0x02
#define QMI8658A_ACC_RANGE_16G   0x03

// 陀螺仪量程
#define QMI8658A_GYRO_RANGE_16DPS   0x00
#define QMI8658A_GYRO_RANGE_32DPS   0x01
#define QMI8658A_GYRO_RANGE_64DPS   0x02
#define QMI8658A_GYRO_RANGE_128DPS  0x03
#define QMI8658A_GYRO_RANGE_256DPS  0x04
#define QMI8658A_GYRO_RANGE_512DPS  0x05
#define QMI8658A_GYRO_RANGE_1024DPS 0x06
#define QMI8658A_GYRO_RANGE_2048DPS 0x07

// 输出数据速率
#define QMI8658A_ODR_8000HZ      0x00
#define QMI8658A_ODR_4000HZ      0x01
#define QMI8658A_ODR_2000HZ      0x02
#define QMI8658A_ODR_1000HZ      0x03
#define QMI8658A_ODR_500HZ       0x04
#define QMI8658A_ODR_250HZ       0x05
#define QMI8658A_ODR_125HZ       0x06
#define QMI8658A_ODR_62_5HZ      0x07
#define QMI8658A_ODR_31_25HZ     0x08
#define QMI8658A_ODR_15_625HZ    0x09
#define QMI8658A_ODR_7_8125HZ    0x0A
#define QMI8658A_ODR_3_90625HZ   0x0B

class QMI8658A {
public:
    QMI8658A();
    
    // 初始化函数
    bool begin(TwoWire *wire = &Wire);
    
    // 配置函数
    void setAccRange(uint8_t range);
    void setGyroRange(uint8_t range);
    void setODR(uint8_t odr);
    void enableAcc(bool enable);
    void enableGyro(bool enable);
    
    // 数据读取函数
    void readAccel(float *x, float *y, float *z);
    void readGyro(float *x, float *y, float *z);
    float readTemperature();
    
    // 原始数据读取
    void readRawAccel(int16_t *x, int16_t *y, int16_t *z);
    void readRawGyro(int16_t *x, int16_t *y, int16_t *z);
    int16_t readRawTemperature();
    
    // 辅助函数
    uint8_t getDeviceID();
    bool selfTest();
    void reset();
    
private:
    TwoWire *_wire;
    uint8_t _accRange;
    uint8_t _gyroRange;
    float _accScale;
    float _gyroScale;
    
    // I2C通信函数
    void writeRegister(uint8_t reg, uint8_t value);
    uint8_t readRegister(uint8_t reg);
    void readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length);
    
    // 计算比例因子
    void calculateScaleFactors();
};

#endif