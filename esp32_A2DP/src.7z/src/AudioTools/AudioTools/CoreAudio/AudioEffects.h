#pragma once

#include "AudioTools/CoreAudio/AudioEffects/SoundGenerator.h"
#include "AudioTools/CoreAudio/AudioEffects/AudioEffects.h"
#include "AudioTools/CoreAudio/AudioEffects/PitchShift.h"
