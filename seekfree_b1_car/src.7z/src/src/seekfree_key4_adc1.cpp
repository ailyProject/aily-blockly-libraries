#include "seekfree_key4_adc1.h"




KEY4_ADC1::KEY4_ADC1()
{
    uint8_t i;
    for(i = 0; KEY_NUM > i; i++)
    {
        key_state[i] = 0;
    }
}

KEY4_ADC1::~KEY4_ADC1()
{

}

void KEY4_ADC1::scan(void *parameter)
{
    const int16_t key_adc_value[KEY_NUM] = {0, 70, 167, 222};
    const int16_t key_adc_range = 10;

    uint8_t i;
    uint16_t adc_value;
    int16_t start_value, end_value;
    static uint16_t key_press_num[KEY_NUM];
    KEY4_ADC1* instance = static_cast<KEY4_ADC1*>(parameter);
    while(1)
    {
        adc_value = analogReadMilliVolts(4) / 10;

        for(i = 0; KEY_NUM > i; i++)
        {
            start_value = key_adc_value[i] - key_adc_range;
            end_value = key_adc_value[i] + key_adc_range;
            if((start_value < adc_value) && (end_value > adc_value))
            {
                key_press_num[i]++;

                if(100 <= key_press_num[i])
                {
                    instance->key_state[i] = 2;   // 长按
                }
                else if(3 <= key_press_num[i])
                {
                    instance->key_state[i] = 1;   // 短按
                }
            }
            else
            {
                if(10 <= key_press_num[i])
                {
                    instance->key_state[i] = 3;
                }
                key_press_num[i] = 0;
            }
        }

        vTaskDelay(10);
    }
}

uint8_t KEY4_ADC1::read_state(uint8_t key_id, uint8_t state)
{
    uint8_t temp = 0;

    if(KEY_NUM < key_id)
    {
        key_id = KEY_NUM - 1;
    }
	
	if(key_state[key_id] == state)
	{
		temp = 1;
	}

    if(KEY_RELEASE == key_state[key_id])
    {
        // 当按键已经放开的时候，读取此状态之后将自动清除
        key_state[key_id] = 0;
    }

    return temp;
}


void KEY4_ADC1::begin(void)
{
    // 初始化ADC设备
    analogReadResolution(12);
    analogSetAttenuation(ADC_11db);

    // 创建按键扫描线程
    xTaskCreate(KEY4_ADC1::scan, "key", 1024, this, 15, NULL);
}