#ifndef _seekfree_expansion_ch422_h_
#define _seekfree_expansion_ch422_h_

#include <Arduino.h> 


class CH422
{
    private:
        uint16_t eoc;
        uint8_t eio;
        void    write_reg       (uint8_t reg_addr, uint8_t dat);// 写一个寄存器


    public:
        CH422();
        ~CH422();
        void    begin           (void); // 初始化
        void    set_beep        (uint8_t state);    // 设置蜂鸣器状态   1：打开  0：关闭
        void    set_red_led     (uint8_t state);    // 设置LED状态      1：打开  0：关闭
        void    set_green_led   (uint8_t state);
        void    set_blue_led    (uint8_t state);

        // 设置MOS状态，仅用于内部模块进行调用   不需要对外
        void    set_power       (uint8_t pin_index, uint8_t state); 
};





#endif
