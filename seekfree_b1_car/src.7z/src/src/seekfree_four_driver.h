#ifndef _seekfree_four_driver_h_
#define _seekfree_four_driver_h_

#include <Arduino.h> 


typedef enum
{
    MOTOR_IDLE,
    MOTOR_SPEED,
    MOTOR_DISTANCE,
    MOTOR_DUTY,
}motor_mode_enum;

class FOUR_DRIVER
{
    private:
        float car_dir;  // 保存当前车模车头角度
        void angle_limit(float &angle);

        uint8_t set_id              (uint16_t now_id, uint8_t set_id);
        
        uint8_t set_can_res         (uint16_t id, uint8_t state);
        uint8_t set_duty            (uint16_t id, int16_t duty);
        uint8_t set_distance        (uint16_t id, uint16_t channel, int16_t speed, int16_t distance);
        uint8_t clear_encoder       (uint16_t id, uint8_t channel);
        uint8_t set_reversal        (uint16_t id, uint8_t state1, uint8_t state2, uint8_t state3, uint8_t state4);

        uint8_t get_id              (uint16_t can_id, uint16_t &read_id);
        // uint8_t get_speed       (void);
        // uint8_t get_distance    (void);
        // uint8_t get_duty        (void);
        // uint8_t clear_encoder   (void);
        // uint8_t get_reversal    (void);
        uint8_t get_encoder         (uint16_t id, uint8_t channel, int32_t &encoder);
        uint8_t get_version         (uint16_t id);

        // 四模组快捷操作
        uint8_t get_encoder_all     (int32_t &distance, uint8_t flag_abs);
        uint8_t clear_encoder_all   (void);

        uint8_t walk                (int32_t distance, int16_t speed);
        uint8_t walk2               (int32_t distance, int16_t speed);


    public:
        FOUR_DRIVER();
        ~FOUR_DRIVER();

        uint8_t main_ver;   // 主版本
        uint8_t midd_ver;   // 中版本
        uint8_t micr_ver;   // 小版本
		
		uint8_t set_speed_ready     (uint16_t id);
		uint8_t set_speed           (uint16_t id, uint16_t channel, int16_t speed);
		uint8_t set_speed_all       (int16_t speed, int16_t turn_speed);
		
        //-------------------------------------------------------------------------------------------------------------------
        // 函数简介     车体移动
        // 参数说明     direction       1：前进 2：后退 3：左移 4：右移
        // 参数说明     distance        行进距离，单位厘米
        // 参数说明     speed           行进速度，单位厘米/秒
        // 返回参数     uint8_t         1：执行失败 0：执行成功
        // 使用示例     move(1, 80, 100);
        //-------------------------------------------------------------------------------------------------------------------
        uint8_t move                (uint8_t direction, int16_t speed, int32_t distance);

        //-------------------------------------------------------------------------------------------------------------------
        // 函数简介     车体旋转
        // 参数说明     angle           旋转角度，正数左转，负数右转
        // 参数说明     speed           旋转时电机的速度，单位厘米/秒
        // 返回参数     uint8_t         1：执行失败 0：执行成功
        // 使用示例     turn(90, 50);
        //-------------------------------------------------------------------------------------------------------------------
        uint8_t turn                (int16_t angle, uint16_t speed);

        //-------------------------------------------------------------------------------------------------------------------
        // 函数简介     追踪目标
        // 参数说明     x               目标的X坐标
        // 参数说明     y               目标的Y坐标
        // 返回参数     uint8_t         0：正在追踪 1：追踪完成
        // 使用示例     track(10, 15);
        //-------------------------------------------------------------------------------------------------------------------
        uint8_t track               (int16_t x, int16_t y);

        uint8_t begin               (uint8_t power_index); // 初始化
};



#endif
