#include "ES8388.h"

ES8388::ES8388(uint8_t sda, uint8_t scl, uint32_t speed) {
  _pinsda = sda;
  _pinscl = scl;
  _i2cspeed = speed;
  _i2s_initialized = false;
  _state = ES8388_STATE_IDLE;
  _record_buffer = nullptr;
  _record_buffer_size = 0;
  _recorded_samples = 0;
  _sample_rate = 44100;
  _i2s_port = I2S_NUM_0;
}

ES8388::~ES8388() {
  freeRecordBuffer();
  if (_i2s_initialized) {
    i2s_driver_uninstall(_i2s_port);
  }
}

bool ES8388::begin(uint32_t sample_rate, 
                   uint8_t mck_pin, uint8_t bck_pin, uint8_t ws_pin,
                   uint8_t data_out_pin, uint8_t data_in_pin,
                   i2s_port_t i2s_port) {
  
  _sample_rate = sample_rate;
  _i2s_port = i2s_port;
  
  // 配置I2S引脚
  _pin_config.mck_io_num = mck_pin;
  _pin_config.bck_io_num = bck_pin;
  _pin_config.ws_io_num = ws_pin;
  _pin_config.data_out_num = data_out_pin;
  _pin_config.data_in_num = data_in_pin;
  
  // 初始化I2C
  i2c.begin(_pinsda, _pinscl, _i2cspeed);
  
  // 扫描I2C设备
  scanI2C();
  
  // 初始化ES8388芯片
  if (!initES8388()) {
    Serial.println("ES8388 initialization failed!");
    return false;
  }
  
  // 初始化I2S
  if (!initI2S()) {
    Serial.println("I2S initialization failed!");
    return false;
  }
  
  Serial.println("ES8388 initialized successfully!");
  return true;
}

bool ES8388::initES8388() {
  bool res = true;
  
  /* INITIALIZATION (BASED ON ES8388 USER GUIDE EXAMPLE) */
  // Set Chip to Slave
  res &= write_reg(ES8388_MASTERMODE, 0x00);
  // Power down DEM and STM
  res &= write_reg(ES8388_CHIPPOWER, 0xFF);
  // Set same LRCK
  res &= write_reg(ES8388_DACCONTROL21, 0x80);
  // Set Chip to Play&Record Mode
  res &= write_reg(ES8388_CONTROL1, 0x05);
  // Power Up Analog and Ibias
  res &= write_reg(ES8388_CONTROL2, 0x40);

  /* ADC setting */
  res &= write_reg(ES8388_ADCPOWER, 0x00);
  res &= write_reg(ES8388_ADCCONTROL2, 0x50);
  res &= write_reg(ES8388_ADCCONTROL3, 0x80);
  res &= write_reg(ES8388_ADCCONTROL1, 0x77);
  res &= write_reg(ES8388_ADCCONTROL4, 0x0C);
  res &= write_reg(ES8388_ADCCONTROL5, 0x02);
  res &= write_reg(ES8388_ADCCONTROL8, 0x00);
  res &= write_reg(ES8388_ADCCONTROL9, 0x00);
  res &= write_reg(ES8388_ADCCONTROL10, 0xEA);
  res &= write_reg(ES8388_ADCCONTROL11, 0xC0);
  res &= write_reg(ES8388_ADCCONTROL12, 0x12);
  res &= write_reg(ES8388_ADCCONTROL13, 0x06);
  res &= write_reg(ES8388_ADCCONTROL14, 0xC3);

  /* DAC setting */
  res &= write_reg(ES8388_DACPOWER, 0x3C);
  res &= write_reg(ES8388_DACCONTROL1, 0x18);
  res &= write_reg(ES8388_DACCONTROL2, 0x02);
  res &= write_reg(ES8388_DACCONTROL3, 0x00);
  res &= write_reg(ES8388_DACCONTROL4, 0x00);
  res &= write_reg(ES8388_DACCONTROL5, 0x00);
  res &= write_reg(ES8388_DACCONTROL16, 0x09);
  res &= write_reg(ES8388_DACCONTROL17, 0x50);
  res &= write_reg(ES8388_DACCONTROL18, 0x38);
  res &= write_reg(ES8388_DACCONTROL19, 0x38);
  res &= write_reg(ES8388_DACCONTROL20, 0x50);
  res &= write_reg(ES8388_DACCONTROL24, 0x1E);
  res &= write_reg(ES8388_DACCONTROL25, 0x1E);
  res &= write_reg(ES8388_DACCONTROL26, 0x1E);
  res &= write_reg(ES8388_DACCONTROL27, 0x1E);

  /* Power up DEM and STM */
  res &= write_reg(ES8388_CHIPPOWER, 0x00);
  
  // 默认配置
  inputSelect(IN1);
  setInputGain(8);
  outputSelect(OUTALL);
  setOutputVolume(20);
  mixerSourceSelect(MIXADC, MIXADC);
  mixerSourceControl(DACOUT);
  
  return res;
}

bool ES8388::initI2S() {
  _i2s_config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX);
  _i2s_config.sample_rate = _sample_rate;
  _i2s_config.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  _i2s_config.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  _i2s_config.communication_format = I2S_COMM_FORMAT_I2S;
  _i2s_config.intr_alloc_flags = 0;
  _i2s_config.dma_buf_count = 8;
  _i2s_config.dma_buf_len = 256;
  _i2s_config.use_apll = false;
  _i2s_config.tx_desc_auto_clear = true;
  _i2s_config.fixed_mclk = 0;

  esp_err_t err = i2s_driver_install(_i2s_port, &_i2s_config, 0, NULL);
  if (err != ESP_OK) {
    Serial.printf("I2S driver install failed: %d\n", err);
    return false;
  }

  err = i2s_set_pin(_i2s_port, &_pin_config);
  if (err != ESP_OK) {
    Serial.printf("I2S set pin failed: %d\n", err);
    i2s_driver_uninstall(_i2s_port);
    return false;
  }

  _i2s_initialized = true;
  return true;
}

bool ES8388::startRecording(float duration_seconds) {
  if (_state != ES8388_STATE_IDLE) {
    Serial.println("ES8388 is not in idle state!");
    return false;
  }
  
  if (!allocateRecordBuffer(duration_seconds)) {
    Serial.println("Failed to allocate record buffer!");
    return false;
  }
  
  _recorded_samples = 0;
  _state = ES8388_STATE_RECORDING;
  
  Serial.printf("Started recording for %.2f seconds...\n", duration_seconds);
  
  size_t bytes_read;
  int16_t temp_buffer[256];
  uint32_t start_time = millis();
  uint32_t duration_ms = (uint32_t)(duration_seconds * 1000);
  
  while ((millis() - start_time) < duration_ms && _recorded_samples < _record_buffer_size/2) {
    esp_err_t result = i2s_read(_i2s_port, temp_buffer, sizeof(temp_buffer), &bytes_read, 100);
    
    if (result == ESP_OK && bytes_read > 0) {
      size_t samples_read = bytes_read / sizeof(int16_t);
      size_t samples_to_copy = min(samples_read, (_record_buffer_size/2) - _recorded_samples);
      
      memcpy(_record_buffer + _recorded_samples, temp_buffer, samples_to_copy * sizeof(int16_t));
      _recorded_samples += samples_to_copy;
    }
  }
  
  _state = ES8388_STATE_IDLE;
  Serial.printf("Recording completed. Recorded %d samples\n", _recorded_samples);
  return true;
}

bool ES8388::stopRecording() {
  if (_state == ES8388_STATE_RECORDING) {
    _state = ES8388_STATE_IDLE;
    return true;
  }
  return false;
}

bool ES8388::startPlayback() {
  if (_state != ES8388_STATE_IDLE || _record_buffer == nullptr || _recorded_samples == 0) {
    Serial.println("No recorded data to play!");
    return false;
  }
  
  _state = ES8388_STATE_PLAYING;
  Serial.println("Starting playback...");
  
  size_t bytes_written;
  size_t samples_played = 0;
  
  while (samples_played < _recorded_samples && _state == ES8388_STATE_PLAYING) {
    size_t samples_to_play = min((size_t)256, _recorded_samples - samples_played);
    
    esp_err_t result = i2s_write(_i2s_port, 
                                _record_buffer + samples_played, 
                                samples_to_play * sizeof(int16_t), 
                                &bytes_written, 
                                1000);
    
    if (result == ESP_OK) {
      samples_played += bytes_written / sizeof(int16_t);
    } else {
      Serial.printf("I2S write error: %d\n", result);
      break;
    }
    
    delay(1); // 避免看门狗重置
  }
  
  _state = ES8388_STATE_IDLE;
  Serial.println("Playback completed.");
  return true;
}

bool ES8388::stopPlayback() {
  if (_state == ES8388_STATE_PLAYING) {
    _state = ES8388_STATE_IDLE;
    return true;
  }
  return false;
}

bool ES8388::recordAndPlay(float duration_seconds) {
  if (!startRecording(duration_seconds)) {
    return false;
  }
  
  delay(100); // 短暂延时
  return startPlayback();
}

bool ES8388::enablePassthrough() {
  Serial.println("Enabling audio passthrough...");
  return analogBypass(false); // 通过DAC输出
}

bool ES8388::disablePassthrough() {
  Serial.println("Disabling audio passthrough...");
  return DACmute(true);
}

void ES8388::processAudio() {
  if (_state != ES8388_STATE_IDLE) return;
  
  static int16_t rxbuf[256], txbuf[256];
  size_t bytes_read;
  
  esp_err_t result = i2s_read(_i2s_port, rxbuf, sizeof(rxbuf), &bytes_read, 10);
  
  if (result == ESP_OK && bytes_read > 0) {
    // 直接将接收到的数据发送到输出
    memcpy(txbuf, rxbuf, bytes_read);
    
    size_t bytes_written;
    i2s_write(_i2s_port, txbuf, bytes_read, &bytes_written, 10);
  }
}

bool ES8388::allocateRecordBuffer(float duration_seconds) {
  freeRecordBuffer();
  
  // 计算所需缓冲区大小 (立体声, 16位)
  _record_buffer_size = (size_t)(duration_seconds * _sample_rate * 2 * sizeof(int16_t));
  _record_buffer = (int16_t*)malloc(_record_buffer_size);
  
  if (_record_buffer == nullptr) {
    Serial.printf("Failed to allocate %d bytes for recording buffer!\n", _record_buffer_size);
    return false;
  }
  
  Serial.printf("Allocated %d bytes for %.2f seconds of recording\n", 
                _record_buffer_size, duration_seconds);
  return true;
}

void ES8388::freeRecordBuffer() {
  if (_record_buffer != nullptr) {
    free(_record_buffer);
    _record_buffer = nullptr;
    _record_buffer_size = 0;
    _recorded_samples = 0;
  }
}

void ES8388::scanI2C() {
  Serial.println("I2C Scan Start:");
  for (uint8_t addr = 1; addr < 127; addr++) {
    i2c.beginTransmission(addr);
    if (i2c.endTransmission() == 0) {
      Serial.printf("Found I2C device at 0x%02X\n", addr);
    }
  }
  Serial.println("I2C Scan End.");
}

// 状态查询方法
bool ES8388::isRecording() { return _state == ES8388_STATE_RECORDING; }
bool ES8388::isPlaying() { return _state == ES8388_STATE_PLAYING; }
es8388_state_t ES8388::getState() { return _state; }
size_t ES8388::getRecordedSamples() { return _recorded_samples; }
float ES8388::getRecordedDuration() { 
  return (float)_recorded_samples / (_sample_rate * 2); // 立体声
}

// 以下是原有的寄存器操作方法实现
bool ES8388::write_reg(uint8_t reg_add, uint8_t data) {
  i2c.beginTransmission(ES8388_ADDR);
  i2c.write(reg_add);
  i2c.write(data);
  return i2c.endTransmission() == 0;
}

bool ES8388::read_reg(uint8_t reg_add, uint8_t& data) {
  bool retval = false;
  i2c.beginTransmission(ES8388_ADDR);
  i2c.write(reg_add);
  i2c.endTransmission(false);
  i2c.requestFrom((uint16_t)ES8388_ADDR, (uint8_t)1, true);
  if (i2c.available() >= 1) {
    data = i2c.read();
    retval = true;
  }
  return retval;
}

bool ES8388::identify(int sda, int scl, uint32_t frequency) {
  if (sda >= 0 && scl >= 0) {
    i2c.begin(sda, scl, frequency);
  }
  i2c.beginTransmission(ES8388_ADDR);
  return i2c.endTransmission() == 0;
}

uint8_t* ES8388::readAllReg() {
  static uint8_t reg[53];
  for (uint8_t i = 0; i < 53; i++) {
    read_reg(i, reg[i]);
  }
  return reg;
}

// ...existing code... (保留原有的其他方法实现)
bool ES8388::outputSelect(outsel_t _sel) {
  bool res = true;
  if (_sel == OUTALL)
    res &= write_reg(ES8388_DACPOWER, 0x3C);
  else if (_sel == OUT1)
    res &= write_reg(ES8388_DACPOWER, 0x30);
  else if (_sel == OUT2)
    res &= write_reg(ES8388_DACPOWER, 0x0C);
  _outSel = _sel;
  return res;
}

bool ES8388::inputSelect(insel_t sel) {
  bool res = true;
  if (sel == IN1)
    res &= write_reg(ES8388_ADCCONTROL2, 0x00);
  else if (sel == IN2)
    res &= write_reg(ES8388_ADCCONTROL2, 0x50);
  else if (sel == IN1DIFF) {
    res &= write_reg(ES8388_ADCCONTROL2, 0xF0);
    res &= write_reg(ES8388_ADCCONTROL3, 0x00);
  } else if (sel == IN2DIFF) {
    res &= write_reg(ES8388_ADCCONTROL2, 0xF0);
    res &= write_reg(ES8388_ADCCONTROL3, 0x80);
  }
  _inSel = sel;
  return res;
}

bool ES8388::DACmute(bool mute) {
  uint8_t _reg;
  read_reg(ES8388_DACCONTROL3, _reg);
  bool res = true;
  if (mute)
    res &= write_reg(ES8388_DACCONTROL3, _reg | 0x04);
  else
    res &= write_reg(ES8388_DACCONTROL3, _reg & ~(0x04));
  return res;
}

bool ES8388::setOutputVolume(uint8_t vol) {
  if (vol > 33) vol = 33;
  bool res = true;
  if (_outSel == OUTALL || _outSel == OUT1) {
    res &= write_reg(ES8388_DACCONTROL24, vol);
    res &= write_reg(ES8388_DACCONTROL25, vol);
  } 
  if (_outSel == OUTALL || _outSel == OUT2) {
    res &= write_reg(ES8388_DACCONTROL26, vol);
    res &= write_reg(ES8388_DACCONTROL27, vol);
  }
  return res;
}

uint8_t ES8388::getOutputVolume() {
  static uint8_t _reg;
  if(_outSel == OUT1)
    read_reg(ES8388_DACCONTROL24, _reg);
  else if(_outSel == OUT2)
    read_reg(ES8388_DACCONTROL26, _reg);
  return _reg;
}

bool ES8388::setInputGain(uint8_t gain) {
  if (gain > 8) gain = 8;
  bool res = true;
  gain = (gain << 4) | gain;
  res &= write_reg(ES8388_ADCCONTROL1, gain);
  return res;
}

uint8_t ES8388::getInputGain() {
  static uint8_t _reg;
  read_reg(ES8388_ADCCONTROL1, _reg);
  _reg = _reg & 0x0F;
  return _reg;
}

bool ES8388::setALCmode(alcmodesel_t alc) {
  bool res = true;
  uint8_t ALCSEL = 0b11;
  uint8_t ALCLVL = 0b0011;
  uint8_t MAXGAIN = 0b111;
  uint8_t MINGAIN = 0b000;
  uint8_t ALCHLD = 0b0000;
  uint8_t ALCDCY = 0b0101;
  uint8_t ALCATK = 0b0111;
  uint8_t ALCMODE = 0b0;
  uint8_t ALCZC = 0b0;
  uint8_t TIME_OUT = 0b0;
  uint8_t NGAT = 0b1;
  uint8_t NGTH = 0b10001;
  uint8_t NGG = 0b00;
  uint8_t WIN_SIZE = 0b00110;

  if (alc == DISABLE)
    ALCSEL = 0b00;
  else if (alc == MUSIC) {
    ALCDCY = 0b1010;
    ALCATK = 0b0110;
    NGTH = 0b01011;
  } else if (alc == VOICE) {
    ALCLVL = 0b1100;
    MAXGAIN = 0b101;
    MINGAIN = 0b010;
    ALCDCY = 0b0001;
    ALCATK = 0b0010;
    NGTH = 0b11000;
    NGG = 0b01;
    res &= write_reg(ES8388_ADCCONTROL1, 0x77);
  }
  
  res &= write_reg(ES8388_ADCCONTROL10, ALCSEL << 6 | MAXGAIN << 3 | MINGAIN);
  res &= write_reg(ES8388_ADCCONTROL11, ALCLVL << 4 | ALCHLD);
  res &= write_reg(ES8388_ADCCONTROL12, ALCDCY << 4 | ALCATK);
  res &= write_reg(ES8388_ADCCONTROL13, ALCMODE << 7 | ALCZC << 6 | TIME_OUT << 5 | WIN_SIZE);
  res &= write_reg(ES8388_ADCCONTROL14, NGTH << 3 | NGG << 2 | NGAT);
  
  return res;
}

bool ES8388::mixerSourceSelect(mixsel_t LMIXSEL, mixsel_t RMIXSEL) {
  bool res = true;
  uint8_t _reg;
  _reg = (LMIXSEL << 3) | RMIXSEL;
  res &= write_reg(ES8388_DACCONTROL16, _reg);
  return res;
}

bool ES8388::mixerSourceControl(bool LD2LO, bool LI2LO, uint8_t LI2LOVOL,
                                bool RD2RO, bool RI2RO, uint8_t RI2LOVOL) {
  bool res = true;
  uint8_t _regL, _regR;
  if (LI2LOVOL > 7) LI2LOVOL = 7;
  if (RI2LOVOL > 7) RI2LOVOL = 7;
  _regL = (LD2LO << 7) | (LI2LO << 6) | (LI2LOVOL << 3);
  _regR = (RD2RO << 7) | (RI2RO << 6) | (RI2LOVOL << 3);
  res &= write_reg(ES8388_DACCONTROL17, _regL);
  res &= write_reg(ES8388_DACCONTROL20, _regR);
  return res;
}

bool ES8388::mixerSourceControl(mixercontrol_t mix) {
  bool res = true;
  if (mix == DACOUT)
    mixerSourceControl(true, false, 2, true, false, 2);
  else if (mix == SRCSELOUT)
    mixerSourceControl(false, true, 2, false, true, 2);
  else if (mix == MIXALL)
    mixerSourceControl(true, true, 2, true, true, 2);
  return res;
}

bool ES8388::analogBypass(bool bypass) {
  bool res = true;
  if (bypass) {
    if (_inSel == IN1)
      mixerSourceSelect(MIXIN1, MIXIN1);
    else if (_inSel == IN2)
      mixerSourceSelect(MIXIN2, MIXIN2);
    mixerSourceControl(false, true, 2, false, true, 2);
  } else {
    mixerSourceControl(true, false, 2, true, false, 2);
  }
  return res;
}