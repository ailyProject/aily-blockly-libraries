#ifndef ES8388_H_
#define ES8388_H_

#include <Arduino.h>
#include <Wire.h>
#include "driver/i2s.h"
#pragma once
#include <stdint.h>

// ES8388 寄存器定义
#define ES8388_ADDR 0x10
#define ES8388_CONTROL1 0x00
#define ES8388_CONTROL2 0x01
#define ES8388_CHIPPOWER 0x02
#define ES8388_ADCPOWER 0x03
#define ES8388_DACPOWER 0x04
#define ES8388_CHIPLOPOW1 0x05
#define ES8388_CHIPLOPOW2 0x06
#define ES8388_ANAVOLMANAG 0x07
#define ES8388_MASTERMODE 0x08
#define ES8388_ADCCONTROL1 0x09
#define ES8388_ADCCONTROL2 0x0a
#define ES8388_ADCCONTROL3 0x0b
#define ES8388_ADCCONTROL4 0x0c
#define ES8388_ADCCONTROL5 0x0d
#define ES8388_ADCCONTROL6 0x0e
#define ES8388_ADCCONTROL7 0x0f
#define ES8388_ADCCONTROL8 0x10
#define ES8388_ADCCONTROL9 0x11
#define ES8388_ADCCONTROL10 0x12
#define ES8388_ADCCONTROL11 0x13
#define ES8388_ADCCONTROL12 0x14
#define ES8388_ADCCONTROL13 0x15
#define ES8388_ADCCONTROL14 0x16
#define ES8388_DACCONTROL1 0x17
#define ES8388_DACCONTROL2 0x18
#define ES8388_DACCONTROL3 0x19
#define ES8388_DACCONTROL4 0x1a
#define ES8388_DACCONTROL5 0x1b
#define ES8388_DACCONTROL6 0x1c
#define ES8388_DACCONTROL7 0x1d
#define ES8388_DACCONTROL8 0x1e
#define ES8388_DACCONTROL9 0x1f
#define ES8388_DACCONTROL10 0x20
#define ES8388_DACCONTROL11 0x21
#define ES8388_DACCONTROL12 0x22
#define ES8388_DACCONTROL13 0x23
#define ES8388_DACCONTROL14 0x24
#define ES8388_DACCONTROL15 0x25
#define ES8388_DACCONTROL16 0x26
#define ES8388_DACCONTROL17 0x27
#define ES8388_DACCONTROL18 0x28
#define ES8388_DACCONTROL19 0x29
#define ES8388_DACCONTROL20 0x2a
#define ES8388_DACCONTROL21 0x2b
#define ES8388_DACCONTROL22 0x2c
#define ES8388_DACCONTROL23 0x2d
#define ES8388_DACCONTROL24 0x2e
#define ES8388_DACCONTROL25 0x2f
#define ES8388_DACCONTROL26 0x30
#define ES8388_DACCONTROL27 0x31
#define ES8388_DACCONTROL28 0x32
#define ES8388_DACCONTROL29 0x33
#define ES8388_DACCONTROL30 0x34

typedef enum {
  MIXIN1,  // direct line 1
  MIXIN2,  // direct line 2
  MIXRES,  // reserved es8388
  MIXADC   // Select from ADC/ALC
} mixsel_t;

typedef enum {
  OUT1,    // Select Line OUT L/R 1
  OUT2,    // Select Line OUT L/R 2
  OUTALL,  // Enable ALL
} outsel_t;

typedef enum {
  IN1,      // Select Line IN L/R 1
  IN2,      // Select Line IN L/R 2
  IN1DIFF,  // differential IN L/R 1
  IN2DIFF   // differential IN L/R 2
} insel_t;

typedef enum {
  DACOUT,     // Select Sink From DAC
  SRCSELOUT,  // Select Sink From SourceSelect()
  MIXALL,     // Sink ALL DAC & SourceSelect()
} mixercontrol_t;

typedef enum {
  DISABLE,  // Disable ALC
  GENERIC,  // Generic Mode
  VOICE,    // Voice Mode
  MUSIC     // Music Mode
} alcmodesel_t;

typedef enum {
  ES8388_STATE_IDLE,
  ES8388_STATE_RECORDING,
  ES8388_STATE_PLAYING,
  ES8388_STATE_ERROR
} es8388_state_t;

class ES8388 {
private:
  outsel_t _outSel = OUTALL;
  insel_t _inSel = IN1;
  TwoWire i2c = TwoWire(0);
  uint8_t _pinsda, _pinscl;
  uint32_t _i2cspeed;
  
  // I2S 配置
  i2s_port_t _i2s_port;
  i2s_config_t _i2s_config;
  i2s_pin_config_t _pin_config;
  bool _i2s_initialized;
  
  // 录音播放状态
  es8388_state_t _state;
  int16_t* _record_buffer;
  size_t _record_buffer_size;
  size_t _recorded_samples;
  uint32_t _sample_rate;
  
  // 私有方法
  bool write_reg(uint8_t reg_add, uint8_t data);
  bool read_reg(uint8_t reg_add, uint8_t& data);
  bool initES8388();
  bool initI2S();

public:
  ES8388(uint8_t _sda, uint8_t _scl, uint32_t _speed);
  ~ES8388();
  
  // 原有方法 - 保持兼容性
  bool init();
  bool identify(int sda, int scl, uint32_t frequency);
  uint8_t* readAllReg();
  bool outputSelect(outsel_t sel);
  bool inputSelect(insel_t sel);
  bool DACmute(bool mute);
  uint8_t getOutputVolume();
  bool setOutputVolume(uint8_t vol);
  uint8_t getInputGain();
  bool setInputGain(uint8_t gain);
  bool setALCmode(alcmodesel_t alc);
  bool mixerSourceSelect(mixsel_t LMIXSEL, mixsel_t RMIXSEL);
  bool mixerSourceControl(bool LD2LO, bool LI2LO, uint8_t LI2LOVOL, bool RD2RO,
                          bool RI2RO, uint8_t RI2LOVOL);
  bool mixerSourceControl(mixercontrol_t mix);
  bool analogBypass(bool bypass);
  
  // 新增方法 - I2S和录放音功能
  bool begin(uint32_t sample_rate = 44100, 
             uint8_t mck_pin = 39, uint8_t bck_pin = 41, uint8_t ws_pin = 42,
             uint8_t data_out_pin = 38, uint8_t data_in_pin = 40,
             i2s_port_t i2s_port = I2S_NUM_0);
  
  // 录音播放功能
  bool startRecording(float duration_seconds);
  bool stopRecording();
  bool startPlayback();
  bool stopPlayback();
  bool isRecording();
  bool isPlaying();
  es8388_state_t getState();
  size_t getRecordedSamples();
  float getRecordedDuration();
  
  // 录音播放一体化功能
  bool recordAndPlay(float duration_seconds);
  
  // 实时录放音
  bool enablePassthrough();
  bool disablePassthrough();
  void processAudio();
  
  // 缓冲区管理
  bool allocateRecordBuffer(float duration_seconds);
  void freeRecordBuffer();
  
  // I2C扫描
  void scanI2C();
};

#endif