#ifndef _MA_MATH_H
#define _MA_MATH_H

#include "ma_math_scalars.h"
#include "ma_math_vectors.h"
#include "ma_math_matrix.h"

#endif  // _MA_MATH_H
