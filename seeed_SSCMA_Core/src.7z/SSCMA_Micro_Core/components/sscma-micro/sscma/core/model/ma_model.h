#ifndef _MA_MODEL_H_
#define _MA_MODEL_H_

#include "../model/ma_model_base.h"
#include "../model/ma_model_factory.h"

#endif  // _MA_MODEL_H_