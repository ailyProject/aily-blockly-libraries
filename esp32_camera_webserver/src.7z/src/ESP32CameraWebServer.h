#ifndef ESP32_CAMERA_WEBSERVER_H
#define ESP32_CAMERA_WEBSERVER_H

// 摄像头型号定义会在用户代码中通过 #define 设置
// 例如: #define CAMERA_MODEL_AI_THINKER

// 根据定义的摄像头型号包含对应的引脚配置
#include "camera_pins.h"

// HTTP服务器相关
#include "app_httpd.h"

// 如果使用FireBeetle 2 ESP32S3，需要AXP313A库
// 这个会在用户代码中通过 #include <DFRobot_AXP313A.h> 包含

#endif
