#ifndef APP_HTTPD_H
#define APP_HTTPD_H

void startCameraServer(int ledPin = -1);

#endif
