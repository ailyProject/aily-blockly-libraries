#include "LTR308.h"

LTR308::LTR308() {
    _gain = LTR308_GAIN_1;
    _integrationTime = LTR308_INTEGRATION_100MS;
    _measurementRate = LTR308_RATE_500MS;
}

bool LTR308::begin(TwoWire *wire) {
    _wire = wire;
    
    // 检查设备是否存在
    _wire->beginTransmission(LTR308_ADDRESS);
    if (_wire->endTransmission() != 0) {
        return false;
    }
    
    // 检查Part ID
    uint8_t partID = getPartID();
    if (partID != 0xB1) {  // LTR308的Part ID应该是0xB1
        return false;
    }
    
    // 复位设备
    reset();
    delay(10);
    
    // 设置默认参数
    setGain(_gain);
    setIntegrationTime(_integrationTime);
    setMeasurementRate(_measurementRate);
    
    // 启用传感器
    enable();
    
    return true;
}

void LTR308::setGain(uint8_t gain) {
    _gain = gain;
    writeRegister(LTR308_GAIN, gain);
}

void LTR308::setIntegrationTime(uint8_t integrationTime) {
    _integrationTime = integrationTime;
    uint8_t currentRate = readRegister(LTR308_MEAS_RATE);
    writeRegister(LTR308_MEAS_RATE, (currentRate & 0xF8) | integrationTime);
}

void LTR308::setMeasurementRate(uint8_t measurementRate) {
    _measurementRate = measurementRate;
    uint8_t currentIntTime = readRegister(LTR308_MEAS_RATE) & 0x07;
    writeRegister(LTR308_MEAS_RATE, (measurementRate << 3) | currentIntTime);
}

float LTR308::getLux() {
    uint32_t rawData = getRawData();
    return calculateLux(rawData);
}

uint32_t LTR308::getRawData() {
    uint8_t buffer[3];
    readMultipleRegisters(LTR308_DATA_0, buffer, 3);
    
    uint32_t rawData = ((uint32_t)buffer[2] << 16) | 
                       ((uint32_t)buffer[1] << 8) | 
                       buffer[0];
    
    return rawData;
}

bool LTR308::isDataReady() {
    uint8_t status = getStatus();
    return (status & 0x08) != 0;  // 检查DATA_READY位
}

void LTR308::enable() {
    writeRegister(LTR308_MAIN_CTRL, 0x02);  // 启用ALS
}

void LTR308::disable() {
    writeRegister(LTR308_MAIN_CTRL, 0x00);  // 禁用ALS
}

void LTR308::reset() {
    writeRegister(LTR308_MAIN_CTRL, 0x10);  // 软件复位
}

uint8_t LTR308::getPartID() {
    return readRegister(LTR308_PART_ID);
}

uint8_t LTR308::getStatus() {
    return readRegister(LTR308_MAIN_STATUS);
}

void LTR308::writeRegister(uint8_t reg, uint8_t value) {
    _wire->beginTransmission(LTR308_ADDRESS);
    _wire->write(reg);
    _wire->write(value);
    _wire->endTransmission();
}

uint8_t LTR308::readRegister(uint8_t reg) {
    _wire->beginTransmission(LTR308_ADDRESS);
    _wire->write(reg);
    _wire->endTransmission(false);
    
    _wire->requestFrom(LTR308_ADDRESS, (uint8_t)1);
    if (_wire->available()) {
        return _wire->read();
    }
    return 0;
}

void LTR308::readMultipleRegisters(uint8_t reg, uint8_t *buffer, uint8_t length) {
    _wire->beginTransmission(LTR308_ADDRESS);
    _wire->write(reg);
    _wire->endTransmission(false);
    
    _wire->requestFrom(LTR308_ADDRESS, length);
    for (uint8_t i = 0; i < length && _wire->available(); i++) {
        buffer[i] = _wire->read();
    }
}

float LTR308::calculateLux(uint32_t rawData) {
    if (rawData == 0) {
        return 0.0;
    }
    
    // LTR308的lux计算公式
    // Lux = rawData * 0.6 / (gain * integration_time_multiplier)
    float gainMultiplier = getGainMultiplier();
    float integrationMultiplier = getIntegrationTimeMultiplier();
    
    float lux = (float)rawData * 0.6 / (gainMultiplier * integrationMultiplier);
    
    return lux;
}

float LTR308::getGainMultiplier() {
    switch (_gain) {
        case LTR308_GAIN_1:  return 1.0;
        case LTR308_GAIN_3:  return 3.0;
        case LTR308_GAIN_6:  return 6.0;
        case LTR308_GAIN_9:  return 9.0;
        case LTR308_GAIN_18: return 18.0;
        default: return 1.0;
    }
}

float LTR308::getIntegrationTimeMultiplier() {
    switch (_integrationTime) {
        case LTR308_INTEGRATION_25MS:  return 0.25;
        case LTR308_INTEGRATION_50MS:  return 0.5;
        case LTR308_INTEGRATION_100MS: return 1.0;
        case LTR308_INTEGRATION_200MS: return 2.0;
        case LTR308_INTEGRATION_400MS: return 4.0;
        default: return 1.0;
    }
}