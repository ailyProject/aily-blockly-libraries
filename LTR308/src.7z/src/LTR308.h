#ifndef LTR308_H
#define LTR308_H

#include <Arduino.h>
#include <Wire.h>

// LTR308 I2C地址
#define LTR308_ADDRESS 0x53

// 寄存器地址
#define LTR308_MAIN_CTRL    0x00
#define LTR308_MEAS_RATE    0x04
#define LTR308_GAIN         0x05
#define LTR308_PART_ID      0x06
#define LTR308_MAIN_STATUS  0x07
#define LTR308_DATA_0       0x0D
#define LTR308_DATA_1       0x0E
#define LTR308_DATA_2       0x0F

// 增益设置
#define LTR308_GAIN_1       0x00  // 1x gain
#define LTR308_GAIN_3       0x01  // 3x gain
#define LTR308_GAIN_6       0x02  // 6x gain
#define LTR308_GAIN_9       0x03  // 9x gain
#define LTR308_GAIN_18      0x04  // 18x gain

// 积分时间设置
#define LTR308_INTEGRATION_25MS   0x00  // 25ms
#define LTR308_INTEGRATION_50MS   0x01  // 50ms
#define LTR308_INTEGRATION_100MS  0x02  // 100ms (default)
#define LTR308_INTEGRATION_200MS  0x03  // 200ms
#define LTR308_INTEGRATION_400MS  0x04  // 400ms

// 测量速率设置
#define LTR308_RATE_25MS    0x00  // 25ms
#define LTR308_RATE_50MS    0x01  // 50ms
#define LTR308_RATE_100MS   0x02  // 100ms
#define LTR308_RATE_200MS   0x03  // 200ms
#define LTR308_RATE_500MS   0x04  // 500ms (default)
#define LTR308_RATE_1000MS  0x05  // 1000ms
#define LTR308_RATE_2000MS  0x06  // 2000ms

class LTR308 {
public:
    LTR308();
    
    // 初始化函数
    bool begin(TwoWire *wire = &Wire);
    
    // 设置参数
    void setGain(uint8_t gain);
    void setIntegrationTime(uint8_t integrationTime);
    void setMeasurementRate(uint8_t measurementRate);
    
    // 读取数据
    float getLux();
    uint32_t getRawData();
    bool isDataReady();
    
    // 控制函数
    void enable();
    void disable();
    void reset();
    
    // 获取设备信息
    uint8_t getPartID();
    uint8_t getStatus();

private:
    TwoWire *_wire;
    uint8_t _gain;
    uint8_t _integrationTime;
    uint8_t _measurementRate;
    
    // I2C通信函数
    void writeRegister(uint8_t reg, uint8_t value);
    uint8_t readRegister(uint8_t reg);
    void readMultipleRegisters(uint8_t reg, uint8_t *buffer, uint8_t length);
    
    // 计算lux值
    float calculateLux(uint32_t rawData);
    float getGainMultiplier();
    float getIntegrationTimeMultiplier();
};

#endif