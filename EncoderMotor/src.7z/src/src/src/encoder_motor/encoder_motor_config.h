/**
 * @file encoder_motor_config.h
 * @brief ESP32 Summer Board 编码电机引脚配置
 * @details 本文件定义了编码电机的引脚配置、编码器参数等
 */

#ifndef ENCODER_MOTOR_CONFIG_H
#define ENCODER_MOTOR_CONFIG_H

#include <Arduino.h>

// ========== 编码电机0 (E0) 引脚配置 ==========
// #define E0_MOTOR_PIN_POSITIVE    GPIO_NUM_12  // 电机正极引脚
// #define E0_MOTOR_PIN_NEGATIVE    GPIO_NUM_14  // 电机负极引脚
// #define E0_ENCODER_PIN_A         GPIO_NUM_35  // 编码器A相引脚
// #define E0_ENCODER_PIN_B         GPIO_NUM_36  // 编码器B相引脚

// ESP32 Arduino Core < 3.0.0 需要指定LEDC通道
#define E0_MOTOR_LEDC_CH_POS     0            // 正极LEDC通道
#define E0_MOTOR_LEDC_CH_NEG     1            // 负极LEDC通道

// ========== 编码电机1 (E1) 引脚配置 ==========
// #define E1_MOTOR_PIN_POSITIVE    GPIO_NUM_15  // 电机正极引脚
// #define E1_MOTOR_PIN_NEGATIVE    GPIO_NUM_17  // 电机负极引脚
// #define E1_ENCODER_PIN_A         GPIO_NUM_34  // 编码器A相引脚
// #define E1_ENCODER_PIN_B         GPIO_NUM_39  // 编码器B相引脚

// ESP32 Arduino Core < 3.0.0 需要指定LEDC通道
#define E1_MOTOR_LEDC_CH_POS     2            // 正极LEDC通道
#define E1_MOTOR_LEDC_CH_NEG     3            // 负极LEDC通道

// ========== 编码器参数（默认值，可通过配置块修改） ==========
#define DEFAULT_ENCODER_PPR           3       // 每转脉冲数 (Pulses Per Revolution)
#define DEFAULT_ENCODER_REDUCTION     48      // 减速比 (Reduction Ratio)

// ========== 相位关系 ==========
// kBPhaseLeads: 电机正转时B相领先A相
// kAPhaseLeads: 电机正转时A相领先B相
// 如不确定，可使用示例程序 detect_phase_relation.ino 检测
#define ENCODER_PHASE_RELATION    em::EncoderMotor::kBPhaseLeads

// ========== PID参数推荐值 ==========
#define DEFAULT_PID_P    5.0f   // 比例系数
#define DEFAULT_PID_I    2.0f   // 积分系数
#define DEFAULT_PID_D    1.0f   // 微分系数

// ========== 速度范围 ==========
#define MIN_SPEED_RPM    -500   // 最小速度 (反转)
#define MAX_SPEED_RPM     500   // 最大速度 (正转)

// ========== PWM占空比范围 ==========
#define MIN_PWM_DUTY    -1023   // 最小占空比 (反转)
#define MAX_PWM_DUTY     1023   // 最大占空比 (正转)

#endif // ENCODER_motor_CONFIG_H
