/**
 * @file EncoderMotor_Wrapper.cpp
 * @brief 编码电机封装库实现
 */

#include "EncoderMotor_Wrapper.h"

// ========== 静态成员初始化 ==========
bool EncoderMotor_Manager::initialized_ = false;
uint32_t EncoderMotor_Manager::ppr_ = DEFAULT_ENCODER_PPR;
uint32_t EncoderMotor_Manager::reduction_ = DEFAULT_ENCODER_REDUCTION;


// ========== 全局编码电机对象 ==========
// 匿名命名空间，保持与图形化生成代码一致e
namespace {
    constexpr uint32_t kPPR = DEFAULT_ENCODER_PPR;
    constexpr uint32_t kReductionRation = DEFAULT_ENCODER_REDUCTION;
}

// 编码电机0
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
em::EncoderMotor g_encoder_motor_0(
    E0_MOTOR_PIN_POSITIVE,
    E0_MOTOR_PIN_NEGATIVE,
    E0_ENCODER_PIN_A,
    E0_ENCODER_PIN_B,
    kPPR,
    kReductionRation,
    ENCODER_PHASE_RELATION
);
#else
em::EncoderMotor g_encoder_motor_0(
    E0_MOTOR_PIN_POSITIVE,
    E0_MOTOR_LEDC_CH_POS,
    E0_MOTOR_PIN_NEGATIVE,
    E0_MOTOR_LEDC_CH_NEG,
    E0_ENCODER_PIN_A,
    E0_ENCODER_PIN_B,
    kPPR,
    kReductionRation,
    ENCODER_PHASE_RELATION
);
#endif

// 编码电机1
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
em::EncoderMotor g_encoder_motor_1(
    E1_MOTOR_PIN_POSITIVE,
    E1_MOTOR_PIN_NEGATIVE,
    E1_ENCODER_PIN_A,
    E1_ENCODER_PIN_B,
    kPPR,
    kReductionRation,
    ENCODER_PHASE_RELATION
);
#else
em::EncoderMotor g_encoder_motor_1(
    E1_MOTOR_PIN_POSITIVE,
    E1_MOTOR_LEDC_CH_POS,
    E1_MOTOR_PIN_NEGATIVE,
    E1_MOTOR_LEDC_CH_NEG,
    E1_ENCODER_PIN_A,
    E1_ENCODER_PIN_B,
    kPPR,
    kReductionRation,
    ENCODER_PHASE_RELATION
);
#endif

// ========== 全局管理器实例 ==========
EncoderMotor_Manager EncoderMotor;

// ========== 封装类实现 ==========
void EncoderMotor_Manager::begin(uint32_t ppr, uint32_t reduction) {
    if (!initialized_) {
        ppr_ = ppr;
        reduction_ = reduction;
        
        // 初始化两个电机
        g_encoder_motor_0.Init();
        g_encoder_motor_1.Init();
        
        // 设置默认PID参数
        g_encoder_motor_0.SetSpeedPid(DEFAULT_PID_P, DEFAULT_PID_I, DEFAULT_PID_D);
        g_encoder_motor_1.SetSpeedPid(DEFAULT_PID_P, DEFAULT_PID_I, DEFAULT_PID_D);
        
        initialized_ = true;
    }
}

void EncoderMotor_Manager::setAllPID(float p, float i, float d) {
    g_encoder_motor_0.SetSpeedPid(p, i, d);
    g_encoder_motor_1.SetSpeedPid(p, i, d);
}

void EncoderMotor_Manager::stopAll() {
    g_encoder_motor_0.Stop();
    g_encoder_motor_1.Stop();
}

void EncoderMotor_Manager::resetAllPulseCount() {
    g_encoder_motor_0.ResetPulseCount();
    g_encoder_motor_1.ResetPulseCount();
}

em::EncoderMotor* EncoderMotor_Manager::getMotor(uint8_t motor_id) {
    if (motor_id == 0) {
        return &g_encoder_motor_0;
    } else if (motor_id == 1) {
        return &g_encoder_motor_1;
    }
    return nullptr;
}

float EncoderMotor_Manager::pulseToDegree(int64_t pulse_count) {
    return pulse_count * 360.0 / (ppr_ * reduction_);
}
