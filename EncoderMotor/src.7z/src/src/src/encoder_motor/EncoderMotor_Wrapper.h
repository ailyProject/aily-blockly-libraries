/**
 * @file EncoderMotor_Wrapper.h
 * @brief 编码电机封装库 - 简化图形化编程使用
 * @details 封装 Emakefun 编码电机库，提供简洁的全局访问接口
 */

#ifndef ENCODER_MOTOR_WRAPPER_H
#define ENCODER_MOTOR_WRAPPER_H

#include "encoder_motor.h"
#include "encoder_motor_lib.h"
#include "encoder_motor_config.h"

// ========== 全局编码电机实例 ==========
// 用户可直接使用 g_encoder_motor_0 和 g_encoder_motor_1
extern em::EncoderMotor g_encoder_motor_0;
extern em::EncoderMotor g_encoder_motor_1;

// ========== 编码电机封装类 ==========
/**
 * @brief 编码电机管理类
 * @details 提供统一的初始化和配置接口，简化图形化编程
 */
class EncoderMotor_Manager {
public:
    /**
     * @brief 初始化所有编码电机
     * @param ppr 每转脉冲数，默认3
     * @param reduction 减速比，默认48
     */
    static void begin(uint32_t ppr = DEFAULT_ENCODER_PPR, 
                     uint32_t reduction = DEFAULT_ENCODER_REDUCTION);
    
    /**
     * @brief 设置所有电机的PID参数
     * @param p 比例系数
     * @param i 积分系数
     * @param d 微分系数
     */
    static void setAllPID(float p, float i, float d);
    
    /**
     * @brief 停止所有电机
     */
    static void stopAll();
    
    /**
     * @brief 重置所有电机的脉冲计数
     */
    static void resetAllPulseCount();
    
    /**
     * @brief 获取电机指针（通过ID）
     * @param motor_id 电机ID (0或1)
     * @return 电机对象指针
     */
    static em::EncoderMotor* getMotor(uint8_t motor_id);
    
    /**
     * @brief 计算角度（从脉冲数转换）
     * @param pulse_count 脉冲计数值
     * @return 角度（度）
     */
    static float pulseToDegree(int64_t pulse_count);
    
private:
    static bool initialized_;
    static uint32_t ppr_;
    static uint32_t reduction_;
};

// ========== 全局管理器实例 ==========
extern EncoderMotor_Manager EncoderMotor;

#endif // ENCODER_MOTOR_WRAPPER_H
