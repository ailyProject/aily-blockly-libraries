#ifndef BLINKER_PROTOCOL_H
#define BLINKER_PROTOCOL_H

#include <time.h>

#include "Blinker/BlinkerApi.h"
#if defined(BLINKER_WIFI)
    #if defined(ESP32)
        #if defined(BLINKER_WIFI_MULTI)
            extern WiFiMulti wifiMulti;
        #endif
    #elif defined(ARDUINO_ARCH_RENESAS)
        #include "RTC.h"
        #include "../modules/NTPClient/NTPClient.h"
        #include <WiFiS3.h>
        #include <WiFiUdp.h>
    #endif
#endif

// 前向声明图表管理器类，避免循环依赖
class BlinkerChartManager;

static const char *TAG_PROTO = "[BlinkerPortocol] ";

template <class Transp>
class BlinkerProtocol : public BlinkerApi< BlinkerProtocol<Transp> >
{
    friend class BlinkerApi< BlinkerProtocol<Transp> >;

    typedef BlinkerApi< BlinkerProtocol<Transp> > BApi;

    public :
        enum _blinker_state_t
        {
            CONNECTING,
            CONNECTED,
            DISCONNECTED
        };

        BlinkerProtocol(Transp& transp)
            : BApi()
#if defined(BLINKER_WIFI) && defined(ARDUINO_ARCH_RENESAS)
            , timeClient(_Udp)
#endif
            , conn(transp) {}
            
        void begin();
        void run();
        void delay(unsigned long ms);
        template <typename T>
        void notify(T n);
        void vibrate(uint16_t ms = 200);
        b_device_staus_t status()               { return conn.status(); }
        char * lastRead()                       { return conn.lastRead(); }
        bool init()                             { return conn.init(); }

        template <typename T1>
        void print(T1 n1, const String &s2);
        template <typename T1>
        void print(T1 n1, const char str2[]);
        template <typename T1>
        void print(T1 n1, char c);
        template <typename T1>
        void print(T1 n1, unsigned char b);
        template <typename T1>
        void print(T1 n1, int n);
        template <typename T1>
        void print(T1 n1, unsigned int n);
        template <typename T1>
        void print(T1 n1, long n);
        template <typename T1>
        void print(T1 n1, unsigned long n);
        template <typename T1>
        void print(T1 n1, double n);
        
        template <typename T1>
        void printArray(T1 n1, const String &s2);

        // template <typename T1>
        // void printNumArray(char * _name, const String & data);

        template <typename T1>
        void printObject(T1 n1, const String &s2);

        void flush();

        void checkState(bool state = true)      { isCheck = state; }

        void setTimezone(float tz)              { _timezone = tz; _isNTPInit = false; }
        float getTimezone()                     { return _timezone; }

        int8_t second();
        int8_t minute();
        int8_t hour();
        int8_t mday();
        int8_t wday();
        int8_t month();
        int16_t year();
        int16_t yday();
        time_t  time();
        int32_t dtime();
        time_t  startTime();
        time_t  runTime();

        // template<typename T>
        // bool sms(const T& msg)
        // { return conn.sms(msg); }

        void reset()                            { conn.reset(); }

#if defined(BLINKER_WIFI)
        template<typename T>
        bool sms(const T& msg, const String & cel = "");

        template<typename T>
        bool push(const T& msg, const String & users = "");

        template<typename T>
        bool wechat(const T& msg);

        template<typename T>
        bool wechat(const String & title, const String & state, const T& msg, const String & users = "");

        void weather(uint32_t _city = 0);
        void weatherForecast(uint32_t _city = 0);
        void air(uint32_t _city = 0);
        bool log(const String & msg);

        void attachAir(blinker_callback_with_string_arg_t newFunction)
        { _airFunc = newFunction; }
        void attachWeather(blinker_callback_with_string_arg_t newFunction)
        { _weatherFunc = newFunction; }
        void attachWeatherForecast(blinker_callback_with_string_arg_t newFunction)
        { _weather_forecast_Func = newFunction; }

    #if defined(BLINKER_ALIGENIE)
        bool aliAvail()                         { return conn.aliAvail(); }
        void aliPrint(const String & _msg)      { conn.aliPrint(_msg); }
    #endif

    #if defined(BLINKER_DUEROS)
        bool duerAvail()                        { return conn.duerAvail(); }
        void duerPrint(const String & _msg, bool report = false)
        { conn.duerPrint(_msg, report); }
    #endif

    #if defined(BLINKER_MIOT)
        bool miotAvail()                        { return conn.miAvail(); }
        void miotPrint(const String & _msg)     { conn.miPrint(_msg); }
    #endif

#endif
        void chartDataUpload(const char* _name, uint8_t value);
        void chartDataUpload(const char* _name, int8_t value);
        void chartDataUpload(const char* _name, uint16_t value);
        void chartDataUpload(const char* _name, int16_t value);
        void chartDataUpload(const char* _name, uint32_t value);
        void chartDataUpload(const char* _name, int32_t value);
        void chartDataUpload(const char* _name, float value);
        void chartDataUpload(const char* _name, double value);
        
        // 图表管理相关接口
        uint8_t registerChart(const char* chartName, blinker_callback_t realtimeCallback = NULL);
        void setChartRealtimeMode(const char* chartName, bool realtime);
        void setChartRealtimeMode(uint8_t chartId, bool realtime);
        bool isChartRealtime(const char* chartName);
        bool isChartRealtime(uint8_t chartId);
        void setChartInterval(const char* chartName, uint32_t interval);
        void setChartInterval(uint8_t chartId, uint32_t interval);
        
        void attachDataStorage(blinker_callback_t newFunction, uint32_t _time = 60, uint8_t d_times = BLINKER_DATA_UPDATE_COUNT);
        void updateDataStorageInterval(uint32_t _time);
        
        // void clearDataStorage();
        // void clearDataStorage(const char* name);
        // size_t getDataStorageMemoryUsage();
        // uint8_t getDataStorageCount() { return data_dataCount; }
        // bool isDataStorageFull() { return data_dataCount >= BLINKER_MAX_BLINKER_DATA_SIZE; }
        
        // bool forceDataUpdate();
        
        // void printDataStorageStatus();
    private :
        void autoPrint(const String & key, const String & data);
        void autoFormatData(const String & key, const String & jsonValue);
        void checkAutoFormat();
        void printNow();
        int  _print(char * n, bool needCheckLength = true);
        void _timerPrint(const String & n);

#if defined(BLINKER_WIFI)
        #if defined(ARDUINO_ARCH_RENESAS)
            WiFiUDP _Udp;
            NTPClient timeClient;
        #endif
        bool wlanCheck();
    // #if defined(ESP32)
        bool ntpConfig();
        bool ntpInit();
    // #endif

        // WiFi模式专用的数据存储功能
        void checkDataStorage();
        bool dataUpdate();
        void dataStorageValueInternal(const char* _name, const BlinkerDataValue& value, BlinkerDataValueType type);
#endif        
        // 基础图表管理相关内部方法 - 支持WiFi和BLE
        void checkRealtimeCharts();
        void parseRealtimeCommand(const String& data);
        void checkRealtimeTimeout();
        void syncChartModes();  // 安全的图表同步方法
        int8_t findChartIndex(const char* chartName);

        bool chartDataUpload(const String & msg);
        
        // bool timeSlot(const String & msg);
        // void httpHeartbeat();
        char                _sendBuf[BLINKER_MAX_SEND_SIZE];
        uint32_t            autoFormatFreshTime;
        bool                autoFormat = false;
        bool                isCheck = true;
        uint32_t            _reconTime = 0;

        bool                _isNTPInit = false;
        uint32_t            _ntpStart;
        float               _timezone = 8.0;
        time_t              _deviceStartTime = 0;
        uint32_t            _dHeartTime = 0;

    protected :
        Transp&             conn;
        _blinker_state_t    _state = CONNECTING;
        bool                isAvail;
        
        // 基础图表管理数据结构 - 支持WiFi和BLE
        struct BlinkerChartInfo {
            char name[BLINKER_MAX_WIDGET_SIZE];
            bool isRealtimeMode;
            uint32_t lastSendTime;
            uint32_t sendInterval;
            blinker_callback_t realtimeCallback;
        };
        BlinkerChartInfo                    _Charts[BLINKER_MAX_BLINKER_DATA_SIZE];
        uint8_t                             chart_count = 0;
        uint32_t                            _lastRealtimeCheck = 0;
        uint32_t                            _lastRealtimeCommandTime = 0;  // 最后收到实时指令的时间
        
    #if defined(BLINKER_WIFI)
        blinker_callback_with_string_arg_t  _airFunc = NULL;
        blinker_callback_with_string_arg_t  _weatherFunc = NULL;
        blinker_callback_with_string_arg_t  _weather_forecast_Func = NULL;

        class BlinkerData *                 _Data[BLINKER_MAX_BLINKER_DATA_SIZE];
        // class BlinkerTimeSlotData *         _TimeSlotData[BLINKER_MAX_BLINKER_DATA_SIZE];
        
        // WiFi模式专用的数据存储功能
        blinker_callback_t                  _dataStorageFunc = NULL;
        uint32_t                            _autoStorageTime = 60;
        uint32_t                            _autoDataTime = 0;
        uint8_t                             _dataTimes = BLINKER_MAX_DATA_COUNT;
        uint32_t                            _autoUpdateTime = 0;
        uint8_t                             data_dataCount = 0;
        uint8_t                             data_timeSlotDataCount = 0;
        uint32_t                            time_timeSlotData = 0;
    #endif
};

template <class Transp>
void BlinkerProtocol<Transp>::begin()
{
    #if defined(ESP32)
    Serial.print(BLINKER_F("package version: "));
    Serial.println(ESP.getSdkVersion());
    #endif
    // Serial.print(BLINKER_F("board type: "));
    // Serial.println(ARDUINO_BOARD);
    #else
    BLINKER_LOG(TAG_PROTO, BLINKER_F(""));

    BLINKER_LOG(TAG_PROTO, BLINKER_F("blinker lib version: "), BLINKER_VERSION);
    #if defined(ESP8266)
    BLINKER_LOG(TAG_PROTO, BLINKER_F("package version: "), ESP.getCoreVersion());
    #elif defined(ESP32)
    BLINKER_LOG(TAG_PROTO, BLINKER_F("package version: "), ESP.getSdkVersion());
    #endif
    // BLINKER_LOG(TAG_PROTO, BLINKER_F("board type: "), ARDUINO_BOARD);
    #endif

    #if defined(BLINKER_NO_LOGO)
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("blinker v"), BLINKER_VERSION, BLINKER_F("\n"),
                    BLINKER_F("    To better use blinker with your IoT project!\n"),
                    BLINKER_F("    Download latest blinker library here!\n"),
                    BLINKER_F("    => https://github.com/blinker-iot/blinker-library\n"));
    #elif defined(BLINKER_LOGO_3D)
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("\n"),
                    BLINKER_F(" __       __                __\n"),
                    BLINKER_F("/\\ \\     /\\ \\    __        /\\ \\              v"), BLINKER_VERSION, BLINKER_F("\n"),
                    BLINKER_F("\\ \\ \\___ \\ \\ \\  /\\_\\    ___\\ \\ \\/'\\      __   _ __   \n"),
                    BLINKER_F(" \\ \\ '__`\\\\ \\ \\ \\/\\ \\ /' _ `\\ \\ , <    /'__`\\/\\`'__\\ \n"),
                    BLINKER_F("  \\ \\ \\L\\ \\\\ \\ \\_\\ \\ \\/\\ \\/\\ \\ \\ \\\\`\\ /\\  __/\\ \\ \\./ \n"),
                    BLINKER_F("   \\ \\_,__/ \\ \\__\\\\ \\_\\ \\_\\ \\_\\ \\_\\ \\_\\ \\____\\\\ \\_\\  \n"),
                    BLINKER_F("    \\/___/   \\/__/ \\/_/\\/_/\\/_/\\/_/\\/_/\\/____/ \\/_/  \n"),
                    BLINKER_F("    To better use blinker with your IoT project!\n"),
                    BLINKER_F("    Download latest blinker library here!\n"),
                    BLINKER_F("    => https://github.com/blinker-iot/blinker-library\n"));
    #else
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("\n"),
                    BLINKER_F(".   .        .   v"), BLINKER_VERSION, BLINKER_F("\n"),
                    BLINKER_F("|-. |  . ,-. | , ,-. ,-.\n"),
                    BLINKER_F("| | |  | | | |<  |-' |\n"),
                    BLINKER_F("`-' `' ' ' ' ' ` `-' '\n"),
                    BLINKER_F( "To better use blinker with your IoT project!\n"),
                    BLINKER_F("Download latest blinker library here!\n"),
                    BLINKER_F("=> https://github.com/blinker-iot/blinker-library\n"));
    #endif

    #if defined(BLINKER_WIFI)
        #if defined(BLINKER_BUTTON_PULLDOWN)
            BApi::buttonInit(false);
        #else
            BApi::buttonInit();
        #endif
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::run()
{
#if defined(BLINKER_WIFI)
    BApi::tick();
#endif

    if (!conn.init()) return;

#if defined(BLINKER_WIFI)
    if (!wlanCheck()) return;

    #if defined(ESP32) || defined(ARDUINO_ARCH_RENESAS)
    ntpInit();
    // #if defined(BLINKER_WIDGET) && (defined(ESP32) || defined(ARDUINO_ARCH_RENESAS))
    BApi::checkTimer();
    // #endif

    // if (((millis() - _dHeartTime)/1000UL >= BLINKER_DEVICE_HEARTBEAT_TIME) && conn.checkInit())
    // {
    //     _dHeartTime += BLINKER_DEVICE_HEARTBEAT_TIME * 1000;
    //     httpHeartbeat();
    // }
    #endif
#endif

    switch (_state)
    {
        case CONNECTING :
            if (conn.connect())
            {
                _state = CONNECTED;
            }
            break;

        case CONNECTED :
            if (!conn.connect())
            {
                _state = DISCONNECTED;
            }
            else if (conn.available())
            {
                isAvail = true;

                char* receivedData = conn.lastRead();
                if (receivedData && strlen(receivedData) > 0) {
                    String dataStr = String(receivedData);
                    
                    BApi::parse(receivedData);
                // #if defined(BLINKER_WIFI)
                    parseRealtimeCommand(dataStr);
                // #endif
                }
            }

            // else if (conn.miAvail())
            // {
            //     BApi::miotParse(conn.lastRead());
            // }
            break;
        
        case DISCONNECTED :
            conn.disconnect();
            _state = CONNECTING;
            break;

        default:
            _state = CONNECTING;
            break;
    }
#if defined(BLINKER_WIFI)
    checkDataStorage();
    checkRealtimeCharts();
#endif
    checkAutoFormat();
}

template <class Transp>
void BlinkerProtocol<Transp>::delay(unsigned long ms)
{
    uint32_t start = micros();
    uint32_t __start = millis();
    unsigned long _ms = ms;
    while (ms > 0)
    {
        run();

        if ((micros() - start) >= 1000)
        {
            ms -= 1;
            start += 1000;
        }

        if ((millis() - __start) >= _ms)
        {
            ms = 0;
        }

        yield();
    }
}

template <class Transp> template <typename T>
void BlinkerProtocol<Transp>::notify(T n)
{
    print(BLINKER_CMD_NOTICE, STRING_format(n));
}

template <class Transp> 
void BlinkerProtocol<Transp>::vibrate(uint16_t ms)
{
    if (ms > 1000) ms = 1000;

    print(BLINKER_CMD_VIBRATE, ms);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, const String &s2)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":\"");
    _msg += s2;
    _msg += BLINKER_F("\"");

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, const char str2[])
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":\"");
    _msg += STRING_format(str2);
    _msg += BLINKER_F("\"");

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, char c)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(c);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, unsigned char b)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(b);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, int n)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(n);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, unsigned int n)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(n);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, long n)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(n);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, unsigned long n)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(n);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::print(T1 n1, double n)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += STRING_format(n);

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::printArray(T1 n1, const String &s2)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += s2;

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp> template <typename T1>
void BlinkerProtocol<Transp>::printObject(T1 n1, const String &s2)
{
    String _msg = BLINKER_F("\"");
    _msg += STRING_format(n1);
    _msg += BLINKER_F("\":");
    _msg += s2;

    autoPrint(STRING_format(n1), _msg);
}

template <class Transp>
void BlinkerProtocol<Transp>::autoPrint(const String & key, const String & data)
{
    if (!autoFormat) autoFormat = true;

    autoFormatData(key, data);
    
    if ((millis() - autoFormatFreshTime) >= BLINKER_MSG_AUTOFORMAT_TIMEOUT)
    {
        autoFormatFreshTime = millis();
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::autoFormatData(const String & key, const String & jsonValue)
{
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("autoFormatData key: "), key, \
                    BLINKER_F(", json: "), jsonValue);
    
    String _data;

    if (STRING_contains_string(STRING_format(_sendBuf), key))
    {

        // DynamicJsonBuffer jsonSendBuffer;
        DynamicJsonDocument jsonBuffer(1024);

        if (strlen(_sendBuf)) {
            BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("add"));

            // JsonObject& root = jsonSendBuffer.parseObject(STRING_format(_sendBuf));
            deserializeJson(jsonBuffer, STRING_format(_sendBuf));
            JsonObject root = jsonBuffer.as<JsonObject>();

            if (root.containsKey(key)) {
                root.remove(key);
            }
            // root.printTo(_data);
            serializeJson(root, _data);

            _data = _data.substring(0, _data.length() - 1);

            if (_data.length() > 4 ) _data += BLINKER_F(",");
            _data += jsonValue;
            _data += BLINKER_F("}");
        }
        else {
            BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("new"));
            
            _data = BLINKER_F("{");
            _data += jsonValue;
            _data += BLINKER_F("}");
        }
    }
    else {
        _data = STRING_format(_sendBuf);

        if (_data.length())
        {
            BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("add."));

            _data = _data.substring(0, _data.length() - 1);

            _data += BLINKER_F(",");
            _data += jsonValue;
            _data += BLINKER_F("}");
        }
        else {
            BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("new."));
            
            _data = BLINKER_F("{");
            _data += jsonValue;
            _data += BLINKER_F("}");
        }
    }

    if (_data.length() > BLINKER_MAX_SEND_BUFFER_SIZE)
    {
        BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("FORMAT DATA SIZE IS MAX THAN LIMIT: "), BLINKER_MAX_SEND_BUFFER_SIZE);
        return;
    }

    strcpy(_sendBuf, _data.c_str());
}

template <class Transp>
void BlinkerProtocol<Transp>::checkAutoFormat()
{
    if (autoFormat)
    {
        if ((millis() - autoFormatFreshTime) >= BLINKER_MSG_AUTOFORMAT_TIMEOUT)
        {
            if (strlen(_sendBuf))
            {
                _print(_sendBuf);
            }
            memset(_sendBuf, '\0', BLINKER_MAX_SEND_SIZE);
            autoFormat = false;
            BLINKER_LOG_FreeHeap_ALL();
        }
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::printNow()
{
    if (strlen(_sendBuf) && autoFormat)
    {
        _print(_sendBuf);
        
        memset(_sendBuf, '\0', BLINKER_MAX_SEND_SIZE);
        autoFormat = false;
    }
}

template <class Transp>
int BlinkerProtocol<Transp>::_print(char * n, bool needCheckLength)
{
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("print: "), n);
    
    if (strlen(n) <= BLINKER_MAX_SEND_SIZE || \
        !needCheckLength)
    {
        // BLINKER_LOG_FreeHeap_ALL();
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Proto print..."));
        BLINKER_LOG_FreeHeap_ALL();
        conn.print(n, isCheck);
        if (!isCheck) isCheck = true;

        return true;
    }
    else {
        BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("SEND DATA BYTES MAX THAN LIMIT!"));

        return false;
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::_timerPrint(const String & n)
{
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("print: "), n);
    
    if (n.length() <= BLINKER_MAX_SEND_SIZE)
    {
        if (!autoFormat) autoFormat = true;
        checkState(false);
        strcpy(_sendBuf, n.c_str());
    }
    else
    {
        BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("SEND DATA BYTES MAX THAN LIMIT!"));
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::flush()
{ 
    conn.flush();
    isAvail = false;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::second()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_sec;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getSeconds();
#endif
    }
    return -1;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::minute()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_min;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getMinutes();
#endif
    }
    return -1;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::hour()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_hour;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getHour();
#endif
    }
    return -1;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::mday()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_mday;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getDayOfMonth();
#endif
    }
    return -1;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::wday()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_wday;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return static_cast<int8_t>(currentTime.getDayOfWeek());
#endif
    }
    return -1;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::month()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_mon + 1;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getMonth();
#endif
    }
    return -1;
}

template <class Transp>
int16_t BlinkerProtocol<Transp>::year()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_year + 1900;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getYear();
#endif
    }
    return -1;
}

template <class Transp>
int16_t BlinkerProtocol<Transp>::yday()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_yday + 1;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        
        int year = currentTime.getYear();
        int month = currentTime.getMonth();
        int day = currentTime.getDayOfMonth();
        
        if (month < 1 || month > 12 || day < 1 || day > 31) {
            return -1;
        }

        const int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int monthDays[12];
        memcpy(monthDays, daysInMonth, sizeof(daysInMonth));
        
        bool isLeapYear = ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
        if (isLeapYear) {
            monthDays[1] = 29;
        }
        if (day > monthDays[month - 1]) {
            return -1;
        }
        int dayOfYear = day;
        
        for (int i = 0; i < month - 1; i++) {
            dayOfYear += monthDays[i];
        }
        
        return dayOfYear;
#endif
    }
    return -1;
}

template <class Transp>
time_t BlinkerProtocol<Transp>::time()
{
    if (_isNTPInit)
    {
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);

        return now_ntp;
    }
    return millis();
}

template <class Transp>
int32_t BlinkerProtocol<Transp>::dtime()
{
    if (_isNTPInit)
    {
#if defined(ESP32)
        time_t _ntpGetTime;

        time_t now_ntp = ::time(nullptr);
        struct tm timeinfo;
        localtime_r(&now_ntp, &timeinfo);
        return timeinfo.tm_hour * 60 * 60 + timeinfo.tm_min * 60 + timeinfo.tm_sec;
#elif defined(ARDUINO_ARCH_RENESAS) && defined(BLINKER_WIFI)
        auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
        RTCTime currentTime = RTCTime(unixTime);
        return currentTime.getHour() * 60 * 60 + currentTime.getMinutes() * 60 + currentTime.getSeconds();
#endif
    }
    return -1;
}

template <class Transp>
time_t BlinkerProtocol<Transp>::startTime()
{
    if (_isNTPInit) return _deviceStartTime;
    else return 0;
}

template <class Transp>
time_t BlinkerProtocol<Transp>::runTime()
{
    if (_isNTPInit)
    {
        return time() - _deviceStartTime;
    }
    else
    {
        return millis()/1000;
    }
}


#if defined(BLINKER_WIFI)

template <class Transp>
bool BlinkerProtocol<Transp>::wlanCheck()
{
    #if defined(BLINKER_WIFI_MULTI)
        if (wifiMulti.run() != WL_CONNECTED)
        {
            if ((millis() - _reconTime) >= 10000 || \
                _reconTime == 0 )
            {
                _reconTime = millis();
                BLINKER_LOG(BLINKER_F("WiFi disconnected! reconnecting!"));
            }

            return false;
        }
    #else
        if (WiFi.status() != WL_CONNECTED)
        {
            if ((millis() - _reconTime) >= 10000 || \
                _reconTime == 0 )
            {
                _reconTime = millis();
                BLINKER_LOG(BLINKER_F("WiFi disconnected! reconnecting!"));
                #if defined(ESP32)
                    WiFi.reconnect();
                #endif
            }

            return false;
        }
    #endif

    return true;
}

template <class Transp>
bool BlinkerProtocol<Transp>::ntpConfig()
{
    // BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("NTP Config"));
#if defined(ESP32)
    configTime((long)(_timezone * 3600), 0, 
                "ntp1.aliyun.com", 
                "120.25.108.11", 
                "time.pool.aliyun.com");
    ::delay(500);
    time_t now_ntp = ::time(nullptr);

    float _com_timezone = abs(_timezone);
    if (_com_timezone < 1.0) _com_timezone = 1.0;

    if (now_ntp < _com_timezone * 3600 * 12)
    {
        configTime((long)(_timezone * 3600), 0, 
                "ntp1.aliyun.com", 
                "120.25.108.11", 
                "time.pool.aliyun.com");
        ::delay(500);
        now_ntp = ::time(nullptr);
        if (now_ntp < _com_timezone * 3600 * 12)
        {
            now_ntp = ::time(nullptr);
            return false;
        }
    }

    struct tm timeinfo;
    localtime_r(&now_ntp, &timeinfo);

    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Current time: "), asctime(&timeinfo));
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("NTP time: "), now_ntp);

    return true;
#elif defined(ARDUINO_ARCH_RENESAS)
    RTC.begin();

    timeClient.begin();
    timeClient.update();

    auto unixTime = timeClient.getEpochTime() + (long)(_timezone * 3600);
    RTCTime timeToSet = RTCTime(unixTime);
    RTC.setTime(timeToSet);
    RTCTime currentTime;
    RTC.getTime(currentTime);
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Current RTC time: "), String(currentTime));
#endif
}

template <class Transp>
bool BlinkerProtocol<Transp>::ntpInit()
{
    if (!_isNTPInit)
    {
        // BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("NTP Init"));
        // if (_isNTPInit)
        // {
        //     time_t now_ntp = ::time(nullptr);
        //     struct tm timeinfo;
        //     #if defined(ESP8266)
        //         gmtime_r(&now_ntp, &timeinfo);
        //     #elif defined(ESP32)
        //         localtime_r(&now_ntp, &timeinfo);
        //     #endif
        // }

        // if ((millis() - _ntpStart) > BLINKER_NTP_TIMEOUT)
        // {
        //     _ntpStart = millis();
        // }
        // else {
        //     return false;
        // }

        if (!ntpConfig()) return false;

        _ntpStart = millis();

        _isNTPInit = true;

        _deviceStartTime = time() - millis()/1000;

    #if defined(BLINKER_WIDGET)
        BApi::loadTiming();
    #endif
        // BApi::beginAuto();

        return true;
    }
    else if (_isNTPInit && (millis() - _ntpStart) >= 60 * 60 * 1000)
    {
        ntpConfig();
        _ntpStart += 60 * 60 * 1000;
    }
    return true;
}

template <class Transp> template<typename T>
bool BlinkerProtocol<Transp>::sms(const T& msg, const String & cel)
{
    String _msg = STRING_format(msg);
    
    String  data = BLINKER_F("{\"deviceName\":\"");
            data += conn.deviceName();
            data += BLINKER_F("\",\"key\":\"");
            data += conn.authKey();
            data += BLINKER_F("\",\"cel\":\"");
            data += cel;
            data += BLINKER_F("\",\"msg\":\"");
            data += _msg;
            data += BLINKER_F("\"}");

    if (_msg.length() > 20) return false;

    return conn.httpServer(BLINKER_CMD_SMS_NUMBER, data) != "false";
}

template <class Transp> template<typename T>
bool BlinkerProtocol<Transp>::push(const T& msg, const String & users)
{
    String _msg = STRING_format(msg);
    
    String  data = BLINKER_F("{\"deviceName\":\"");
            data += conn.deviceName();
            data += BLINKER_F("\",\"key\":\"");
            data += conn.authKey();
            data += BLINKER_F("\",\"msg\":\"");
            data += _msg;
            data += BLINKER_F("\",\"receivers\":\"");
            data += users;
            data += BLINKER_F("\"}");

    return conn.httpServer(BLINKER_CMD_PUSH_NUMBER, data) != "false";
}

template <class Transp> template<typename T>
bool BlinkerProtocol<Transp>::wechat(const T& msg)
{
    String _msg = STRING_format(msg);
    
    String  data = BLINKER_F("{\"deviceName\":\"");
            data += conn.deviceName();
            data += BLINKER_F("\",\"key\":\"");
            data += conn.authKey();
            data += BLINKER_F("\",\"msg\":\"");
            data += _msg;
            data += BLINKER_F("\"}");

    return conn.httpServer(BLINKER_CMD_WECHAT_NUMBER, data) != "false";
}

template <class Transp> template<typename T>
bool BlinkerProtocol<Transp>::wechat(const String & title, const String & state, const T& msg, const String & users)
{
    String _msg = STRING_format(msg);

    String  data = BLINKER_F("{\"deviceName\":\"");
            data += conn.deviceName();
            data += BLINKER_F("\",\"key\":\"");
            data += conn.authKey();
            data += BLINKER_F("\",\"title\":\"");
            data += title;
            data += BLINKER_F("\",\"state\":\"");
            data += state;
            data += BLINKER_F("\",\"msg\":\"");
            data += _msg;
            data += BLINKER_F("\",\"receivers\":\"");
            data += users;
            data += BLINKER_F("\"}");

    return conn.httpServer(BLINKER_CMD_WECHAT_NUMBER, data) != "false";
}

template <class Transp>
void BlinkerProtocol<Transp>::weather(uint32_t _city)
{
    String data = BLINKER_F("/weather?");

    if (_city != 0)
    {
        data += BLINKER_F("code=");
        data += STRING_format(_city);
        data += BLINKER_F("&");
    }

    data += BLINKER_F("deviceName=");
    data += conn.deviceName();
    data += BLINKER_F("&key=");
    data += conn.token();

    if (_weatherFunc) _weatherFunc(conn.httpServer(BLINKER_CMD_WEATHER_NUMBER, data));
}

template <class Transp>
void BlinkerProtocol<Transp>::weatherForecast(uint32_t _city)
{
    String data = BLINKER_F("/forecast?");

    if (_city != 0)
    {
        data += BLINKER_F("code=");
        data += STRING_format(_city);
        data += BLINKER_F("&");
    }

    data += BLINKER_F("deviceName=");
    data += conn.deviceName();
    data += BLINKER_F("&key=");
    data += conn.token();

    if (_weather_forecast_Func) _weather_forecast_Func(conn.httpServer(BLINKER_CMD_WEATHER_FORECAST_NUMBER, data));
}

template <class Transp>
void BlinkerProtocol<Transp>::air(uint32_t _city)
{
    String data = BLINKER_F("/air?");

    if (_city != 0)
    {
        data += BLINKER_F("code=");
        data += STRING_format(_city);
        data += BLINKER_F("&");
    }

    data += BLINKER_F("deviceName=");
    data += conn.deviceName();
    data += BLINKER_F("&key=");
    data += conn.token();

    if (_airFunc) _airFunc(conn.httpServer(BLINKER_CMD_AQI_NUMBER, data));
}

// template <class Transp>
// bool BlinkerProtocol<Transp>::log(const String & msg)
// {
//     String data = BLINKER_F("{\"token\":\"");
//     data += conn.token();
//     data += BLINKER_F("\",\"data\":[[");
//     data += STRING_format(time());
//     data += BLINKER_F(",\"");
//     data += msg;
//     data += BLINKER_F("\"]]}");

//     return conn.httpServer(BLINKER_CMD_LOG_NUMBER, data) != "false";
// }

#endif

template <class Transp>
bool BlinkerProtocol<Transp>::chartDataUpload(const String & msg)
{
#if defined(BLINKER_WIFI) || defined(BLINKER_MQTT) || \
    defined(BLINKER_PRO) || defined(BLINKER_WIFI_AT) || \
    defined(BLINKER_WIFI_GATEWAY) || defined(BLINKER_NBIOT_SIM7020) || \
    defined(BLINKER_GPRS_AIR202) || defined(BLINKER_PRO_SIM7020) || \
    defined(BLINKER_PRO_AIR202) || defined(BLINKER_MQTT_AUTO) || \
    defined(BLINKER_PRO_ESP) || defined(BLINKER_LOWPOWER_AIR202) || \
    defined(BLINKER_WIFI_SUBDEVICE) || defined(BLINKER_QRCODE_NBIOT_SIM7020) || \
    defined(BLINKER_NBIOT_SIM7000) || defined(BLINKER_QRCODE_NBIOT_SIM7000)
    String data = BLINKER_F("{\"deviceName\":\"");
    data += conn.deviceName();
    data += BLINKER_F("\",\"key\":\"");
    data += conn.authKey();
    data += BLINKER_F("\",\"data\":{");
    data += msg;
    data += BLINKER_F("}}");
    
    return conn.httpServer(BLINKER_CMD_DATA_STORAGE_NUMBER, data) != "false";
#else
    // BLE模式或其他不支持数据存储的模式下，直接返回false
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in current mode"));
    return false;
#endif
}

// template <class Transp>
// bool BlinkerProtocol<Transp>::timeSlot(const String & msg)
// {
//     String data = BLINKER_F("{\"device\":\"");
//     data += conn.deviceName();
//     data += BLINKER_F("\",\"key\":\"");
//     data += conn.authKey();
//     data += BLINKER_F("\",\"data\":[");
//     data += msg;
//     data += BLINKER_F("]}");
    
//     return conn.httpServer(BLINKER_CMD_TIME_SLOT_DATA_NUMBER, data) != "false";
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::textData(const String & msg)
// {
//     String data = BLINKER_F("{");
//     data += BLINKER_F("\"device\":\"");
//     data += conn.deviceName();
//     data += BLINKER_F("\",\"key\":\"");
//     data += conn.authKey();
//     data += BLINKER_F("\",\"data\":\"");
//     data += msg;
//     data += BLINKER_F("\"}");

//     conn.httpServer(BLINKER_CMD_TEXT_DATA_NUMBER, data);
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::configUpdate(const String & msg)
// {
//     DynamicJsonDocument jsonBuffer(1024);
//     DeserializationError error = deserializeJson(jsonBuffer, msg);
//     JsonObject root = jsonBuffer.as<JsonObject>();

//     // if (!root.success())
//     if (error)
//     {
//         BLINKER_ERR_LOG(TAG_PROTO, "update data is not Json! ", msg);
//         return;
//     }

//     String data = BLINKER_F("{");
//     data += BLINKER_F("\"token\":\"");
//     data += conn.token();
//     data += BLINKER_F("\",\"data\":");
//     data += msg;
//     data += BLINKER_F("}");

//     conn.httpServer(BLINKER_CMD_CONFIG_UPDATE_NUMBER, data);
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::configGet()
// {
//     String data = BLINKER_F("/cloud_storage/object?token=");
//     data += conn.token();

//     conn.httpServer(BLINKER_CMD_CONFIG_GET_NUMBER, data);
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::httpHeartbeat()
// {
//     String data = BLINKER_F("/heartbeat?");
//     data += BLINKER_F("deviceName=");
//     data += conn.deviceName();
//     data += BLINKER_F("&key=");
//     data += conn.authKey();
//     data += BLINKER_F("&heartbeat=");
//     data += STRING_format(BLINKER_DEVICE_HEARTBEAT_TIME);

//     conn.httpServer(BLINKER_CMD_DEVICE_HEARTBEAT_NUMBER, data);
// }

// 优化的非模板数据存储实现 - 直接使用联合体，避免字符串转换

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, uint8_t value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.uint8_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_UINT8);
    #else
    // BLE模式下仅记录日志，不进行数据存储
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, int8_t value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.int8_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_INT8);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, uint16_t value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.uint16_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_UINT16);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, int16_t value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.int16_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_INT16);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, uint32_t value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.uint32_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_UINT32);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, int32_t value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.int32_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_INT32);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, float value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.float_data = value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_FLOAT);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::chartDataUpload(const char* _name, double value)
{
    #if defined(BLINKER_WIFI)
    BlinkerDataValue data_value;
    data_value.float_data = (float)value;
    dataStorageValueInternal(_name, data_value, BLINKER_DATA_TYPE_FLOAT);
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Chart data upload not supported in BLE mode: "), _name, BLINKER_F("="), value);
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::attachDataStorage(blinker_callback_t newFunction, uint32_t _time, uint8_t d_times)
{
    #if defined(BLINKER_WIFI)
    _dataStorageFunc = newFunction;
    if (_time < 5) _time = 5;
    _autoStorageTime = _time;
    _autoDataTime = millis();
    if (d_times > BLINKER_MAX_DATA_COUNT || d_times == 0) d_times = BLINKER_DATA_UPDATE_COUNT;
    _dataTimes = d_times;
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Data storage not supported in BLE mode"));
    #endif
}

template <class Transp>
void BlinkerProtocol<Transp>::updateDataStorageInterval(uint32_t _time)
{
    #if defined(BLINKER_WIFI)
    if (_time < 5) _time = 5;
    uint32_t oldTime = _autoStorageTime;
    _autoStorageTime = _time;
    
    if (_time < oldTime) {
        _autoDataTime = millis();
    }
    
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Updated data storage interval from "), oldTime, 
                   BLINKER_F(" to "), _time, BLINKER_F(" seconds"));
    #else
    BLINKER_LOG_ALL(BLINKER_F("[BlinkerProtocol] Data storage not supported in BLE mode"));
    #endif
}

#if defined(BLINKER_WIFI)
template <class Transp>
void BlinkerProtocol<Transp>::checkDataStorage()
{
    if (_dataStorageFunc)
    {
        if (millis() - _autoDataTime >= _autoStorageTime * 1000)
        {
            _autoDataTime += _autoStorageTime * 1000;
            _dataStorageFunc();
            
            checkRealtimeTimeout();
        }
    }

    if (millis() - _autoUpdateTime >= BLINKER_DATA_FREQ_TIME * 1000)
    {
        if ((data_dataCount || data_timeSlotDataCount) && conn.checkInit() )// && ESP.getFreeHeap() > 4000)
        {
            if (dataUpdate()) _autoUpdateTime += BLINKER_DATA_FREQ_TIME * 1000;
            else _autoUpdateTime = millis() - 100000;
        }
    }
}

template <class Transp>
bool BlinkerProtocol<Transp>::dataUpdate()
{
    String data = "";

    // if (data_timeSlotDataCount > 0)
    // {
    //     for (uint8_t _num = 0; _num < data_timeSlotDataCount; _num++) {
    //         data += _TimeSlotData[_num]->getData();
    //         if (_num < data_timeSlotDataCount - 1) {
    //             data += BLINKER_F(",");
    //         }
    //     }

    //     if (timeSlot(data))
    //     {
    //         for (uint8_t _num = 0; _num < data_timeSlotDataCount; _num++)
    //         {
    //             // _TimeSlotData[_num]->flush();
    //             free(_TimeSlotData[_num]);
    //         }

    //         data_timeSlotDataCount = 0;
    //         return true;
    //     }
    //     return false;
    // }

    if (!data_dataCount) return false;

    // 预估数据长度并预分配内存
    size_t estimatedLength = 0;
    for (uint8_t _num = 0; _num < data_dataCount; _num++) {
        if (_Data[_num] != nullptr) {
            estimatedLength += strlen(_Data[_num]->getName()) + 100; // 预估每个数据项的长度
        }
    }
    data.reserve(estimatedLength);

    // 构建JSON数据
    bool firstItem = true;
    for (uint8_t _num = 0; _num < data_dataCount; _num++) {
        if (_Data[_num] == nullptr) continue;
        
        if (!firstItem) {
            data += BLINKER_F(",");
        }
        
        data += BLINKER_F("\"");
        data += _Data[_num]->getName();
        data += BLINKER_F("\":");
        data += _Data[_num]->getData();
        
        firstItem = false;

        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Added data for: "), _Data[_num]->getName());
        BLINKER_LOG_FreeHeap_ALL();
    }

    if (data.length() == 0) {
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("No valid data to send"));
        return false;
    }

    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Sending data to storage: "), data.length(), BLINKER_F(" bytes"));
    
    if (chartDataUpload(data))
    {
        for (uint8_t _num = 0; _num < data_dataCount; _num++)
        {
            if (_Data[_num] != nullptr) {
                _Data[_num]->flush();
            }
        }
        
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Data storage update successful"));
        return true;
    }

    BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Data storage update failed"));
    return false;
}
#endif

// template <class Transp> template<typename T>
// void BlinkerProtocol<Transp>::timeSlotData(char _name[], const T& _data)
// {
//     uint32_t now_time = time();

//     if (data_timeSlotDataCount == BLINKER_MAX_BLINKER_DATA_SIZE)
//     {
//         BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("BLINKER MAX DATA STORAGE LIMIT!"));
//         return;
//     }

//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("timeSlotData save"));

//     if (millis() - time_timeSlotData < 1000)
//     {
//         if (data_timeSlotDataCount != 0)
//         {
//             BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("data_timeSlotDataCount != 0"));
//             _TimeSlotData[data_timeSlotDataCount - 1]->saveData(_name, _data, now_time);
//         }
//         else
//         {
//             BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("data_timeSlotDataCount == 0"));
//             _TimeSlotData[data_timeSlotDataCount] = new BlinkerTimeSlotData();
//             _TimeSlotData[data_timeSlotDataCount]->saveData(_name, _data, now_time);
//             data_timeSlotDataCount++;
//         }

//         BLINKER_LOG_ALL(TAG_PROTO, _name, BLINKER_F(" save: "), _data, BLINKER_F(" time: "), now_time);
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("data_timeSlotDataCount: "), data_timeSlotDataCount);
//     }
//     else
//     {
//         time_timeSlotData = millis();

//         _TimeSlotData[data_timeSlotDataCount] = new BlinkerTimeSlotData();
//         _TimeSlotData[data_timeSlotDataCount]->saveData(_name, _data, now_time);
//         data_timeSlotDataCount++;

//         BLINKER_LOG_ALL(TAG_PROTO, _name, BLINKER_F(" save: "), _data, BLINKER_F(" time: "), now_time);
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("data_timeSlotDataCount: "), data_timeSlotDataCount);
//     }
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::clearDataStorage()
// {
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Clearing all data storage"));
    
//     for (uint8_t i = 0; i < data_dataCount; i++) {
//         if (_Data[i] != nullptr) {
//             delete _Data[i];
//             _Data[i] = nullptr;
//         }
//     }
//     data_dataCount = 0;
    
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Data storage cleared"));
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::clearDataStorage(const char* name)
// {
//     int8_t num = checkNum(name, _Data, data_dataCount);
//     if (num != BLINKER_OBJECT_NOT_AVAIL) {
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Clearing data storage: "), name);
        
//         delete _Data[num];
        
//         // 移动后续元素向前填补空隙
//         for (uint8_t i = num; i < data_dataCount - 1; i++) {
//             _Data[i] = _Data[i + 1];
//         }
//         _Data[data_dataCount - 1] = nullptr;
//         data_dataCount--;
        
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Data storage cleared for: "), name);
//     }
// }

// template <class Transp>
// size_t BlinkerProtocol<Transp>::getDataStorageMemoryUsage()
// {
//     size_t totalMemory = 0;
    
//     for (uint8_t i = 0; i < data_dataCount; i++) {
//         if (_Data[i] != nullptr) {
//             totalMemory += _Data[i]->getMemoryUsage();
//         }
//     }
    
//     // 加上指针数组的内存
//     totalMemory += sizeof(_Data);
    
//     return totalMemory;
// }

// template <class Transp>
// bool BlinkerProtocol<Transp>::forceDataUpdate()
// {
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Force data update triggered"));
    
//     if (data_dataCount == 0) {
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("No data to update"));
//         return true;
//     }
    
//     if (!conn.checkInit()) {
//         BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Connection not ready"));
//         return false;
//     }
    
//     bool result = dataUpdate();
//     if (result) {
//         _autoUpdateTime = millis(); // 重置自动更新时间
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Force data update successful"));
//     } else {
//         BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Force data update failed"));
//     }
    
//     return result;
// }

// template <class Transp>
// void BlinkerProtocol<Transp>::printDataStorageStatus()
// {
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("=== Data Storage Status ==="));
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Count: "), data_dataCount, BLINKER_F("/"), BLINKER_MAX_BLINKER_DATA_SIZE);
    
//     size_t totalMemory = getDataStorageMemoryUsage();
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Memory usage: "), totalMemory, BLINKER_F(" bytes"));
    
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Auto storage time: "), _autoStorageTime, BLINKER_F(" seconds"));
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Data times: "), _dataTimes);
    
//     // 计算平均内存效率
//     float totalEfficiency = 0.0f;
//     uint8_t validItems = 0;
    
//     for (uint8_t i = 0; i < data_dataCount; i++) {
//         if (_Data[i] != nullptr) {
//             size_t itemMemory = _Data[i]->getMemoryUsage();
//             float efficiency = _Data[i]->getMemoryEfficiency();
            
//             BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("  ["), i, BLINKER_F("] "), 
//                             _Data[i]->getName(), BLINKER_F(" ("), 
//                             itemMemory, BLINKER_F(" bytes, "),
//                             (int)(efficiency * 100), BLINKER_F("% efficient)"));
            
//             totalEfficiency += efficiency;
//             validItems++;
//         }
//     }
    
//     if (validItems > 0) {
//         float avgEfficiency = totalEfficiency / validItems;
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Average efficiency: "), (int)(avgEfficiency * 100), BLINKER_F("%"));
        
//         // 估算节省的内存
//         size_t oldMemoryEstimate = validItems * (sizeof(time_t) * BLINKER_MAX_DATA_COUNT + 10 * BLINKER_MAX_DATA_COUNT);
//         size_t savedMemory = oldMemoryEstimate > totalMemory ? oldMemoryEstimate - totalMemory : 0;
//         BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Memory saved: ~"), savedMemory, BLINKER_F(" bytes"));
//     }
    
//     BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("========================"));
// }

#if defined(BLINKER_WIFI)
template <class Transp>
void BlinkerProtocol<Transp>::dataStorageValueInternal(const char* _name, const BlinkerDataValue& value, BlinkerDataValueType type)
{
    time_t _time = time();
    uint8_t _second = second();
    time_t now_time = _time - _second;
    now_time = now_time - now_time % 10;

    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("dataStorageValue: "), _name, BLINKER_F(" (type="), type, BLINKER_F(")"));

    int8_t num = checkNum(_name, _Data, data_dataCount);

    if (num == BLINKER_OBJECT_NOT_AVAIL) {
        if (data_dataCount >= BLINKER_MAX_BLINKER_DATA_SIZE) {
            BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Max data storage reached"));
            return;
        }
        
        _Data[data_dataCount] = new BlinkerData();
        if (_Data[data_dataCount] == nullptr) {
            BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Memory allocation failed"));
            return;
        }
        
        _Data[data_dataCount]->name(_name);
        bool success = _Data[data_dataCount]->saveDataValue(value, type, now_time, BLINKER_DATA_FREQ_TIME);
        
        if (success) {
            data_dataCount++;
            BLINKER_LOG_ALL(TAG_PROTO, _name, BLINKER_F(" created & saved directly"));
        } else {
            delete _Data[data_dataCount];
            _Data[data_dataCount] = nullptr;
            BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Save failed for new data"));
        }
    } else {
        bool success = _Data[num]->saveDataValue(value, type, now_time, BLINKER_DATA_FREQ_TIME);
        if (success) {
            BLINKER_LOG_ALL(TAG_PROTO, _name, BLINKER_F(" updated directly"));
        } else {
            BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Save skipped (too frequent): "), _name);
        }
    }

    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("chartDataUpload count: "), data_dataCount);
}
#endif

template <class Transp>
uint8_t BlinkerProtocol<Transp>::registerChart(const char* chartName, blinker_callback_t realtimeCallback)
{
    if (chart_count >= BLINKER_MAX_BLINKER_DATA_SIZE) {
        BLINKER_ERR_LOG(TAG_PROTO, BLINKER_F("Max chart count reached"));
        return 0;
    }
    
    int8_t existingIndex = findChartIndex(chartName);
    if (existingIndex != -1) {
        // 更新现有图表的回调
        _Charts[existingIndex].realtimeCallback = realtimeCallback;
        return existingIndex + 1;
    }
    
    strncpy(_Charts[chart_count].name, chartName, BLINKER_MAX_WIDGET_SIZE - 1);
    _Charts[chart_count].name[BLINKER_MAX_WIDGET_SIZE - 1] = '\0';
    _Charts[chart_count].isRealtimeMode = false;
    _Charts[chart_count].lastSendTime = 0;
    _Charts[chart_count].sendInterval = 1000;  // 默认1秒
    _Charts[chart_count].realtimeCallback = realtimeCallback;
    
    chart_count++;
    
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Chart registered: "), chartName, 
                    BLINKER_F(" (ID: "), chart_count, BLINKER_F(")"));
    
    return chart_count;
}

template <class Transp>
int8_t BlinkerProtocol<Transp>::findChartIndex(const char* chartName)
{
    for (uint8_t i = 0; i < chart_count; i++) {
        if (strcmp(_Charts[i].name, chartName) == 0) {
            return i;
        }
    }
    return -1;
}

template <class Transp>
void BlinkerProtocol<Transp>::setChartRealtimeMode(const char* chartName, bool realtime)
{
    int8_t index = findChartIndex(chartName);
    if (index != -1) {
        setChartRealtimeMode(index, realtime);
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::setChartRealtimeMode(uint8_t chartId, bool realtime)
{
    if (chartId > 0 && chartId <= chart_count) {
        uint8_t index = chartId - 1;
        _Charts[index].isRealtimeMode = realtime;
        _Charts[index].lastSendTime = 0;  // 重置时间
        
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Chart "), _Charts[index].name, 
                       BLINKER_F(" mode set to: "), 
                       realtime ? BLINKER_F("realtime") : BLINKER_F("historical"));
    }
}

template <class Transp>
bool BlinkerProtocol<Transp>::isChartRealtime(const char* chartName)
{
    int8_t index = findChartIndex(chartName);
    return (index != -1) ? _Charts[index].isRealtimeMode : false;
}

template <class Transp>
bool BlinkerProtocol<Transp>::isChartRealtime(uint8_t chartId)
{
    return (chartId > 0 && chartId <= chart_count) ? 
           _Charts[chartId - 1].isRealtimeMode : false;
}

template <class Transp>
void BlinkerProtocol<Transp>::setChartInterval(const char* chartName, uint32_t interval)
{
    int8_t index = findChartIndex(chartName);
    if (index != -1) {
        setChartInterval(index + 1, interval);
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::setChartInterval(uint8_t chartId, uint32_t interval)
{
    if (chartId > 0 && chartId <= chart_count) {
        _Charts[chartId - 1].sendInterval = interval;
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Chart "), _Charts[chartId - 1].name, 
                       BLINKER_F(" interval set to: "), interval, BLINKER_F("ms"));
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::parseRealtimeCommand(const String& data)
{
    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Parsing realtime command: "), data);
    
    DynamicJsonDocument jsonBuffer(512);
    DeserializationError error = deserializeJson(jsonBuffer, data);
    
    if (!error && jsonBuffer.containsKey("rt")) {
        JsonArray rtArray = jsonBuffer["rt"];
        
        _lastRealtimeCommandTime = millis();
        
        for (uint8_t i = 0; i < chart_count; i++) {
            _Charts[i].isRealtimeMode = false;
        }
        
        for (JsonVariant value : rtArray) {
            String chartName = value.as<String>();
            int8_t index = findChartIndex(chartName.c_str());
            if (index != -1) {
                _Charts[index].isRealtimeMode = true;
                _Charts[index].lastSendTime = 0;  // 重置时间
                BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Chart "), chartName, 
                               BLINKER_F(" switched to realtime mode"));
            }
        }
        
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Realtime command processed"));
        
        syncChartModes();
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::checkRealtimeTimeout()
{
    #if defined(BLINKER_WIFI)
    const uint32_t REALTIME_TIMEOUT_MS = 2 * _autoStorageTime * 1000;
    #else
    const uint32_t REALTIME_TIMEOUT_MS = 2 * 60 * 1000;  // 默认120秒超时
    #endif
    
    bool hasRealtimeCharts = false;
    for (uint8_t i = 0; i < chart_count; i++) {
        if (_Charts[i].isRealtimeMode) {
            hasRealtimeCharts = true;
            break;
        }
    }
    
    if (hasRealtimeCharts && _lastRealtimeCommandTime > 0) {
        uint32_t currentTime = millis();
        
        uint32_t timeDiff;
        if (currentTime >= _lastRealtimeCommandTime) {
            timeDiff = currentTime - _lastRealtimeCommandTime;
        } else {
            timeDiff = (UINT32_MAX - _lastRealtimeCommandTime) + currentTime + 1;
        }
        
        if (timeDiff >= REALTIME_TIMEOUT_MS) {
            BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Realtime timeout detected, switching all charts to historical mode"));
            
            for (uint8_t i = 0; i < chart_count; i++) {
                if (_Charts[i].isRealtimeMode) {
                    _Charts[i].isRealtimeMode = false;
                    BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Chart "), i, BLINKER_F(" switched to historical due to timeout"));
                }
            }
            
            _lastRealtimeCommandTime = 0;
            
            syncChartModes();
        }
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::syncChartModes()
{
    extern void (*_blinker_chart_sync_callback)(void);
    if (_blinker_chart_sync_callback) {
        BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Calling chart sync callback"));
        _blinker_chart_sync_callback();
    }
}

template <class Transp>
void BlinkerProtocol<Transp>::checkRealtimeCharts()
{
    uint32_t currentTime = millis();
    
    if (currentTime - _lastRealtimeCheck < 10) {
        return;
    }
    _lastRealtimeCheck = currentTime;
    
    for (uint8_t i = 0; i < chart_count; i++) {
        if (_Charts[i].isRealtimeMode && _Charts[i].realtimeCallback) {
            if (currentTime - _Charts[i].lastSendTime >= _Charts[i].sendInterval) {
                _Charts[i].lastSendTime = currentTime;
                
                _Charts[i].realtimeCallback();
                
                BLINKER_LOG_ALL(TAG_PROTO, BLINKER_F("Realtime callback triggered for: "), 
                               _Charts[i].name);
            }
        }
    }
}

// #endif
