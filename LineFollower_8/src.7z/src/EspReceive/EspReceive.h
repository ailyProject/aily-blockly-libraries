#ifndef ESPRECEIVE_H
#define ESPRECEIVE_H

#include <Arduino.h>
#include <Wire.h>

// 传感器数据结构 (8路传感器)
struct SensorData {
  uint8_t digital;         // 数字状态（8位二进制值，每位表示一个传感器）
  uint16_t reference[8];   // 参考值（每个传感器的阈值，0-1023）
  uint16_t current[8];     // 当前值（当前的传感器读数，0-1023）
};

// RGB颜色值定义
enum RGBColor {
  RGB_COLOR_OFF = 0,      // 关闭
  RGB_COLOR_RED = 1,      // 红色
  RGB_COLOR_GREEN = 2,    // 绿色
  RGB_COLOR_BLUE = 3,     // 蓝色
  RGB_COLOR_WHITE = 4,    // 白色
  RGB_COLOR_YELLOW = 5,   // 黄色
  RGB_COLOR_CYAN = 6,     // 青色
  RGB_COLOR_MAGENTA = 7   // 紫色
};

// 简化别名以兼容生成代码
#define OFF RGB_COLOR_OFF
#define RED RGB_COLOR_RED
#define GREEN RGB_COLOR_GREEN
#define BLUE RGB_COLOR_BLUE
#define WHITE RGB_COLOR_WHITE
#define YELLOW RGB_COLOR_YELLOW
#define CYAN RGB_COLOR_CYAN
#define MAGENTA RGB_COLOR_MAGENTA

// 传感器ID常量定义（与图形化代码兼容）
#define A0 0
#define A1 1
#define A2 2
#define A3 3
#define A4 4
#define A5 5
#define A6 6
#define A7 7

// 线路状态常量定义（8路传感器，256种状态，定义常用状态）
#define STATE_00000000 0    // 全白线
#define STATE_00011000 24   // 中间两个传感器检测到黑线（直行）
#define STATE_00111100 60   // 中间四个传感器检测到黑线（宽线）
#define STATE_11111111 255  // 全黑线

class EspReceive {
private:
  // I2C设备地址（八路版本）
  static const uint8_t SENSOR_DRIVER_ADDR = 0x27;
  
  // 命令类型定义
  static const uint8_t CMD_READ_SENSORS = 0x01;  // 读取传感器数据命令
  static const uint8_t CMD_SET_FREQ = 0x02;      // 设置上传频率命令
  static const uint8_t CMD_SET_RGB = 0x03;       // RGB灯控制命令
  
  uint8_t _sdaPin;
  uint8_t _sclPin;
  uint16_t _uploadInterval;
  SensorData _latestSensorData;
  bool _autoUploadEnabled;
  unsigned long _lastI2CCheckTime;
  
  // 内部方法
  bool readSensorDataOnce(SensorData &data);
  bool checkAutoUploadData();
  bool checkAutoUploadDataWithRetry();  // 带重试机制的数据读取
  void processSensorData(SensorData &data);
  
public:
  // 构造函数 - ESP32标准引脚
  EspReceive(uint8_t sdaPin = 21, uint8_t sclPin = 22, uint16_t uploadInterval = 5);
  
  // 初始化
  bool begin();
  
  // 自动上传控制
  void enableAutoUpload(bool enabled = true);
  void disableAutoUpload();
  bool isAutoUploadEnabled();
  
  // 数据读取
  bool readSensorData(SensorData &data);
  SensorData getLatestData();
  
  // 状态计算
  uint8_t calculateDigitalState(const SensorData &data);
  float calculateLineOffset(SensorData data);  // 计算加权偏移量（-7到+7）
  String stateToString(uint8_t state);
  
  // 单路传感器数据获取
  uint16_t getSensorReference(SensorData data, uint8_t sensorId);
  uint16_t getSensorCurrent(SensorData data, uint8_t sensorId);
  uint8_t getSensorColor(SensorData data, uint8_t sensorId);
  
  // 状态对比和显示
  void printSensorData(SensorData &data);
  void printSingleSensor(SensorData &data, int sensorIndex);
  void printStateComparison(uint8_t currentState, uint8_t targetState);
  void printAllStates();
  void printDetailedAnalysis(SensorData &data);
  
  // RGB控制
  bool setModuleRGB(RGBColor color);
  bool setModuleRGB(uint8_t colorValue);
  
  // 频率设置
  bool setModuleFrequency(uint16_t intervalMs);
  
  // 工具方法
  bool isValidSensorIndex(int index);
  String getColorName(uint8_t colorValue);
  String getSensorPinName(int index);
  
  // 循环处理（用于自动上传）
  void loop();
  
  // I2C诊断功能
  void scanI2CDevices();
  bool testI2CConnection();
  
  // 版本信息
  static const char* getVersion() { return "1.0.0"; }
};

#endif