// Please note, the Arduino IDE is a bit retarded, if the below define has an
// underscore other than _h, it goes mental.  Wish it wouldn't  mess
// wif ma files!
#ifndef OJASR_h
#define OJASR_h

#include <Arduino.h>

#if defined __AVR__ || defined(ESP8266) 
#include <SoftwareSerial.h>
#elif defined (ESP32)
#include <ESP32SoftwareSerial.h>
#endif

#define ASR_DEBUG 0

#if defined __AVR__ || defined(ESP8266) 

class OJASR : public SoftwareSerial
{
  
  public: 

    /** Create OPENJUMMPER ASR object.
     * 
     * Example, create global instance:
     * 
     *     OJASR asr(2,3);
     * 
     * For a 5v Arduino:
     * -----------------
     *  * TX on GD3800 connects to D2 on the Arduino
     *  * RX on GD3800 connects to one end of a 1k resistor,
     *      other end of resistor connects to D3 on the Arduino
     * 
     * For a 3v3 Arduino:
     * -----------------
     *  * TX on GD3800 connects to D2 on the Arduino
     *  * RX on GD3800 connects to D3 on the Arduino
     * 
     * Of course, power and ground are also required, VCC on ASR modular is 5v tolerant (but RX isn't totally, hence the resistor above).
     * 
     * And then you can use in your setup():
     * 
     *     asr.begin(115200)//Note: The baud rate here must be 115200
     *
     * and all the other commands :-)
     */
    
    OJASR(short rxPin, short txPin) : SoftwareSerial(rxPin,txPin) { };

    //int getAsrDateNumber();
    int asrRun();

    int asrDate = -1;
    int WakeUpStatus = 0;
    unsigned long lastWakeUptime = 0;
  
  protected:

    size_t readBytesUntilAndIncluding(char terminator, char *buffer, size_t length, byte maxOneLineOnly = 0);
    
    int    waitUntilAvailable(unsigned long maxWaitTime = 1000);
    
};

#elif defined ESP32

class OJASR : public Esp32SoftwareSerial
{
  
  public: 

    /** Create OPENJUMMPER ASR object.
     * 
     * Example, create global instance:
     * 
     *     OJASR asr(D18,D19);
     * 
     * For a 5v Arduino:
     * -----------------
     *  * TX on GD3800 connects to D18 on the Arduino
     *  * RX on GD3800 connects to one end of a 1k resistor,
     *      other end of resistor connects to D19 on the Arduino
     * 
     * For a 3v3 Arduino:
     * -----------------
     *  * TX on GD3800 connects to D18 on the Arduino
     *  * RX on GD3800 connects to D19 on the Arduino
     * 
     * Of course, power and ground are also required, VCC on ASR modular is 5v tolerant (but RX isn't totally, hence the resistor above).
     * 
     * And then you can use in your setup():
     * 
     *     asr.begin(115200)//Note: The baud rate here must be 115200
     *
     * and all the other commands :-)
     */
    
    OJASR(short rxPin, short txPin) : Esp32SoftwareSerial(rxPin,txPin) { };

    int asrRun();

    int asrDate = -1;
    int WakeUpStatus = 0;
    unsigned long lastWakeUptime = 0;
    
  protected:

    size_t readBytesUntilAndIncluding(char terminator, char *buffer, size_t length, byte maxOneLineOnly = 0);
    
    int    waitUntilAvailable(unsigned long maxWaitTime = 1000);
    
};

#endif

#endif