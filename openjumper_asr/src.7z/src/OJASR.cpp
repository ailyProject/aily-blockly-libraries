#include "OJASR.h"

/* 
#if MP3_DEBUG
      Serial.print("EF");      
      #endif
*/ 

// Waits until data becomes available, or a timeout occurs
int OJASR::waitUntilAvailable(unsigned long maxWaitTime)
{
  unsigned long startTime;
  int c = 0;
  startTime = millis();
  do {
    c = this->available();
    if (c) break;
    } while(millis() - startTime < maxWaitTime);

    return c;
}

/*
int OJASR::getAsrDateNumber(void){
  int number = -1;

  while(this->waitUntilAvailable(150))
  {
    number = this->read();
        
    #if ASR_DEBUG
    Serial.println(number);
    #endif
  }

  if(number >= 0)
    return number;
}
*/

int OJASR::asrRun(void){
  asrDate = -1;
  int Rnumber = -1;

  if (lastWakeUptime != 0){
    if((millis() -  lastWakeUptime) >= 15000){
      if(WakeUpStatus != 0){
        WakeUpStatus = 0;
        
        #if ASR_DEBUG
        Serial.print("last Wake Up time:");
        Serial.print(lastWakeUptime);
        Serial.print(" --now time:");
        Serial.print(millis());
        Serial.print(" --Wake Up Status:");
        Serial.println(WakeUpStatus);
        #endif
      }  
    }
    else{ if(WakeUpStatus != 1)WakeUpStatus = 1;}
  }

  while(this->waitUntilAvailable(150))
  {
    Rnumber = this->read();
        
    if(Rnumber >= 0){
      asrDate = Rnumber;
      WakeUpStatus = 1;
      lastWakeUptime = millis();

      #if ASR_DEBUG
      Serial.print("cmd:");
      Serial.print(Rnumber);
      Serial.print(" --Wake Up Status:");
      Serial.print(WakeUpStatus);
      Serial.print(" --Wake Up time:");
      Serial.println(lastWakeUptime);
      #endif

      return Rnumber;
    }   
  }
}
