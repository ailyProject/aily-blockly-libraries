#include "CHSC6X.h"

CHSC6X::CHSC6X(uint8_t screen_w, uint8_t screen_h, 
    uint8_t rotation, uint8_t int_pin, 
    uint16_t i2c_addr, TwoWire *wire)
    : _touch_wire(wire),
      _i2c_addr(i2c_addr),
      _int_pin(int_pin),
      _screen_width(screen_w),
      _screen_height(screen_h),
      _rotation(rotation)
{}

void CHSC6X::begin()
{
    pinMode(_int_pin, INPUT_PULLUP);
    _touch_wire->begin(); // Initialize I2C bus for touch controller
}

bool CHSC6X::isPressed()
{
    if(digitalRead(_int_pin) != LOW) {
        delay(1);
        if(digitalRead(_int_pin) != LOW)
        return false;
    }
    return true;
}

bool CHSC6X::getXY(uint8_t &x, uint8_t &y)
{
    uint8_t temp[CHSC6X_READ_POINT_LEN] = {0};
    uint8_t read_len = _touch_wire->requestFrom(_i2c_addr, CHSC6X_READ_POINT_LEN);
    if(read_len == CHSC6X_READ_POINT_LEN){
        _touch_wire->readBytes(temp, read_len);
        if (temp[0] == 0x01) {
            _convertXY(temp[2], temp[4]);
            x = temp[2];
            y = temp[4];

            return true; // Valid touch point obtained
        }
    }
    return false; // Failed to get valid touch point
}

bool CHSC6X::run()
{
    return getXY(_x, _y);
}

// Private coordinate conversion function (switch-case method)
void CHSC6X::_convertXY(uint8_t &x, uint8_t &y)
{
    uint8_t temp_x = x, temp_y = y, screen_end = 0;
    
    // 修正角度偏移：原始坐标系偏移了90度，需要补偿
    // rotation映射: 0→3次(270°), 1→0次(0°), 2→1次(90°), 3→2次(180°)
    int actual_rotation_count = (_rotation + 3) % 4;
    
    for (int i = 1; i <= actual_rotation_count; i++) {
        temp_x = x;
        temp_y = y;
        screen_end = (i % 2) ? _screen_width : _screen_height;
        x = temp_y;
        y = screen_end - temp_x;
    }
}

// Utility methods implementation
void CHSC6X::setRotation(uint8_t rotation)
{
    _rotation = rotation % 4; // Ensure rotation is 0-3
}

uint8_t CHSC6X::getRotation() const
{
    return _rotation;
}

void CHSC6X::setScreenSize(uint8_t width, uint8_t height)
{
    _screen_width = width;
    _screen_height = height;
}

void CHSC6X::getScreenSize(uint8_t &width, uint8_t &height) const
{
    width = _screen_width;
    height = _screen_height;
}