#ifndef CHSC6X_H
#define CHSC6X_H

#include "Arduino.h"
#include <Wire.h>

#define CHSC6X_I2C_ID 0x2e
#define CHSC6X_MAX_POINTS_NUM 1
#define CHSC6X_READ_POINT_LEN 5
#define TOUCH_INT D7

class CHSC6X {
    public:
        CHSC6X(uint8_t screen_w = 240, uint8_t screen_h = 240, 
            uint8_t rotation = 0, uint8_t int_pin = TOUCH_INT, 
            uint16_t i2c_addr = CHSC6X_I2C_ID, TwoWire *wire = &Wire);

        void begin();
        bool isPressed();
        bool getXY(uint8_t &x, uint8_t &y);
        bool run();

        uint8_t getX() const { return _x; }
        uint8_t getY() const { return _y; }
        
        // Alternative coordinate conversion method (similar to lv_xiao_round_screen.h)
        void convertXYLoop(uint8_t &x, uint8_t &y);
        
        // Utility methods
        void setRotation(uint8_t rotation);
        uint8_t getRotation() const;
        void setScreenSize(uint8_t width, uint8_t height);
        void getScreenSize(uint8_t &width, uint8_t &height) const;

    private:
        void _convertXY(uint8_t &x, uint8_t &y);
        TwoWire *_touch_wire;
        uint16_t _i2c_addr;
        uint8_t _int_pin;
        uint8_t _screen_width;
        uint8_t _screen_height;
        uint8_t _rotation;
        uint8_t _x;;
        uint8_t _y;
};

#endif /* CHSC6X_H */
