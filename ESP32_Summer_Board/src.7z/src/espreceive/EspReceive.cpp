#include "EspReceive.h"

// 构造函数 - 完全按照原始esp32.ino设计
EspReceive::EspReceive(uint8_t sdaPin, uint8_t sclPin, uint16_t uploadInterval) {
  _sdaPin = sdaPin;
  _sclPin = sclPin;
  _uploadInterval = uploadInterval;
  _autoUploadEnabled = true;  // 默认启用自动上传
  _lastI2CCheckTime = 0;
  
  // 初始化传感器数据
  memset(&_latestSensorData, 0, sizeof(SensorData));
}

// 优化初始化：提高I2C速度
bool EspReceive::begin() {
  Wire.begin(_sdaPin, _sclPin);
  Wire.setClock(100000); // 提高到100kHz，加快通信速度
  Wire.setTimeOut(20);   // 减少超时时间到20ms
  
  delay(5); // 减少初始化延时
  return true;
}

// 自动上传控制
void EspReceive::enableAutoUpload(bool enabled) {
  _autoUploadEnabled = enabled;
}

void EspReceive::disableAutoUpload() {
  _autoUploadEnabled = false;
}

bool EspReceive::isAutoUploadEnabled() {
  return _autoUploadEnabled;
}

// 核心优化：快速数据读取，最小化延时和重试
bool EspReceive::checkAutoUploadData() {
  SensorData sensorData;
  
  // 减少重试次数，提高响应速度
  const int maxRetries = 2; // 从3减少到2
  
  for (int retry = 0; retry < maxRetries; retry++) {
    Wire.beginTransmission(SENSOR_DRIVER_ADDR);
    Wire.write(CMD_READ_SENSORS);
    byte error = Wire.endTransmission();
    
    if (error != 0) {
      if (retry < maxRetries - 1) {
        delay(2); // 大幅减少重试延时
        continue;
      }
      return false;
    }
    
    // 最小化等待延时
    delay(2); // 与八路Arduino Uno版本一致
  
    int bytesReceived = Wire.requestFrom((uint8_t)SENSOR_DRIVER_ADDR, (uint8_t)32);
    
    if (bytesReceived == 32) {
      // 八路版本：不读取数字状态字节，Arduino端自己计算
      
      // 读取参考值（8路传感器，每个占用2字节，大端序）
      for (int i = 0; i < 8; i++) {
        uint8_t highByte = Wire.read();
        uint8_t lowByte = Wire.read();
        sensorData.reference[i] = (highByte << 8) | lowByte;
      }
      
      // 读取当前值（8路传感器，每个占用2字节，大端序）
      for (int i = 0; i < 8; i++) {
        uint8_t highByte = Wire.read();
        uint8_t lowByte = Wire.read();
        sensorData.current[i] = (highByte << 8) | lowByte;
      }
      
      // 计算数字状态值（根据参考值和当前值）
      sensorData.digital = 0;
      for (int i = 0; i < 8; i++) {
        if (sensorData.current[i] >= sensorData.reference[i]) {
          sensorData.digital |= (1 << i);
        }
      }
      
      // 简化数据验证，只检查基本范围
      bool dataValid = true;
      for (int i = 0; i < 8; i++) {
        if (sensorData.current[i] > 4095 || sensorData.reference[i] > 4095) {
          dataValid = false;
          break;
        }
      }
      
      if (dataValid) {
        _latestSensorData = sensorData;
        return true;
      }
    }
    
    // 清空缓冲区
    while (Wire.available()) Wire.read();
    
    // 最小重试间隔
    if (retry < maxRetries - 1) {
      delay(1); // 大幅减少重试延时
    }
  }
  
  return false;
}

// 简化重试版本
bool EspReceive::checkAutoUploadDataWithRetry() {
  // 直接调用优化后的基本版本，不再额外重试
  return checkAutoUploadData();
}

// 简化的单次读取
bool EspReceive::readSensorDataOnce(SensorData &data) {
  Wire.beginTransmission(SENSOR_DRIVER_ADDR);
  Wire.write(CMD_READ_SENSORS);
  byte error = Wire.endTransmission();
  
  if (error != 0) return false;
  
  delay(2); // 与八路Arduino Uno版本一致
  
  int bytesReceived = Wire.requestFrom((uint8_t)SENSOR_DRIVER_ADDR, (uint8_t)32);
  
  if (bytesReceived == 32) {
    // 读取参考值（8路传感器）
    for (int i = 0; i < 8; i++) {
      uint8_t highByte = Wire.read();
      uint8_t lowByte = Wire.read();
      data.reference[i] = (highByte << 8) | lowByte;
    }
    
    // 读取当前值（8路传感器）
    for (int i = 0; i < 8; i++) {
      uint8_t highByte = Wire.read();
      uint8_t lowByte = Wire.read();
      data.current[i] = (highByte << 8) | lowByte;
    }
    
    // 计算数字状态值
    data.digital = 0;
    for (int i = 0; i < 8; i++) {
      if (data.current[i] >= data.reference[i]) {
        data.digital |= (1 << i);
      }
    }
    
    _latestSensorData = data;
    return true;
  } else if (bytesReceived > 0) {
    while (Wire.available()) Wire.read();
  }
  
  return false;
}

// 读取传感器数据 - 简单封装
bool EspReceive::readSensorData(SensorData &data) {
  return checkAutoUploadData();
}

// 处理接收到的传感器数据 - 八路版本
void EspReceive::processSensorData(SensorData &data) {
  // 打印数字状态 - 反转显示方向：A7→A0
  Serial.print("DigitalValue: 0b");
  for (int i = 0; i < 8; i++) {
    Serial.print((data.digital >> i) & 1);
  }
  Serial.print(" (");
  
  // 打印每个传感器的数字状态 (A0→A7顺序)
  for (int i = 0; i < 8; i++) {
    Serial.print("A");
    Serial.print(i);
    Serial.print("=");
    Serial.print((data.digital >> i) & 1);
    if (i < 7) Serial.print(", ");
  }
  Serial.println(")");
  
  // 打印当前值 (A0-A7顺序)
  Serial.print("CurrentGrayValue: ");
  for (int i = 0; i < 8; i++) {
    Serial.print(data.current[i]);
    if (i < 7) Serial.print(", ");
  }
  Serial.println();
  
  // 打印参考值 (A0-A7顺序)
  Serial.print("ReferenceGrayValue: ");
  for (int i = 0; i < 8; i++) {
    Serial.print(data.reference[i]);
    if (i < 7) Serial.print(", ");
  }
  Serial.println();
  Serial.println();
}

// 关键优化：实时获取最新数据，无延时限制
SensorData EspReceive::getLatestData() {
  // 每次调用都立即尝试获取最新数据，不设任何时间间隔
  checkAutoUploadData();
  return _latestSensorData;
}

// 计算实时数字状态（实时>=参考为1，小于参考为0，与八路Arduino Uno版本一致）
uint8_t EspReceive::calculateDigitalState(const SensorData &data) {
  uint8_t state = 0;
  for (int i = 0; i < 8; i++) {
    if (data.current[i] >= data.reference[i]) {
      state |= (1 << i);  // 设置对应位为1
    }
  }
  return state;
}

// 计算偏移量
int EspReceive::calculateLineOffset(SensorData data) {
  // 偏移量 = A1传感器值 - A2传感器值
  return (int)data.current[1] - (int)data.current[2];
}

// 状态转换为二进制字符串（8位）
String EspReceive::stateToString(uint8_t state) {
  String result = "";
  for (int i = 7; i >= 0; i--) {
    result += ((state >> i) & 1) ? "1" : "0";
  }
  return result;
}

// 单路传感器数据获取函数
uint16_t EspReceive::getSensorReference(SensorData data, uint8_t sensorId) {
  if (sensorId < 8) {
    return data.reference[sensorId];
  }
  return 0;
}

uint16_t EspReceive::getSensorCurrent(SensorData data, uint8_t sensorId) {
  if (sensorId < 8) {
    return data.current[sensorId];
  }
  return 0;
}

uint8_t EspReceive::getSensorColor(SensorData data, uint8_t sensorId) {
  if (sensorId < 8) {
    // 返回数字值：当前值 >= 参考值时为1（检测到黑线），否则为0（白色背景）
    return (data.current[sensorId] >= data.reference[sensorId]) ? 1 : 0;
  }
  return 0;
}

// 打印传感器数据（8路）
void EspReceive::printSensorData(SensorData &data) {
  // 打印参考值 (8路传感器)
  Serial.print("ReferenceGrayValue: ");
  for (int i = 0; i < 8; i++) {
    Serial.print(data.reference[i]);
    if (i < 7) Serial.print(", ");
  }
  Serial.println();
  
  // 打印当前值 (8路传感器)
  Serial.print("CurrentGrayValue: ");
  for (int i = 0; i < 8; i++) {
    Serial.print(data.current[i]);
    if (i < 7) Serial.print(", ");
  }
  Serial.println();
  Serial.println();
}

// 打印单路传感器数据
void EspReceive::printSingleSensor(SensorData &data, int sensorIndex) {
  if (!isValidSensorIndex(sensorIndex)) {
    Serial.println("错误：传感器索引超出范围 (0-7)");
    return;
  }
  
  // 打印单路传感器信息
  Serial.print("传感器 ");
  Serial.print(getSensorPinName(sensorIndex));
  Serial.println(" 数据:");
  
  // 打印原始数字状态
  bool digitalState = (data.digital >> sensorIndex) & 1;
  Serial.print("  原始数字状态: ");
  Serial.print(digitalState ? "HIGH" : "LOW");
  Serial.print(" (");
  Serial.print(digitalState);
  Serial.println(")");
  
  // 计算实时数字状态
  bool realtimeDigitalState = data.current[sensorIndex] >= data.reference[sensorIndex];
  Serial.print("  实时数字状态: ");
  Serial.print(realtimeDigitalState ? "HIGH" : "LOW");
  Serial.print(" (");
  Serial.print(realtimeDigitalState ? 1 : 0);
  Serial.println(") [当前值>=参考值=1, <参考值=0]");
  
  // 打印参考值
  Serial.print("  参考值: ");
  Serial.println(data.reference[sensorIndex]);
  
  // 打印当前值
  Serial.print("  当前值: ");
  Serial.println(data.current[sensorIndex]);
  
  Serial.println();
}

// 状态对比
void EspReceive::printStateComparison(uint8_t currentState, uint8_t targetState) {
  Serial.println("=== 状态对比 ===");
  Serial.print("当前状态: ");
  Serial.print(stateToString(currentState));
  Serial.print(" (十进制: ");
  Serial.print(currentState);
  Serial.println(")");
  
  Serial.print("目标状态: ");
  Serial.print(stateToString(targetState));
  Serial.print(" (十进制: ");
  Serial.print(targetState);
  Serial.println(")");
  
  if (currentState == targetState) {
    Serial.println("状态匹配: ✓ 相同");
  } else {
    Serial.println("状态匹配: ✗ 不同");
    
    // 显示差异位
    uint8_t diff = currentState ^ targetState;
    Serial.print("差异位: ");
    Serial.print(stateToString(diff));
    Serial.print(" (位置: ");
    for (int i = 0; i < 8; i++) {
      if (diff & (1 << i)) {
        Serial.print("A");
        Serial.print(i);
        Serial.print(" ");
      }
    }
    Serial.println(")");
  }
  Serial.println();
}

// 打印所有256种状态（简化版，只显示前32个和最后8个）
void EspReceive::printAllStates() {
  Serial.println("=== 8路传感器状态表（部分显示）===");
  Serial.println("十进制 | 二进制     | 传感器状态描述");
  Serial.println("-------|------------|------------------");
  
  // 显示前32个状态
  for (int i = 0; i < 32; i++) {
    Serial.printf("%6d | %s | ", i, stateToString(i).c_str());
    
    // 描述每个传感器的状态
    for (int j = 0; j < 8; j++) {
      Serial.print("A");
      Serial.print(j);
      Serial.print(":");
      Serial.print(((i >> j) & 1) ? "1" : "0");
      if (j < 7) Serial.print(",");
    }
    Serial.println();
  }
  
  Serial.println("...(省略中间状态)...");
  
  // 显示最后8个状态
  for (int i = 248; i < 256; i++) {
    Serial.printf("%6d | %s | ", i, stateToString(i).c_str());
    
    for (int j = 0; j < 8; j++) {
      Serial.print("A");
      Serial.print(j);
      Serial.print(":");
      Serial.print(((i >> j) & 1) ? "1" : "0");
      if (j < 7) Serial.print(",");
    }
    Serial.println();
  }
  Serial.println();
}

// 详细分析（8路）
void EspReceive::printDetailedAnalysis(SensorData &data) {
  uint8_t realtimeState = calculateDigitalState(data);
  
  Serial.println("详细分析: [当前值>=参考值=1, <参考值=0]");
  for (int i = 0; i < 8; i++) {
    bool bitState = (realtimeState >> i) & 1;
    Serial.print("  A"); Serial.print(i); Serial.print(": ");
    Serial.print(data.current[i]); 
    Serial.print(bitState ? " >= " : " < ");
    Serial.print(data.reference[i]);
    Serial.print(" → "); Serial.println(bitState ? "1" : "0");
  }
  Serial.println();
}

// RGB控制
bool EspReceive::setModuleRGB(RGBColor color) {
  return setModuleRGB((uint8_t)color);
}

bool EspReceive::setModuleRGB(uint8_t colorValue) {
  Wire.beginTransmission(SENSOR_DRIVER_ADDR);
  Wire.write(CMD_SET_RGB);     // 发送RGB控制命令
  Wire.write(colorValue);      // 发送颜色值
  byte error = Wire.endTransmission();
  
  if (error != 0) {
    return false;
  } else {
    // String colorNames[] = {"OFF", "RED", "GREEN", "BLUE", "WHITE", "YELLOW", "CYAN", "MAGENTA"};
    // if (colorValue <= 7) {
    //   Serial.print("RGB灯设置为: ");
    //   Serial.println(colorNames[colorValue]);
    // } else {
    //   Serial.print("RGB灯设置为未知颜色: ");
    //   Serial.println(colorValue);
    // }
  }
  
  // 等待命令处理 - 与原始代码一致
  delay(10);
  return true;
}

// 频率设置 - 完全按照原始esp32.ino实现
bool EspReceive::setModuleFrequency(uint16_t intervalMs) {
  Wire.beginTransmission(SENSOR_DRIVER_ADDR);
  Wire.write(CMD_SET_FREQ);  // 发送设置频率命令
  Wire.write((uint8_t)(intervalMs >> 8));  // 高字节
  Wire.write((uint8_t)(intervalMs & 0xFF));  // 低字节
  byte error = Wire.endTransmission();
  
  if (error != 0) {
    // Serial.print("设置上传频率失败，错误码: ");
    // Serial.println(error);
    return false;
  } else {
    _uploadInterval = intervalMs;
    // Serial.print("上传频率设置成功，间隔: ");
    // Serial.print(intervalMs);
    // Serial.println(" ms");
    return true;
  }
}

// 工具方法
bool EspReceive::isValidSensorIndex(int index) {
  return (index >= 0 && index <= 7);
}

String EspReceive::getColorName(uint8_t colorValue) {
  String colorNames[] = {"OFF", "RED", "GREEN", "BLUE", "WHITE", "YELLOW", "CYAN", "MAGENTA"};
  if (colorValue <= 7) {
    return colorNames[colorValue];
  } else {
    return "UNKNOWN(" + String(colorValue) + ")";
  }
}

String EspReceive::getSensorPinName(int index) {
  String pinNames[] = {"A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7"};
  if (isValidSensorIndex(index)) {
    return pinNames[index];
  }
  return "INVALID";
}

// I2C设备扫描功能
void EspReceive::scanI2CDevices() {
  // Serial.println("\n=== I2C设备扫描 ===");
  // Serial.println("扫描地址范围: 0x01-0x7F");
  
  int deviceCount = 0;
  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();
    
    if (error == 0) {
      // Serial.print("发现I2C设备，地址: 0x");
      // if (address < 16) Serial.print("0");
      // Serial.print(address, HEX);
      // Serial.print(" (十进制: ");
      // Serial.print(address);
      // Serial.println(")");
      deviceCount++;
      
      if (address == SENSOR_DRIVER_ADDR) {
        // Serial.println("  ✓ 这是目标传感器设备！");
      }
    } else if (error == 4) {
      // Serial.print("地址 0x");
      // if (address < 16) Serial.print("0");
      // Serial.print(address, HEX);
      // Serial.println(" 发生未知错误");
    }
  }
  
  if (deviceCount == 0) {
    // Serial.println("❌ 未发现任何I2C设备！");
    // Serial.println("请检查:");
    // Serial.println("  1. SDA/SCL引脚连接");
    // Serial.println("  2. 设备供电");
    // Serial.println("  3. 上拉电阻(通常ESP32内置)");
  } else {
    // Serial.print("✓ 总共发现 ");
    // Serial.print(deviceCount);
    // Serial.println(" 个I2C设备");
  }
  // Serial.println("==================\n");
}

// 测试与目标设备的基本通信
bool EspReceive::testI2CConnection() {
  // Serial.println("\n=== 测试目标设备通信 ===");
  // Serial.print("目标地址: 0x");
  // Serial.print(SENSOR_DRIVER_ADDR, HEX);
  // Serial.print(" (十进制: ");
  // Serial.print(SENSOR_DRIVER_ADDR);
  // Serial.println(")");
  
  // 尝试简单的地址探测
  Wire.beginTransmission(SENSOR_DRIVER_ADDR);
  uint8_t error = Wire.endTransmission();
  
  if (error == 0) {
    // Serial.println("✓ 设备响应正常");
    return true;
  } else {
    // Serial.print("❌ 设备无响应，错误码: ");
    // Serial.println(error);
    // Serial.println("错误码含义:");
    // Serial.println("  1: 数据太长，超出传输缓冲区");
    // Serial.println("  2: 地址发送时收到NACK");
    // Serial.println("  3: 数据发送时收到NACK");
    // Serial.println("  4: 其他错误");
    // Serial.println("  5: 超时");
    return false;
  }
}

// 循环处理（用于自动上传）
void EspReceive::loop() {
  SensorData data;
  if (checkAutoUploadData()) {
    // 计算实时数字状态
    uint8_t realtimeState = calculateDigitalState(data);
    
    // 处理接收到的传感器数据
    // printSensorData(data);
    
    // 显示实时数字状态和详细分析
    // Serial.print("实时数字状态: ");
    // Serial.print(stateToString(realtimeState));
    // Serial.print(" (十进制: ");
    // Serial.print(realtimeState);
    // Serial.println(")");
    
    // 详细状态分析
    // printDetailedAnalysis(data);
  }
}
