#ifndef SERVO_H
#define SERVO_H

#include <Arduino.h>

class Servo {
private:
    int pin;
    int currentAngle;
    bool attached;
    int ledcChannel; // 新增：LEDC通道号
    
public:
    Servo();
    ~Servo();
    
    void attach(int pin);
    void detach();
    bool isAttached();
    
    void write(int angle);
    void writeMicroseconds(int microseconds);
    int read();
    
    // 平滑转动
    void smoothMove(int targetAngle, int speed = 5);
    
    // 扫描动作
    void sweep(int startAngle, int endAngle, int delayTime = 20);
};

#endif